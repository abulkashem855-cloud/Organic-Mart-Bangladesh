import express from 'express';
import path from 'path';
import cors from 'cors';
import bcrypt from 'bcryptjs';
import { createServer as createViteServer } from 'vite';
import { db } from './src/backend/db';
import { authenticateToken, requireAdmin, generateToken, AuthenticatedRequest } from './src/backend/middleware/auth';
import { User, Order, Product } from './src/types';

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(cors());
  app.use(express.json({ limit: '10mb' }));

  // --- API ROUTES ---

  // Health check
  app.get('/api/health', (req, res) => {
    res.json({ status: 'ok', app: 'Organic Mart Bangladesh', timestamp: new Date().toISOString() });
  });

  // Auth: Login
  app.post('/api/auth/login', (req, res) => {
    const { username, email, phone, password } = req.body;
    const identifier = username || email || phone;

    if (!identifier || !password) {
      return res.status(400).json({ error: 'Username/Email/Phone and Password are required' });
    }

    const user = db.getUserByEmailOrUsername(identifier);
    if (!user) {
      return res.status(401).json({ error: 'Invalid username or password' });
    }

    const isValid = db.verifyPassword(user.id, password);
    if (!isValid) {
      return res.status(401).json({ error: 'Invalid username or password' });
    }

    const token = generateToken(user);
    return res.json({
      message: 'Login successful',
      token,
      user: {
        id: user.id,
        name: user.name,
        email: user.email,
        phone: user.phone,
        role: user.role,
        avatar: user.avatar
      }
    });
  });

  // Auth: Register
  app.post('/api/auth/register', (req, res) => {
    const { name, email, password, phone } = req.body;

    if (!name || !email || !password) {
      return res.status(400).json({ error: 'Name, Email and Password are required' });
    }

    const existing = db.getUserByEmailOrUsername(email);
    if (existing) {
      return res.status(400).json({ error: 'User with this email already exists' });
    }

    const passwordHash = bcrypt.hashSync(password, 10);
    const newUser: User = {
      id: 'user-' + Date.now(),
      name,
      email,
      phone,
      role: 'user',
      createdAt: new Date().toISOString()
    };

    db.createUser(newUser, passwordHash);
    const token = generateToken(newUser);

    return res.status(201).json({
      message: 'Account created successfully',
      token,
      user: newUser
    });
  });

  // Auth: Me
  app.get('/api/auth/me', authenticateToken, (req: AuthenticatedRequest, res) => {
    if (!req.user) return res.status(401).json({ error: 'Unauthorized' });
    const user = db.getUserById(req.user.id);
    if (!user) return res.status(404).json({ error: 'User not found' });
    return res.json({ user });
  });

  // Products: List & Filter
  app.get('/api/products', (req, res) => {
    let products = db.getProducts();

    const { category, search, minPrice, maxPrice, sort, featured, bestSeller, todayDeal, seasonal, newArrival, brand } = req.query;

    if (category) {
      products = products.filter(p => p.categoryId === category);
    }

    if (brand) {
      products = products.filter(p => p.brand.toLowerCase() === (brand as string).toLowerCase());
    }

    if (search) {
      const q = (search as string).toLowerCase().trim();
      products = products.filter(p =>
        p.name.toLowerCase().includes(q) ||
        (p.bnName && p.bnName.includes(q)) ||
        p.categoryName.toLowerCase().includes(q) ||
        p.description.toLowerCase().includes(q)
      );
    }

    if (minPrice) {
      products = products.filter(p => (p.discountPrice || p.price) >= Number(minPrice));
    }

    if (maxPrice) {
      products = products.filter(p => (p.discountPrice || p.price) <= Number(maxPrice));
    }

    if (featured === 'true') {
      products = products.filter(p => p.featured);
    }

    if (bestSeller === 'true') {
      products = products.filter(p => p.bestSeller);
    }

    if (todayDeal === 'true') {
      products = products.filter(p => p.todayDeal);
    }

    if (seasonal === 'true') {
      products = products.filter(p => p.seasonal);
    }

    if (newArrival === 'true') {
      products = products.filter(p => p.newArrival);
    }

    // Sort
    if (sort === 'price-low') {
      products.sort((a, b) => (a.discountPrice || a.price) - (b.discountPrice || b.price));
    } else if (sort === 'price-high') {
      products.sort((a, b) => (b.discountPrice || b.price) - (a.discountPrice || a.price));
    } else if (sort === 'rating') {
      products.sort((a, b) => b.rating - a.rating);
    } else if (sort === 'newest') {
      products.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
    }

    return res.json({ count: products.length, products });
  });

  // Product: Single
  app.get('/api/products/:id', (req, res) => {
    const product = db.getProductById(req.params.id);
    if (!product) {
      return res.status(404).json({ error: 'Product not found' });
    }
    return res.json(product);
  });

  // Product: Add (Admin)
  app.post('/api/products', authenticateToken, requireAdmin, (req, res) => {
    try {
      const productData = req.body;
      const created = db.addProduct(productData);
      return res.status(201).json(created);
    } catch (err) {
      return res.status(500).json({ error: 'Failed to create product' });
    }
  });

  // Product: Update (Admin)
  app.put('/api/products/:id', authenticateToken, requireAdmin, (req, res) => {
    const updated = db.updateProduct(req.params.id, req.body);
    if (!updated) {
      return res.status(404).json({ error: 'Product not found' });
    }
    return res.json(updated);
  });

  // Product: Delete (Admin)
  app.delete('/api/products/:id', authenticateToken, requireAdmin, (req, res) => {
    const deleted = db.deleteProduct(req.params.id);
    if (!deleted) {
      return res.status(404).json({ error: 'Product not found' });
    }
    return res.json({ message: 'Product deleted successfully' });
  });

  // Product: Submit Review
  app.post('/api/products/:id/reviews', (req, res) => {
    const { userName, rating, comment } = req.body;
    if (!userName || !rating || !comment) {
      return res.status(400).json({ error: 'Name, Rating and Comment are required' });
    }

    const review = db.addProductReview(req.params.id, {
      userName,
      rating: Number(rating),
      comment,
      verifiedPurchase: true
    });

    if (!review) {
      return res.status(404).json({ error: 'Product not found' });
    }

    return res.status(201).json(review);
  });

  // Categories: List
  app.get('/api/categories', (req, res) => {
    return res.json(db.getCategories());
  });

  // Categories: Add (Admin)
  app.post('/api/categories', authenticateToken, requireAdmin, (req, res) => {
    try {
      const { name, bnName, icon, image, description, id } = req.body;
      if (!name) {
        return res.status(400).json({ error: 'Category English Name is required' });
      }
      const newCategory = db.addCategory({
        id,
        name,
        bnName: bnName || name,
        icon: icon || 'Leaf',
        image: image || 'https://images.unsplash.com/photo-1542838132-92c53300491e?w=800&auto=format&fit=crop&q=80',
        description: description || ''
      });
      return res.status(201).json(newCategory);
    } catch (err) {
      return res.status(500).json({ error: 'Failed to create category' });
    }
  });

  // Categories: Update (Admin)
  const handleCategoryUpdate = (req: AuthenticatedRequest, res: express.Response) => {
    const updated = db.updateCategory(req.params.id, req.body);
    if (!updated) {
      return res.status(404).json({ error: 'Category not found' });
    }
    return res.json(updated);
  };
  app.put('/api/categories/:id', authenticateToken, requireAdmin, handleCategoryUpdate);
  app.patch('/api/categories/:id', authenticateToken, requireAdmin, handleCategoryUpdate);

  // Categories: Delete (Admin)
  app.delete('/api/categories/:id', authenticateToken, requireAdmin, (req, res) => {
    const deleted = db.deleteCategory(req.params.id);
    if (!deleted) {
      return res.status(404).json({ error: 'Category not found' });
    }
    return res.json({ message: 'Category deleted successfully' });
  });

  // Coupons: Validate
  app.post('/api/coupons/apply', (req, res) => {
    const { code, amount } = req.body;
    if (!code) return res.status(400).json({ error: 'Coupon code required' });

    const coupon = db.getCouponByCode(code);
    if (!coupon) {
      return res.status(404).json({ error: 'Invalid or expired coupon code' });
    }

    if (amount && amount < coupon.minSpend) {
      return res.status(400).json({
        error: `Minimum spend of ৳${coupon.minSpend} required for coupon ${coupon.code}`
      });
    }

    let discountAmount = 0;
    if (coupon.discountType === 'percent') {
      discountAmount = Math.round((amount * coupon.discountValue) / 100);
      if (coupon.maxDiscount && discountAmount > coupon.maxDiscount) {
        discountAmount = coupon.maxDiscount;
      }
    } else {
      discountAmount = coupon.discountValue;
    }

    return res.json({
      valid: true,
      code: coupon.code,
      discountAmount,
      coupon
    });
  });

  // Coupons: List (Admin)
  app.get('/api/coupons', (req, res) => {
    return res.json(db.getCoupons());
  });

  // Coupons: Create (Admin)
  app.post('/api/coupons', authenticateToken, requireAdmin, (req, res) => {
    const couponData = req.body;
    if (!couponData.code || !couponData.discountValue) {
      return res.status(400).json({ error: 'Code and discount value required' });
    }
    const created = db.addCoupon({
      ...couponData,
      id: 'coupon-' + Date.now(),
      active: true
    });
    return res.status(201).json(created);
  });

  // Coupons: Delete (Admin)
  app.delete('/api/coupons/:id', authenticateToken, requireAdmin, (req, res) => {
    const deleted = db.deleteCoupon(req.params.id);
    if (!deleted) return res.status(404).json({ error: 'Coupon not found' });
    return res.json({ message: 'Coupon deleted successfully' });
  });

  // Orders: Create
  app.post('/api/orders', (req, res) => {
    const orderData = req.body;

    if (!orderData.customerName || !orderData.customerPhone || !orderData.items || orderData.items.length === 0) {
      return res.status(400).json({ error: 'Missing customer details or items' });
    }

    const order = db.createOrder({
      ...orderData,
      status: 'Pending',
      paymentStatus: orderData.paymentMethod === 'cod' ? 'Pending' : 'Paid',
      statusHistory: [
        {
          status: 'Pending',
          timestamp: new Date().toISOString(),
          note: `Order submitted with payment method ${orderData.paymentMethod.toUpperCase()}`
        }
      ]
    });

    return res.status(201).json(order);
  });

  // Orders: Track by ID or Phone
  app.get('/api/orders/track/:query', (req, res) => {
    const order = db.getOrderById(req.params.query);
    if (!order) {
      return res.status(404).json({ error: 'No order found matching this Order ID or Phone number' });
    }
    return res.json(order);
  });

  // Orders: List (User / Admin)
  app.get('/api/orders', (req, res) => {
    const phone = req.query.phone as string;
    let orders = db.getOrders();
    if (phone) {
      orders = orders.filter(o => o.customerPhone === phone);
    }
    return res.json(orders);
  });

  // Orders: Update Status (Admin)
  const handleOrderStatusUpdate = (req: AuthenticatedRequest, res: express.Response) => {
    const { status, note } = req.body;
    if (!status) return res.status(400).json({ error: 'Status is required' });

    const updated = db.updateOrderStatus(req.params.id, status, note);
    if (!updated) return res.status(404).json({ error: 'Order not found' });

    return res.json(updated);
  };

  app.put('/api/orders/:id/status', authenticateToken, requireAdmin, handleOrderStatusUpdate);
  app.patch('/api/orders/:id/status', authenticateToken, requireAdmin, handleOrderStatusUpdate);

  // Blogs: List
  app.get('/api/blogs', (req, res) => {
    return res.json(db.getBlogs());
  });

  // Blogs: Single
  app.get('/api/blogs/:id', (req, res) => {
    const blog = db.getBlogById(req.params.id);
    if (!blog) return res.status(404).json({ error: 'Blog post not found' });
    return res.json(blog);
  });

  // Blogs: Create (Admin)
  app.post('/api/admin/blogs', authenticateToken, requireAdmin, (req, res) => {
    const { title, excerpt, content, author, category, image, readTime, slug, tags } = req.body;
    if (!title || !content) {
      return res.status(400).json({ error: 'Title and Content are required' });
    }
    const newBlog = db.addBlog({
      title,
      slug: slug || title.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, ''),
      excerpt: excerpt || (content.length > 120 ? content.slice(0, 120) + '...' : content),
      content,
      author: author || 'Admin Kashem',
      category: category || 'Organic Living',
      image: image || 'https://images.unsplash.com/photo-1542838132-92c53300491e?auto=format&fit=crop&w=800&q=80',
      readTime: readTime || '3 min read',
      date: new Date().toISOString().split('T')[0],
      tags: tags || ['organic', 'health']
    });
    return res.status(201).json(newBlog);
  });

  // Blogs: Update/Edit (Admin)
  const handleBlogUpdate = (req: AuthenticatedRequest, res: express.Response) => {
    const updated = db.updateBlog(req.params.id, req.body);
    if (!updated) return res.status(404).json({ error: 'Blog not found' });
    return res.json(updated);
  };
  app.put('/api/admin/blogs/:id', authenticateToken, requireAdmin, handleBlogUpdate);
  app.patch('/api/admin/blogs/:id', authenticateToken, requireAdmin, handleBlogUpdate);
  app.put('/api/blogs/:id', authenticateToken, requireAdmin, handleBlogUpdate);

  // Blogs: Delete (Admin)
  const handleBlogDelete = (req: AuthenticatedRequest, res: express.Response) => {
    const deleted = db.deleteBlog(req.params.id);
    if (!deleted) return res.status(404).json({ error: 'Blog not found' });
    return res.json({ message: 'Blog deleted successfully' });
  };
  app.delete('/api/admin/blogs/:id', authenticateToken, requireAdmin, handleBlogDelete);
  app.delete('/api/blogs/:id', authenticateToken, requireAdmin, handleBlogDelete);

  // Contact Message Submit
  app.post('/api/contact', (req, res) => {
    const { name, email, phone, subject, message } = req.body;
    if (!name || !email || !message) {
      return res.status(400).json({ error: 'Name, Email and Message are required' });
    }

    const msg = db.addContactMessage({ name, email, phone: phone || '', subject: subject || 'General Query', message });
    return res.status(201).json({ message: 'Thank you for reaching out! We will contact you soon.', data: msg });
  });

  // Newsletter Subscription
  app.post('/api/newsletter', (req, res) => {
    const { email } = req.body;
    if (!email) return res.status(400).json({ error: 'Email address is required' });

    db.addNewsletter(email);
    return res.json({ message: 'Successfully subscribed to Organic Mart newsletter!' });
  });

  // Admin Analytics Dashboard Data
  app.get('/api/admin/analytics', authenticateToken, requireAdmin, (req, res) => {
    const orders = db.getOrders();
    const products = db.getProducts();

    const validOrders = orders.filter(o => o.status?.toLowerCase() !== 'cancelled');
    const cancelledOrders = orders.filter(o => o.status?.toLowerCase() === 'cancelled');

    const totalRevenue = validOrders.reduce((sum, o) => sum + (o.grandTotal || 0), 0);
    const cancelledRevenue = cancelledOrders.reduce((sum, o) => sum + (o.grandTotal || 0), 0);

    const todayStr = new Date().toISOString().split('T')[0];
    const todayOrders = orders.filter(o => o.createdAt.startsWith(todayStr));
    const todaySales = todayOrders
      .filter(o => o.status?.toLowerCase() !== 'cancelled')
      .reduce((sum, o) => sum + (o.grandTotal || 0), 0);

    const monthlySales = totalRevenue;

    const users = db.getUsers();
    const nonAdminUsers = users.filter(u => u.role !== 'admin');
    const customerIdentifiers = new Set<string>();

    nonAdminUsers.forEach(u => {
      if (u.email && u.email.trim()) customerIdentifiers.add(u.email.toLowerCase().trim());
      else if (u.phone && u.phone.trim()) customerIdentifiers.add(u.phone.trim());
      else customerIdentifiers.add(u.id);
    });

    orders.forEach(o => {
      if (o.customerEmail && o.customerEmail.trim()) {
        customerIdentifiers.add(o.customerEmail.toLowerCase().trim());
      } else if (o.customerPhone && o.customerPhone.trim()) {
        customerIdentifiers.add(o.customerPhone.trim());
      } else if (o.userId) {
        customerIdentifiers.add(o.userId);
      }
    });

    const totalCustomers = customerIdentifiers.size;

    return res.json({
      todaySales,
      monthlySales,
      totalOrders: orders.length,
      validOrdersCount: validOrders.length,
      cancelledOrdersCount: cancelledOrders.length,
      cancelledRevenue,
      totalRevenue,
      totalVisitors: 14250,
      activeProducts: products.length,
      totalCustomers,
      recentOrders: orders.slice(0, 5),
      salesByMonth: [
        { month: 'Oct', sales: 125000 },
        { month: 'Nov', sales: 168000 },
        { month: 'Dec', sales: 210000 },
        { month: 'Jan', sales: 245000 },
        { month: 'Feb', sales: 289000 }
      ]
    });
  });

  // Store Settings (Public & Admin)
  app.get('/api/settings', (req, res) => {
    return res.json(db.getSettings());
  });

  app.put('/api/admin/settings', authenticateToken, requireAdmin, (req, res) => {
    const updated = db.updateSettings(req.body);
    return res.json(updated);
  });

  // Admin Contact Messages
  app.get('/api/admin/messages', authenticateToken, requireAdmin, (req, res) => {
    return res.json(db.getContactMessages());
  });

  app.delete('/api/admin/messages/:id', authenticateToken, requireAdmin, (req, res) => {
    const deleted = db.deleteContactMessage(req.params.id);
    if (!deleted) return res.status(404).json({ error: 'Message not found' });
    return res.json({ message: 'Message deleted successfully' });
  });

  // --- VITE / STATIC SERVING ---
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Organic Mart Server running on http://localhost:${PORT}`);
  });
}

startServer();
