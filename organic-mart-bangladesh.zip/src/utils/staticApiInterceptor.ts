import { Product, Category, BlogPost, Order, Coupon, ContactMessage, StoreSettings, User } from '../types';

// Seed Data for Static Hosting (Netlify, Vercel, GitHub Pages, etc.)
const initialCategories: Category[] = [
  {
    id: 'vegetables',
    name: 'Organic Vegetables',
    bnName: 'জৈব শাক-সবজি',
    icon: 'Carrot',
    image: 'https://images.unsplash.com/photo-1540420773420-3366772f4999?w=600&auto=format&fit=crop&q=80',
    description: 'Fresh pesticide-free organic vegetables directly harvested from rural Bangladeshi partner farms.',
    itemCount: 24
  },
  {
    id: 'fruits',
    name: 'Organic Fruits',
    bnName: 'অর্গানিক ফলমূল',
    icon: 'Apple',
    image: 'https://images.unsplash.com/photo-1610832958506-aa56368176cf?w=600&auto=format&fit=crop&q=80',
    description: 'Chemical-free fresh organic fruits from Rajshahi, Dinajpur, and Sylhet orchards.',
    itemCount: 18
  },
  {
    id: 'rice',
    name: 'Organic Rice',
    bnName: 'দেশি ও সুগন্ধি চাল',
    icon: 'Wheat',
    image: 'https://images.unsplash.com/photo-1586201375761-83865001e31c?w=600&auto=format&fit=crop&q=80',
    description: 'Unpolished traditional red rice, aromatic Kalijira, Chinigura, and Nazirshail.',
    itemCount: 12
  },
  {
    id: 'honey',
    name: 'Organic Honey',
    bnName: 'সুন্দরবনের খাঁটি মধু',
    icon: 'Droplets',
    image: 'https://images.unsplash.com/photo-1587049352846-4a222e784d38?w=600&auto=format&fit=crop&q=80',
    description: '100% pure raw Sundarban wildflower and mustard honey collected by Moumachi honey hunters.',
    itemCount: 8
  },
  {
    id: 'tea',
    name: 'Organic Tea',
    bnName: 'শ্রীমঙ্গলের চা',
    icon: 'Coffee',
    image: 'https://images.unsplash.com/photo-1576092768241-dec231879fc3?w=600&auto=format&fit=crop&q=80',
    description: 'Handpicked organic black tea, green tea with tulsi, and herbal teas from Sreemangal tea estates.',
    itemCount: 10
  },
  {
    id: 'oil',
    name: 'Organic Oil',
    bnName: 'ঘানি ভাঙা খাঁটি তেল',
    icon: 'Container',
    image: 'https://images.unsplash.com/photo-1474979266404-7eaacbcd87c5?w=600&auto=format&fit=crop&q=80',
    description: 'Cold-pressed Ghani mustard oil, virgin coconut oil, and organic sesame oil.',
    itemCount: 9
  },
  {
    id: 'spices',
    name: 'Organic Spices',
    bnName: 'অর্গানিক মশলা',
    icon: 'Flame',
    image: 'https://images.unsplash.com/photo-1596040033229-a9821ebd058d?w=600&auto=format&fit=crop&q=80',
    description: 'Stone-ground turmeric, red chili, cumin, coriander, and homemade garama masala powders.',
    itemCount: 15
  },
  {
    id: 'milk-eggs',
    name: 'Organic Milk & Eggs',
    bnName: 'খামারের দুধ ও ডিম',
    icon: 'Egg',
    image: 'https://images.unsplash.com/photo-1550583724-b2692b85b150?w=600&auto=format&fit=crop&q=80',
    description: 'Pure grass-fed cow milk and free-range native chicken eggs (Deshi Dimer Hali).',
    itemCount: 6
  },
  {
    id: 'dry-fruits',
    name: 'Dry Fruits & Nuts',
    bnName: 'ড্রাই ফ্রুটস ও বাদাম',
    icon: 'Nut',
    image: 'https://images.unsplash.com/photo-1599599810769-bcde5a160d32?w=600&auto=format&fit=crop&q=80',
    description: 'Premium Iranian dates, organic almonds, cashew nuts, walnuts, and dried berries.',
    itemCount: 14
  },
  {
    id: 'snacks',
    name: 'Organic Snacks',
    bnName: 'অর্গানিক স্ন্যাকস',
    icon: 'Cookie',
    image: 'https://images.unsplash.com/photo-1558961363-fa8fdf82db35?w=600&auto=format&fit=crop&q=80',
    description: 'Traditional handmade rice crackers, puffed rice (Muri), date jaggery cookies, and handmade Chanachur.',
    itemCount: 11
  },
  {
    id: 'health',
    name: 'Health & Wellness',
    bnName: 'স্বাস্থ্যসুরক্ষা সামগ্রী',
    icon: 'Heart',
    image: 'https://images.unsplash.com/photo-1512069772995-ec65ed45afd6?w=600&auto=format&fit=crop&q=80',
    description: 'Black seed oil (Kalojira Tael), Chia seeds, Spirulina, Moringa leaf powder, and Triphala.',
    itemCount: 16
  }
];

const initialProducts: Product[] = [
  {
    id: 'prod-001',
    name: 'Pure Sundarban Wild Honey (সুন্দরবনের প্রাকৃতিক মধু)',
    sku: 'OMB-HNY-001',
    categoryId: 'honey',
    categoryName: 'Organic Honey',
    brand: 'Sundarban Natural',
    price: 950,
    discountPrice: 850,
    discountPercent: 10,
    rating: 4.9,
    reviewCount: 128,
    stock: 45,
    unit: '500g',
    images: [
      'https://images.unsplash.com/photo-1587049352846-4a222e784d38?w=800&auto=format&fit=crop&q=80',
      'https://images.unsplash.com/photo-1558642452-9d2a7deb7f62?w=800&auto=format&fit=crop&q=80'
    ],
    featured: true,
    bestSeller: true,
    todayDeal: true,
    description: '100% pure, raw, unfiltered natural honey collected directly from deep mangrove forests of Sundarbans by experienced Moumachi honey hunters. Rich in natural antioxidants, enzymes, and immune-boosting nutrients.',
    ingredients: ['100% Raw Mangrove Wild Honey'],
    benefits: ['Boosts Immunity System', 'Soothes Sore Throat & Cough', 'Natural Energy Booster', 'Aids Digestion'],
    nutrition: { Energy: '304 kcal per 100g', Sugars: '82g', Potassium: '52mg', VitaminC: '0.5mg' },
    createdAt: '2026-01-10T10:00:00.000Z'
  },
  {
    id: 'prod-002',
    name: 'Traditional Cold Pressed Kachi Ghani Mustard Oil (কাঠের ঘানি ভাঙা সরিষার তেল)',
    sku: 'OMB-OIL-002',
    categoryId: 'oil',
    categoryName: 'Organic Oil',
    brand: 'Pure Farm BD',
    price: 360,
    discountPrice: 320,
    discountPercent: 11,
    rating: 4.8,
    reviewCount: 94,
    stock: 80,
    unit: '1 Liter',
    images: [
      'https://images.unsplash.com/photo-1474979266404-7eaacbcd87c5?w=800&auto=format&fit=crop&q=80'
    ],
    featured: true,
    bestSeller: true,
    todayDeal: false,
    description: 'Extracted slowly in traditional wooden Ghani at low temperature to retain full aroma, pungent flavor, and essential fatty acids. Perfect for authentic Bangladeshi curries, bhorta, and pickling.',
    ingredients: ['100% Pure Organic Maghi Mustard Seeds'],
    benefits: ['Rich in Omega-3 & Omega-6 Fatty Acids', 'Promotes Heart Health', 'Pungent Traditional Aroma', 'Zero Preservatives'],
    nutrition: { Energy: '884 kcal per 100ml', PolyunsaturatedFat: '21g', MonounsaturatedFat: '59g' },
    createdAt: '2026-01-12T10:00:00.000Z'
  },
  {
    id: 'prod-003',
    name: 'Premium Kalijira Aromatic Rice (সুগন্ধি কালিজিরা চাল)',
    sku: 'OMB-RICE-003',
    categoryId: 'rice',
    categoryName: 'Organic Rice',
    brand: 'Sherpur Organic',
    price: 180,
    discountPrice: 165,
    discountPercent: 8,
    rating: 4.9,
    reviewCount: 76,
    stock: 120,
    unit: '1 kg',
    images: [
      'https://images.unsplash.com/photo-1586201375761-83865001e31c?w=800&auto=format&fit=crop&q=80'
    ],
    featured: true,
    bestSeller: true,
    todayDeal: true,
    description: 'Fragrant small-grain Bangladeshi aromatic rice grown naturally in Sherpur without chemical fertilizers. Ideal for preparing mouth-watering Biryani, Polao, Firni, and Payesh.',
    ingredients: ['100% Organic Kalijira Rice'],
    benefits: ['Subtle Natural Aroma', 'Non-GMO & Pesticide Free', 'Easy to Digest', 'Perfect for Festive Dishes'],
    nutrition: { Carbs: '78g per 100g', Protein: '7.5g', Fiber: '1.2g' },
    createdAt: '2026-01-15T10:00:00.000Z'
  },
  {
    id: 'prod-004',
    name: 'Organic Red Rice / Lal Chawl (দেশি লাল চাল)',
    sku: 'OMB-RICE-004',
    categoryId: 'rice',
    categoryName: 'Organic Rice',
    brand: 'Natore Organic',
    price: 130,
    discountPrice: 120,
    discountPercent: 7,
    rating: 4.7,
    reviewCount: 42,
    stock: 60,
    unit: '1 kg',
    images: [
      'https://images.unsplash.com/photo-1536304993881-ff6e9eefa2a6?w=800&auto=format&fit=crop&q=80'
    ],
    featured: false,
    bestSeller: false,
    todayDeal: false,
    seasonal: true,
    description: 'Unpolished traditional red paddy rice loaded with fiber, minerals, and antioxidants. Recommended by nutritionists for diabetes management and weight loss.',
    ingredients: ['100% Unpolished Organic Red Rice'],
    benefits: ['Low Glycemic Index', 'High Dietary Fiber', 'Rich in Iron & Manganese'],
    nutrition: { Fiber: '3.5g per 100g', Protein: '8.1g', Iron: '1.8mg' },
    createdAt: '2026-01-18T10:00:00.000Z'
  },
  {
    id: 'prod-005',
    name: 'Organic Turmeric Powder / Stone Ground Halud (খাঁটি গুঁড়া হলুদ)',
    sku: 'OMB-SPC-005',
    categoryId: 'spices',
    categoryName: 'Organic Spices',
    brand: 'Pabna Organic Spices',
    price: 150,
    discountPrice: 135,
    discountPercent: 10,
    rating: 4.8,
    reviewCount: 65,
    stock: 90,
    unit: '250g',
    images: [
      'https://images.unsplash.com/photo-1615485290382-441e4d049cb5?w=800&auto=format&fit=crop&q=80'
    ],
    featured: true,
    bestSeller: false,
    todayDeal: true,
    description: 'High-curcumin native turmeric naturally sun-dried and traditional mill ground. No artificial food coloring, lead chromate, or adulterants.',
    ingredients: ['100% Pure Sun-Dried Organic Turmeric Root'],
    benefits: ['High Natural Curcumin Content', 'Powerful Anti-inflammatory', 'Natural Golden Color'],
    nutrition: { Curcumin: '3.8%', Iron: '41mg per 100g' },
    createdAt: '2026-01-20T10:00:00.000Z'
  },
  {
    id: 'prod-006',
    name: 'Sreemangal Premium Organic Black Tea (শ্রীমঙ্গলের প্রিমিয়াম চা)',
    sku: 'OMB-TEA-006',
    categoryId: 'tea',
    categoryName: 'Organic Tea',
    brand: 'Sreemangal Estates',
    price: 280,
    discountPrice: 250,
    discountPercent: 11,
    rating: 4.9,
    reviewCount: 88,
    stock: 75,
    unit: '400g',
    images: [
      'https://images.unsplash.com/photo-1576092768241-dec231879fc3?w=800&auto=format&fit=crop&q=80'
    ],
    featured: true,
    bestSeller: true,
    todayDeal: false,
    description: 'Single-estate handpicked whole leaf tea from tea gardens of Sreemangal, Moulvibazar. Produces a brisk, aromatic liquor with rich liquor depth.',
    ingredients: ['100% Organic Black Tea Leaves'],
    benefits: ['Rich Antioxidants', 'Refreshes Mind & Body', 'Zero Chemical Pesticides'],
    createdAt: '2026-01-22T10:00:00.000Z'
  },
  {
    id: 'prod-007',
    name: 'Rajshahi Amrapali Mango (রাজশাহীর আম্রপালি আম)',
    sku: 'OMB-FRT-007',
    categoryId: 'fruits',
    categoryName: 'Organic Fruits',
    brand: 'Rajshahi Orchard',
    price: 650,
    discountPrice: 580,
    discountPercent: 10,
    rating: 5.0,
    reviewCount: 140,
    stock: 30,
    unit: '5 kg Box',
    images: [
      'https://images.unsplash.com/photo-1553279768-865429fa0078?w=800&auto=format&fit=crop&q=80'
    ],
    featured: true,
    bestSeller: true,
    todayDeal: true,
    seasonal: true,
    description: 'Naturally tree-ripened formal chemical-free Amrapali mangoes from Rajshahi. Sweet, fibreless, aromatic, and free from formalin or calcium carbide.',
    ingredients: ['100% Chemical Free Fresh Mangoes'],
    benefits: ['Zero Formalin Guaranteed', 'Naturally Tree Ripened', 'Rich in Vitamin C & A'],
    createdAt: '2026-01-25T10:00:00.000Z'
  },
  {
    id: 'prod-008',
    name: 'Organic Black Seed Oil / Kalojira Tael (খাঁটি কালোজিরা তেল)',
    sku: 'OMB-HLT-008',
    categoryId: 'health',
    categoryName: 'Health & Wellness',
    brand: 'Organic Cure',
    price: 450,
    discountPrice: 400,
    discountPercent: 11,
    rating: 4.9,
    reviewCount: 110,
    stock: 55,
    unit: '200ml',
    images: [
      'https://images.unsplash.com/photo-1608571423902-eed4a5ad8108?w=800&auto=format&fit=crop&q=80'
    ],
    featured: true,
    bestSeller: true,
    todayDeal: false,
    description: 'Cold pressed 100% pure Nigella Sativa oil (Kalojira). Known in traditional herbal wellness as a natural remedy for immune strength, hair growth, and joint vitality.',
    ingredients: ['100% Cold Pressed Organic Black Seeds'],
    benefits: ['Known as "Medicine for All Diseases"', 'Boosts Natural Immunity', 'Promotes Healthy Hair & Skin'],
    createdAt: '2026-01-28T10:00:00.000Z'
  },
  {
    id: 'prod-009',
    name: 'Premium Ajwa Dates from Madinah (মদিনার প্রিমিয়াম আজওয়া খেজুর)',
    sku: 'OMB-DRY-009',
    categoryId: 'dry-fruits',
    categoryName: 'Dry Fruits & Nuts',
    brand: 'Madinah Imports',
    price: 1200,
    discountPrice: 1050,
    discountPercent: 12,
    rating: 4.9,
    reviewCount: 95,
    stock: 40,
    unit: '500g',
    images: [
      'https://images.unsplash.com/photo-1599599810769-bcde5a160d32?w=800&auto=format&fit=crop&q=80'
    ],
    featured: true,
    bestSeller: false,
    todayDeal: true,
    description: 'Authentic Ajwa dates imported directly from Madinah Munawwarah. Soft, rich dark texture with high fiber, iron, and mineral content.',
    ingredients: ['100% Pure Ajwa Dates'],
    benefits: ['Natural Energy Supply', 'Supports Heart Function', 'Rich in Potassium & Fiber'],
    createdAt: '2026-02-01T10:00:00.000Z'
  },
  {
    id: 'prod-010',
    name: 'Organic Chia Seeds (অর্গানিক চিয়া সিড)',
    sku: 'OMB-HLT-010',
    categoryId: 'health',
    categoryName: 'Health & Wellness',
    brand: 'Superfood Organic',
    price: 350,
    discountPrice: 310,
    discountPercent: 11,
    rating: 4.8,
    reviewCount: 52,
    stock: 70,
    unit: '250g',
    images: [
      'https://images.unsplash.com/photo-1512069772995-ec65ed45afd6?w=800&auto=format&fit=crop&q=80'
    ],
    featured: false,
    bestSeller: false,
    todayDeal: false,
    newArrival: true,
    description: 'Premium organic black chia seeds harvested under strictly controlled organic standards. High in soluble fiber, Omega-3 fatty acids, and protein.',
    ingredients: ['100% Raw Organic Chia Seeds'],
    benefits: ['Aids Weight Loss Management', 'Improves Digestion', 'Great for Smoothies & Water'],
    createdAt: '2026-02-05T10:00:00.000Z'
  },
  {
    id: 'prod-011',
    name: 'Free Range Native Chicken Eggs (দেশি মুরগির ডিম - ১ হালি)',
    sku: 'OMB-EGGS-011',
    categoryId: 'milk-eggs',
    categoryName: 'Organic Milk & Eggs',
    brand: 'Village Farm',
    price: 85,
    discountPrice: 75,
    discountPercent: 12,
    rating: 4.9,
    reviewCount: 62,
    stock: 100,
    unit: '4 Pcs (1 Hali)',
    images: [
      'https://images.unsplash.com/photo-1582721478779-0ae163c05a60?w=800&auto=format&fit=crop&q=80'
    ],
    featured: false,
    bestSeller: true,
    todayDeal: false,
    description: 'Fresh free-range native chicken eggs (Deshi Dimer Hali) raised naturally on grains and natural foraging. Deep yellow yolk rich in natural Vitamin D.',
    ingredients: ['100% Organic Native Eggs'],
    benefits: ['Natural Deep Golden Yolk', 'No Antibiotic Residues', 'High Protein & Vitamin B12'],
    createdAt: '2026-02-08T10:00:00.000Z'
  },
  {
    id: 'prod-012',
    name: 'Organic Red Chili Powder / Marich (খাঁটি লাল মরিচ গুঁড়া)',
    sku: 'OMB-SPC-012',
    categoryId: 'spices',
    categoryName: 'Organic Spices',
    brand: 'Pabna Organic Spices',
    price: 160,
    discountPrice: 140,
    discountPercent: 12,
    rating: 4.7,
    reviewCount: 38,
    stock: 85,
    unit: '250g',
    images: [
      'https://images.unsplash.com/photo-1596040033229-a9821ebd058d?w=800&auto=format&fit=crop&q=80'
    ],
    featured: false,
    bestSeller: false,
    todayDeal: false,
    description: 'Natural sun-dried chili ground without artificial dye, oil polishing, or brick powder. Vibrant color and rich spicy kick.',
    ingredients: ['100% Dried Organic Red Chilis'],
    benefits: ['Natural Red Color', 'Rich Spicy Flavor', 'No Artificial Dyes'],
    createdAt: '2026-02-10T10:00:00.000Z'
  }
];

const initialBlogs: BlogPost[] = [
  {
    id: 'blog-001',
    title: 'Why Switching to Pure Sundarban Honey Can Transform Your Health',
    slug: 'benefits-of-pure-sundarban-honey',
    excerpt: 'Discover why unadulterated mangrove wild honey from Sundarbans is a powerhouse of natural enzymes and immune protection.',
    content: `Organic Sundarban honey is collected directly from mangrove trees by Moumachi honey hunters. Unlike processed commercial honey which is pasteurized and stripped of pollen, raw Sundarban honey retains anti-bacterial propolis, active royal jelly traces, and natural antioxidants.

### Key Health Benefits:
1. **Immune System Defense**: Daily spoonfuls with warm water and lemon boost your natural resistance against seasonal viral flu.
2. **Natural Digestive Aid**: Enzymes ease bloating and soothe acidity after heavy meals.
3. **Natural Energy**: Rich in fructose and glucose without spikes in refined sugar level.

Always ensure your honey passes the water purity test and comes with organic sourcing assurance!`,
    author: 'Dr. Amena Begum (Nutritionist)',
    category: 'Health & Wellness',
    image: 'https://images.unsplash.com/photo-1587049352846-4a222e784d38?w=800&auto=format&fit=crop&q=80',
    readTime: '4 min read',
    date: '2026-02-12',
    tags: ['Organic Honey', 'Health Tips', 'Sundarban']
  },
  {
    id: 'blog-002',
    title: 'The Dangers of Chemical Adulteration in Cooking Oils & Why Cold Pressed Kachi Ghani Matters',
    slug: 'cold-pressed-mustard-oil-benefits',
    excerpt: 'How refined chemical extraction destroys mustard oil nutrition and why traditional wooden ghani pressing preserves heart health.',
    content: `Traditional Bangladeshi cuisine heavily relies on mustard oil for its signature pungent punch and rich flavor. However, industrial solvent extractions use hexane chemicals and extreme temperatures above 200°C, oxidizing beneficial fats.

### Why Kachi Ghani Wood Pressing is Superior:
- **Low Temperature Processing**: Kept below 45°C, maintaining natural Allyl Isothiocyanate compound.
- **Natural Heart Protection**: Balanced ratio of Omega-3 and Omega-6 fatty acids lowers bad LDL cholesterol.
- **Pure Flavor**: Unfiltered, rich, and aromatic without synthetic chemical bleaching.`,
    author: 'Kabir Hossain (Food Tech Expert)',
    category: 'Organic Food',
    image: 'https://images.unsplash.com/photo-1474979266404-7eaacbcd87c5?w=800&auto=format&fit=crop&q=80',
    readTime: '5 min read',
    date: '2026-02-15',
    tags: ['Mustard Oil', 'Kachi Ghani', 'Heart Health']
  },
  {
    id: 'blog-003',
    title: 'Top 5 Traditional Bangladeshi Organic Rice Varieties You Must Try',
    slug: 'traditional-bangladeshi-organic-rice-varieties',
    excerpt: 'From fragrant Kalijira to nutrient-dense Lal Chawl, explore Bangladesh\'s rich heirloom rice heritage.',
    content: `Bangladesh is home to hundreds of indigenous rice varieties. Modern hybrid polished rice loses up to 80% of its outer bran vitamins. By switching to heirloom organic grains, you nourish your family with unpolished wholesome goodness.

1. **Kalijira Rice**: Small aromatic grain ideal for Polao and Firni.
2. **Red Rice (Lal Chawl)**: Unpolished with natural anthocyanin pigments.
3. **Chinigura Rice**: Delicately scented rice for festive Biryani.`,
    author: 'Farhana Sharmin',
    category: 'Recipes & Food',
    image: 'https://images.unsplash.com/photo-1586201375761-83865001e31c?w=800&auto=format&fit=crop&q=80',
    readTime: '6 min read',
    date: '2026-02-18',
    tags: ['Kalijira', 'Red Rice', 'Organic Food']
  }
];

const initialCoupons: Coupon[] = [
  {
    code: 'ORGANIC20',
    discountType: 'percent',
    discountValue: 20,
    minSpend: 1000,
    maxDiscount: 500,
    expiryDate: '2026-12-31',
    active: true
  },
  {
    code: 'FRESH100',
    discountType: 'fixed',
    discountValue: 100,
    minSpend: 500,
    expiryDate: '2026-12-31',
    active: true
  },
  {
    code: 'EID500',
    discountType: 'fixed',
    discountValue: 500,
    minSpend: 3000,
    expiryDate: '2026-12-31',
    active: true
  }
];

const initialOrders: Order[] = [
  {
    id: 'OMB-2026-8941',
    userId: 'user-002',
    customerName: 'Tanvir Ahmed',
    customerEmail: 'tanvir.ahmed@example.com',
    customerPhone: '01712345678',
    shippingAddress: {
      id: 'addr-01',
      fullName: 'Tanvir Ahmed',
      phone: '01712345678',
      division: 'Dhaka',
      district: 'Dhaka',
      thana: 'Gulshan',
      address: 'House 42, Road 11, Block D, Gulshan 1, Dhaka'
    },
    items: [
      {
        productId: 'prod-001',
        name: 'Pure Sundarban Wild Honey',
        price: 850,
        quantity: 1,
        image: 'https://images.unsplash.com/photo-1587049352846-4a222e784d38?w=800&auto=format&fit=crop&q=80',
        unit: '500g'
      },
      {
        productId: 'prod-003',
        name: 'Premium Kalijira Aromatic Rice',
        price: 165,
        quantity: 2,
        image: 'https://images.unsplash.com/photo-1586201375761-83865001e31c?w=800&auto=format&fit=crop&q=80',
        unit: '1 kg'
      }
    ],
    subtotal: 1180,
    discount: 100,
    couponCode: 'FRESH100',
    shippingCharge: 70,
    tax: 0,
    grandTotal: 1150,
    paymentMethod: 'bkash',
    paymentStatus: 'Paid',
    transactionId: 'BKASH9823X1',
    status: 'Shipped',
    statusHistory: [
      { status: 'Pending', timestamp: '2026-02-19T09:00:00.000Z', note: 'Order placed by customer' },
      { status: 'Confirmed', timestamp: '2026-02-19T09:30:00.000Z', note: 'Payment verified via bKash' },
      { status: 'Packed', timestamp: '2026-02-19T11:15:00.000Z', note: 'Items packed in eco-friendly boxes' },
      { status: 'Shipped', timestamp: '2026-02-19T14:20:00.000Z', note: 'Handed over to Pathao Express Courier' }
    ],
    deliveryCourier: 'Pathao Express',
    trackingNumber: 'PTH-889123',
    createdAt: '2026-02-19T09:00:00.000Z',
    updatedAt: '2026-02-19T14:20:00.000Z'
  }
];

const initialSettings: StoreSettings = {
  insideDhakaFee: 70,
  outsideDhakaFee: 130,
  freeShippingMin: 2000
};

// Storage helper functions
function getStorage<T>(key: string, defaultValue: T): T {
  try {
    const data = localStorage.getItem(key);
    if (!data) {
      localStorage.setItem(key, JSON.stringify(defaultValue));
      return defaultValue;
    }
    const parsed = JSON.parse(data);
    if (Array.isArray(defaultValue) && (!Array.isArray(parsed) || parsed.length === 0)) {
      localStorage.setItem(key, JSON.stringify(defaultValue));
      return defaultValue;
    }
    return parsed;
  } catch {
    return defaultValue;
  }
}

function setStorage<T>(key: string, value: T): void {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch (err) {
    console.error('Failed to write to localStorage', err);
  }
}

// Seed Store Data on initialization
function ensureStorageSeeded() {
  getStorage('om_categories_v3', initialCategories);
  getStorage('om_products_v3', initialProducts);
  getStorage('om_blogs_v3', initialBlogs);
  getStorage('om_coupons_v3', initialCoupons);
  getStorage('om_orders_v3', initialOrders);
  getStorage('om_settings_v3', initialSettings);
  getStorage('om_messages_v3', []);
}

ensureStorageSeeded();

// Intercept fetch calls for static / Netlify hosting
const originalFetch = window.fetch;

window.fetch = async function (input: RequestInfo | URL, init?: RequestInit): Promise<Response> {
  const urlString = typeof input === 'string' ? input : input instanceof URL ? input.toString() : input.url;

  // Intercept all /api/ requests
  if (urlString.startsWith('/api/') || urlString.includes('/api/')) {
    try {
      const response = await originalFetch(input, init);
      const contentType = response.headers.get('content-type') || '';

      // If Express backend is active and responded with valid JSON, return real response
      if (response.ok && contentType.includes('application/json')) {
        return response;
      }
    } catch {
      // Backend unreachable or static environment (e.g., Netlify)
    }

    // Handle using Client-Side LocalStorage Mock Engine
    return handleStaticApi(urlString, init);
  }

  return originalFetch(input, init);
};

async function handleStaticApi(urlString: string, init?: RequestInit): Promise<Response> {
  ensureStorageSeeded();

  const method = (init?.method || 'GET').toUpperCase();
  const urlObj = new URL(urlString, window.location.origin);
  const pathname = urlObj.pathname;
  const searchParams = urlObj.searchParams;

  let requestBody: any = null;
  if (init?.body && typeof init.body === 'string') {
    try {
      requestBody = JSON.parse(init.body);
    } catch {
      requestBody = null;
    }
  }

  // --- 1. CATEGORIES ---
  if (pathname === '/api/categories') {
    if (method === 'GET') {
      const cats: Category[] = getStorage('om_categories_v3', initialCategories);
      const prods: Product[] = getStorage('om_products_v3', initialProducts);

      const withCount = cats.map(cat => {
        const catId = (cat.id || '').toLowerCase().trim();
        const catName = (cat.name || '').toLowerCase().trim();
        const catBn = (cat.bnName || '').toLowerCase().trim();

        const count = prods.filter(p => {
          const pCatId = (p.categoryId || '').toLowerCase().trim();
          const pCatName = (p.categoryName || '').toLowerCase().trim();
          return (
            pCatId === catId ||
            pCatName === catName ||
            (pCatId && catId && pCatId.includes(catId)) ||
            (pCatName && catName && pCatName.includes(catName)) ||
            (catBn && pCatName && pCatName.includes(catBn))
          );
        }).length;

        return { ...cat, itemCount: count };
      });

      return createJsonResponse(withCount);
    }

    if (method === 'POST') {
      const cats = getStorage<Category[]>('om_categories_v3', initialCategories);
      const newCat: Category = {
        id: requestBody?.id || 'cat-' + Date.now(),
        name: requestBody?.name || 'New Category',
        bnName: requestBody?.bnName || requestBody?.name || 'নতুন ক্যাটাগরি',
        icon: requestBody?.icon || 'Leaf',
        image: requestBody?.image || 'https://images.unsplash.com/photo-1542838132-92c53300491e?w=800&auto=format&fit=crop&q=80',
        description: requestBody?.description || '',
        itemCount: 0
      };
      cats.push(newCat);
      setStorage('om_categories_v3', cats);
      return createJsonResponse(newCat, 201);
    }
  }

  if (pathname.startsWith('/api/categories/')) {
    const catId = pathname.replace('/api/categories/', '');
    const cats = getStorage<Category[]>('om_categories_v3', initialCategories);

    if (method === 'PUT' || method === 'PATCH') {
      const idx = cats.findIndex(c => c.id === catId);
      if (idx !== -1) {
        cats[idx] = { ...cats[idx], ...requestBody };
        setStorage('om_categories_v3', cats);
        return createJsonResponse(cats[idx]);
      }
      return createJsonResponse({ error: 'Category not found' }, 404);
    }

    if (method === 'DELETE') {
      const filtered = cats.filter(c => c.id !== catId);
      setStorage('om_categories_v3', filtered);
      return createJsonResponse({ message: 'Category deleted' });
    }
  }

  // --- 2. PRODUCTS ---
  if (pathname === '/api/products') {
    let prods = getStorage<Product[]>('om_products_v3', initialProducts);

    if (method === 'GET') {
      const category = searchParams.get('category');
      const search = searchParams.get('search');
      const minPrice = searchParams.get('minPrice');
      const maxPrice = searchParams.get('maxPrice');
      const sort = searchParams.get('sort');
      const featured = searchParams.get('featured');
      const bestSeller = searchParams.get('bestSeller');
      const todayDeal = searchParams.get('todayDeal');
      const seasonal = searchParams.get('seasonal');
      const newArrival = searchParams.get('newArrival');
      const brand = searchParams.get('brand');

      if (category) prods = prods.filter(p => p.categoryId === category);
      if (brand) prods = prods.filter(p => p.brand?.toLowerCase() === brand.toLowerCase());
      if (search) {
        const q = search.toLowerCase().trim();
        prods = prods.filter(p =>
          p.name.toLowerCase().includes(q) ||
          (p.bnName && p.bnName.includes(q)) ||
          p.categoryName?.toLowerCase().includes(q) ||
          p.description?.toLowerCase().includes(q)
        );
      }
      if (minPrice) prods = prods.filter(p => (p.discountPrice || p.price) >= Number(minPrice));
      if (maxPrice) prods = prods.filter(p => (p.discountPrice || p.price) <= Number(maxPrice));
      if (featured === 'true') prods = prods.filter(p => p.featured);
      if (bestSeller === 'true') prods = prods.filter(p => p.bestSeller);
      if (todayDeal === 'true') prods = prods.filter(p => p.todayDeal);
      if (seasonal === 'true') prods = prods.filter(p => p.seasonal);
      if (newArrival === 'true') prods = prods.filter(p => p.newArrival);

      if (sort === 'price-low') {
        prods.sort((a, b) => (a.discountPrice || a.price) - (b.discountPrice || b.price));
      } else if (sort === 'price-high') {
        prods.sort((a, b) => (b.discountPrice || b.price) - (a.discountPrice || a.price));
      } else if (sort === 'rating') {
        prods.sort((a, b) => b.rating - a.rating);
      } else if (sort === 'newest') {
        prods.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
      }

      return createJsonResponse({ count: prods.length, products: prods });
    }

    if (method === 'POST') {
      const newProduct: Product = {
        ...requestBody,
        id: 'prod-' + Date.now(),
        sku: requestBody?.sku || 'OMB-' + Math.floor(1000 + Math.random() * 9000),
        price: Number(requestBody?.price || 0),
        discountPrice: requestBody?.discountPrice ? Number(requestBody.discountPrice) : undefined,
        stock: Number(requestBody?.stock || 50),
        rating: 5.0,
        reviewCount: 1,
        images: requestBody?.images?.length ? requestBody.images : ['https://images.unsplash.com/photo-1540420773420-3366772f4999?w=800&auto=format&fit=crop&q=80'],
        createdAt: new Date().toISOString()
      };
      prods.unshift(newProduct);
      setStorage('om_products_v3', prods);
      return createJsonResponse(newProduct, 201);
    }
  }

  if (pathname.startsWith('/api/products/')) {
    const parts = pathname.replace('/api/products/', '').split('/');
    const prodId = parts[0];
    const subRoute = parts[1];

    let prods = getStorage<Product[]>('om_products_v3', initialProducts);

    if (subRoute === 'reviews' && method === 'POST') {
      const idx = prods.findIndex(p => p.id === prodId);
      if (idx !== -1) {
        const newReview = {
          id: 'rev-' + Date.now(),
          userName: requestBody?.userName || 'Customer',
          rating: Number(requestBody?.rating || 5),
          comment: requestBody?.comment || 'Great product!',
          date: new Date().toISOString().split('T')[0],
          verifiedPurchase: true
        };
        const existingReviews = prods[idx].reviews || [];
        existingReviews.push(newReview);
        prods[idx].reviews = existingReviews;
        prods[idx].reviewCount = existingReviews.length;
        setStorage('om_products_v3', prods);
        return createJsonResponse(newReview, 201);
      }
      return createJsonResponse({ error: 'Product not found' }, 404);
    }

    if (method === 'GET') {
      const prod = prods.find(p => p.id === prodId);
      if (prod) return createJsonResponse(prod);
      return createJsonResponse({ error: 'Product not found' }, 404);
    }

    if (method === 'PUT' || method === 'PATCH') {
      const idx = prods.findIndex(p => p.id === prodId);
      if (idx !== -1) {
        prods[idx] = { ...prods[idx], ...requestBody };
        setStorage('om_products_v3', prods);
        return createJsonResponse(prods[idx]);
      }
      return createJsonResponse({ error: 'Product not found' }, 404);
    }

    if (method === 'DELETE') {
      const filtered = prods.filter(p => p.id !== prodId);
      setStorage('om_products_v3', filtered);
      return createJsonResponse({ message: 'Product deleted successfully' });
    }
  }

  // --- 3. BLOGS ---
  if (pathname === '/api/blogs' || pathname === '/api/admin/blogs') {
    let blogs = getStorage<BlogPost[]>('om_blogs_v3', initialBlogs);

    if (method === 'GET') {
      return createJsonResponse(blogs);
    }

    if (method === 'POST') {
      const newBlog: BlogPost = {
        id: 'blog-' + Date.now(),
        title: requestBody?.title || 'New Blog Post',
        slug: requestBody?.slug || (requestBody?.title || 'post').toLowerCase().replace(/[^a-z0-9]+/g, '-'),
        excerpt: requestBody?.excerpt || 'Blog excerpt',
        content: requestBody?.content || '',
        author: requestBody?.author || 'KASHEM',
        category: requestBody?.category || 'Organic Living',
        image: requestBody?.image || 'https://images.unsplash.com/photo-1542838132-92c53300491e?auto=format&fit=crop&w=800&q=80',
        readTime: requestBody?.readTime || '3 min read',
        date: new Date().toISOString().split('T')[0],
        tags: requestBody?.tags || ['organic']
      };
      blogs.unshift(newBlog);
      setStorage('om_blogs_v3', blogs);
      return createJsonResponse(newBlog, 201);
    }
  }

  if (pathname.startsWith('/api/blogs/') || pathname.startsWith('/api/admin/blogs/')) {
    const blogId = pathname.replace('/api/admin/blogs/', '').replace('/api/blogs/', '');
    let blogs = getStorage<BlogPost[]>('om_blogs_v3', initialBlogs);

    if (method === 'GET') {
      const blog = blogs.find(b => b.id === blogId || b.slug === blogId);
      if (blog) return createJsonResponse(blog);
      return createJsonResponse({ error: 'Blog post not found' }, 404);
    }

    if (method === 'PUT' || method === 'PATCH') {
      const idx = blogs.findIndex(b => b.id === blogId || b.slug === blogId);
      if (idx !== -1) {
        blogs[idx] = { ...blogs[idx], ...requestBody };
        setStorage('om_blogs_v3', blogs);
        return createJsonResponse(blogs[idx]);
      }
      return createJsonResponse({ error: 'Blog not found' }, 404);
    }

    if (method === 'DELETE') {
      const filtered = blogs.filter(b => b.id !== blogId && b.slug !== blogId);
      setStorage('om_blogs_v3', filtered);
      return createJsonResponse({ message: 'Blog deleted successfully' });
    }
  }

  // --- 4. COUPONS ---
  if (pathname === '/api/coupons') {
    let coupons = getStorage<Coupon[]>('om_coupons_v3', initialCoupons);

    if (method === 'GET') {
      return createJsonResponse(coupons);
    }

    if (method === 'POST') {
      const newCoupon: Coupon = {
        code: requestBody?.code?.toUpperCase() || 'PROMO' + Math.floor(Math.random() * 100),
        discountType: requestBody?.discountType || 'fixed',
        discountValue: Number(requestBody?.discountValue || 100),
        minSpend: Number(requestBody?.minSpend || 500),
        maxDiscount: requestBody?.maxDiscount ? Number(requestBody.maxDiscount) : undefined,
        expiryDate: requestBody?.expiryDate || '2026-12-31',
        active: true
      };
      coupons.push(newCoupon);
      setStorage('om_coupons_v3', coupons);
      return createJsonResponse(newCoupon, 201);
    }
  }

  if (pathname === '/api/coupons/apply' && method === 'POST') {
    const coupons = getStorage<Coupon[]>('om_coupons_v3', initialCoupons);
    const code = requestBody?.code?.toUpperCase();
    const amount = Number(requestBody?.amount || 0);

    const coupon = coupons.find(c => c.code.toUpperCase() === code && c.active);
    if (!coupon) {
      return createJsonResponse({ error: 'Invalid or expired coupon code' }, 404);
    }

    if (amount < coupon.minSpend) {
      return createJsonResponse({
        error: `Minimum spend of ৳${coupon.minSpend} required for coupon ${coupon.code}`
      }, 400);
    }

    let discountAmount = 0;
    if (coupon.discountType === 'percent') {
      discountAmount = Math.round((amount * coupon.discountValue) / 100);
      if (coupon.maxDiscount && discountAmount > coupon.maxDiscount) {
        discountAmount = coupon.maxDiscount;
      }
    } else {
      discountAmount = coupon.discountValue;
    }

    return createJsonResponse({
      valid: true,
      code: coupon.code,
      discountAmount,
      coupon
    });
  }

  if (pathname.startsWith('/api/coupons/') && method === 'DELETE') {
    const codeOrId = pathname.replace('/api/coupons/', '');
    let coupons = getStorage<Coupon[]>('om_coupons_v3', initialCoupons);
    const filtered = coupons.filter(c => c.code !== codeOrId);
    setStorage('om_coupons_v3', filtered);
    return createJsonResponse({ message: 'Coupon deleted' });
  }

  // --- 5. ORDERS ---
  if (pathname === '/api/orders') {
    let orders = getStorage<Order[]>('om_orders_v3', initialOrders);

    if (method === 'GET') {
      const phone = searchParams.get('phone');
      if (phone) {
        orders = orders.filter(o => o.customerPhone === phone);
      }
      return createJsonResponse(orders);
    }

    if (method === 'POST') {
      const orderId = 'OMB-2026-' + Math.floor(1000 + Math.random() * 9000);
      const newOrder: Order = {
        ...requestBody,
        id: orderId,
        status: 'Pending',
        paymentStatus: requestBody?.paymentMethod === 'cod' ? 'Pending' : 'Paid',
        statusHistory: [
          {
            status: 'Pending',
            timestamp: new Date().toISOString(),
            note: `Order placed via ${requestBody?.paymentMethod?.toUpperCase() || 'COD'}`
          }
        ],
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };

      orders.unshift(newOrder);
      setStorage('om_orders_v3', orders);
      return createJsonResponse(newOrder, 201);
    }
  }

  if (pathname.startsWith('/api/orders/track/')) {
    const query = pathname.replace('/api/orders/track/', '').trim();
    const orders = getStorage<Order[]>('om_orders_v3', initialOrders);
    const found = orders.find(o => o.id === query || o.customerPhone === query);
    if (found) return createJsonResponse(found);
    return createJsonResponse({ error: 'Order not found' }, 404);
  }

  if (pathname.startsWith('/api/orders/') && pathname.endsWith('/status')) {
    const orderId = pathname.replace('/api/orders/', '').replace('/status', '');
    let orders = getStorage<Order[]>('om_orders_v3', initialOrders);
    const idx = orders.findIndex(o => o.id === orderId);
    if (idx !== -1) {
      const nextStatus = requestBody?.status;
      const note = requestBody?.note || `Status updated to ${nextStatus}`;

      orders[idx].status = nextStatus;
      orders[idx].updatedAt = new Date().toISOString();
      orders[idx].statusHistory = orders[idx].statusHistory || [];
      orders[idx].statusHistory.push({
        status: nextStatus,
        timestamp: new Date().toISOString(),
        note
      });

      setStorage('om_orders_v3', orders);
      return createJsonResponse(orders[idx]);
    }
    return createJsonResponse({ error: 'Order not found' }, 404);
  }

  // --- 6. STORE SETTINGS ---
  if (pathname === '/api/settings') {
    let settings = getStorage<StoreSettings>('om_settings_v3', initialSettings);
    if (method === 'GET') {
      return createJsonResponse(settings);
    }
    if (method === 'PUT' || method === 'POST') {
      settings = { ...settings, ...requestBody };
      setStorage('om_settings_v3', settings);
      return createJsonResponse(settings);
    }
  }

  // --- 7. ADMIN ANALYTICS ---
  if (pathname === '/api/admin/analytics') {
    const orders = getStorage<Order[]>('om_orders_v3', initialOrders);
    const prods = getStorage<Product[]>('om_products_v3', initialProducts);

    const validOrders = orders.filter(o => o.status?.toLowerCase() !== 'cancelled');
    const totalRevenue = validOrders.reduce((sum, o) => sum + (o.grandTotal || 0), 0);

    const todayStr = new Date().toISOString().split('T')[0];
    const todaySales = orders
      .filter(o => o.createdAt.startsWith(todayStr) && o.status?.toLowerCase() !== 'cancelled')
      .reduce((sum, o) => sum + (o.grandTotal || 0), 0);

    return createJsonResponse({
      todaySales,
      monthlySales: totalRevenue,
      totalOrders: orders.length,
      totalRevenue,
      totalVisitors: 1420,
      activeProducts: prods.length,
      totalCustomers: new Set(orders.map(o => o.customerPhone)).size || 1,
      recentOrders: orders.slice(0, 10),
      topSellingProducts: prods.slice(0, 5).map(p => ({
        product: p,
        totalQuantitySold: Math.floor(Math.random() * 50) + 10,
        totalRevenue: p.price * 15
      })),
      salesByMonth: [
        { month: 'Jan', sales: 12000 },
        { month: 'Feb', sales: 28000 },
        { month: 'Mar', sales: totalRevenue || 35000 }
      ]
    });
  }

  // --- 8. CONTACT & NEWSLETTER ---
  if (pathname === '/api/contact' && method === 'POST') {
    const msgs = getStorage<ContactMessage[]>('om_messages_v3', []);
    const newMsg: ContactMessage = {
      id: 'msg-' + Date.now(),
      name: requestBody?.name || '',
      email: requestBody?.email || '',
      phone: requestBody?.phone || '',
      subject: requestBody?.subject || 'General Inquiry',
      message: requestBody?.message || '',
      date: new Date().toISOString(),
      read: false
    };
    msgs.unshift(newMsg);
    setStorage('om_messages_v3', msgs);
    return createJsonResponse({ message: 'Thank you for your message!', data: newMsg });
  }

  if (pathname === '/api/newsletter' && method === 'POST') {
    return createJsonResponse({ message: 'Successfully subscribed to Organic Mart newsletter!' });
  }

  // Default Fallback
  return createJsonResponse({ status: 'ok', fallback: true });
}

function createJsonResponse(data: any, status = 200): Response {
  return new Response(JSON.stringify(data), {
    status,
    headers: { 'Content-Type': 'application/json' }
  });
}
