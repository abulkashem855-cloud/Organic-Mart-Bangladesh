import React, { useState } from 'react';
import { X, CheckCircle2, ShieldCheck } from 'lucide-react';

interface Props {
  amount: number;
  isOpen: boolean;
  onClose: () => void;
  onSuccess: (trxId: string) => void;
}

export const BkashPaymentModal: React.FC<Props> = ({ amount, isOpen, onClose, onSuccess }) => {
  const [step, setStep] = useState<'phone' | 'otp' | 'pin' | 'success'>('phone');
  const [phone, setPhone] = useState('');
  const [otp, setOtp] = useState('123456');
  const [pin, setPin] = useState('');
  const [trxId, setTrxId] = useState('');
  const [error, setError] = useState('');

  if (!isOpen) return null;

  const handlePhoneSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!phone || phone.length < 11) {
      setError('Please enter a valid 11-digit bKash account number (e.g. 01712345678)');
      return;
    }
    setError('');
    setStep('otp');
  };

  const handleOtpSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (otp.length !== 6) {
      setError('Enter 6-digit verification code');
      return;
    }
    setError('');
    setStep('pin');
  };

  const handlePinSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (pin.length !== 5) {
      setError('Enter 5-digit bKash PIN');
      return;
    }
    setError('');
    const randomTrx = 'BKASH' + Math.random().toString(36).substring(2, 9).toUpperCase();
    setTrxId(randomTrx);
    setStep('success');
    setTimeout(() => {
      onSuccess(randomTrx);
    }, 1500);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/70 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="relative w-full max-w-sm bg-pink-700 text-white rounded-3xl shadow-2xl overflow-hidden border border-pink-600">
        {/* Header */}
        <div className="p-5 bg-pink-800 flex items-center justify-between border-b border-pink-600">
          <div className="flex items-center gap-2">
            <span className="font-extrabold text-xl tracking-wider text-white bg-pink-600 px-2.5 py-1 rounded-xl">
              bKash
            </span>
            <span className="text-xs font-semibold text-pink-200">Merchant Payment</span>
          </div>
          <button onClick={onClose} className="p-1 text-pink-200 hover:text-white">
            <X size={20} />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6">
          <div className="bg-pink-800/80 p-3 rounded-2xl mb-5 text-center border border-pink-600/50">
            <p className="text-[11px] text-pink-200 uppercase font-bold tracking-wider">Merchant / Acc: <strong className="text-white font-mono">01738019928</strong></p>
            <p className="text-2xl font-black text-white mt-0.5">৳{amount.toLocaleString()}</p>
          </div>

          {error && (
            <p className="text-xs font-bold text-amber-200 bg-red-900/80 p-2.5 rounded-xl mb-4 text-center">
              {error}
            </p>
          )}

          {step === 'phone' && (
            <form onSubmit={handlePhoneSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-pink-100 mb-1">
                  Your bKash Account Number
                </label>
                <input
                  type="text"
                  placeholder="e.g. 01712345678"
                  value={phone}
                  onChange={e => setPhone(e.target.value)}
                  maxLength={11}
                  required
                  className="w-full px-4 py-3 rounded-xl bg-pink-900/90 text-white placeholder-pink-400 border border-pink-500 font-mono text-center text-sm font-bold outline-none"
                />
              </div>
              <p className="text-[10px] text-pink-200 text-center flex items-center justify-center gap-1">
                <ShieldCheck size={14} /> Encrypted & Secured bKash Gateway
              </p>
              <button
                type="submit"
                className="w-full py-3 bg-white text-pink-800 font-extrabold text-xs rounded-xl hover:bg-pink-100 transition-colors shadow-lg"
              >
                PROCEED
              </button>
            </form>
          )}

          {step === 'otp' && (
            <form onSubmit={handleOtpSubmit} className="space-y-4">
              <div className="text-center">
                <p className="text-xs font-semibold text-pink-200 mb-2">
                  Verification code sent to <strong className="text-white">{phone}</strong>
                </p>
                <input
                  type="text"
                  value={otp}
                  onChange={e => setOtp(e.target.value)}
                  maxLength={6}
                  required
                  className="w-full px-4 py-3 rounded-xl bg-pink-900/90 text-white border border-pink-500 font-mono text-center text-lg tracking-widest font-bold outline-none"
                />
              </div>
              <button
                type="submit"
                className="w-full py-3 bg-white text-pink-800 font-extrabold text-xs rounded-xl hover:bg-pink-100 transition-colors shadow-lg"
              >
                VERIFY OTP
              </button>
            </form>
          )}

          {step === 'pin' && (
            <form onSubmit={handlePinSubmit} className="space-y-4">
              <div className="text-center">
                <p className="text-xs font-semibold text-pink-200 mb-2">
                  Enter your 5-digit bKash PIN
                </p>
                <input
                  type="password"
                  placeholder="•••••"
                  value={pin}
                  onChange={e => setPin(e.target.value)}
                  maxLength={5}
                  required
                  className="w-full px-4 py-3 rounded-xl bg-pink-900/90 text-white border border-pink-500 font-mono text-center text-xl tracking-widest font-bold outline-none"
                />
              </div>
              <button
                type="submit"
                className="w-full py-3 bg-white text-pink-800 font-extrabold text-xs rounded-xl hover:bg-pink-100 transition-colors shadow-lg"
              >
                CONFIRM PAYMENT
              </button>
            </form>
          )}

          {step === 'success' && (
            <div className="text-center py-6 space-y-3">
              <CheckCircle2 size={48} className="text-lime-300 mx-auto animate-bounce" />
              <h3 className="text-lg font-bold text-white">bKash Payment Successful!</h3>
              <p className="text-xs text-pink-200">
                Transaction ID: <strong className="text-white font-mono">{trxId}</strong>
              </p>
              <p className="text-[11px] text-pink-200 font-medium">Finalizing your organic order...</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
