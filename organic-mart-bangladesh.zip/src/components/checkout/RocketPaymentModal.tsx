import React, { useState } from 'react';
import { X, CheckCircle2, ShieldCheck } from 'lucide-react';

interface Props {
  amount: number;
  isOpen: boolean;
  onClose: () => void;
  onSuccess: (trxId: string) => void;
}

export const RocketPaymentModal: React.FC<Props> = ({ amount, isOpen, onClose, onSuccess }) => {
  const [step, setStep] = useState<'phone' | 'pin' | 'success'>('phone');
  const [phone, setPhone] = useState('');
  const [pin, setPin] = useState('');
  const [trxId, setTrxId] = useState('');
  const [error, setError] = useState('');

  if (!isOpen) return null;

  const handlePhoneSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!phone || phone.length < 11) {
      setError('Enter valid 11 or 12-digit DBBL Rocket account number');
      return;
    }
    setError('');
    setStep('pin');
  };

  const handlePinSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (pin.length !== 4) {
      setError('Enter 4-digit Rocket PIN');
      return;
    }
    setError('');
    const randomTrx = 'ROCKET' + Math.random().toString(36).substring(2, 9).toUpperCase();
    setTrxId(randomTrx);
    setStep('success');
    setTimeout(() => {
      onSuccess(randomTrx);
    }, 1500);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/70 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="relative w-full max-w-sm bg-purple-900 text-white rounded-3xl shadow-2xl overflow-hidden border border-purple-700">
        {/* Header */}
        <div className="p-5 bg-purple-950 flex items-center justify-between border-b border-purple-800">
          <div className="flex items-center gap-2">
            <span className="font-extrabold text-xl tracking-wider text-purple-200 bg-purple-800 px-2.5 py-1 rounded-xl border border-purple-600">
              ROCKET
            </span>
            <span className="text-xs font-semibold text-purple-300">Dutch-Bangla Bank</span>
          </div>
          <button onClick={onClose} className="p-1 text-purple-300 hover:text-white">
            <X size={20} />
          </button>
        </div>

        <div className="p-6">
          <div className="bg-purple-950/80 p-3.5 rounded-2xl mb-5 text-center border border-purple-700">
            <p className="text-[11px] text-purple-300 uppercase font-bold tracking-wider">Merchant / Account: <strong className="text-white font-mono">01738019928</strong></p>
            <p className="text-2xl font-black text-white mt-1">৳{amount.toLocaleString()}</p>
          </div>

          {error && (
            <p className="text-xs font-bold text-amber-100 bg-red-900/80 p-2.5 rounded-xl mb-4 text-center">
              {error}
            </p>
          )}

          {step === 'phone' && (
            <form onSubmit={handlePhoneSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-purple-200 mb-1">
                  Your DBBL Rocket Account Number
                </label>
                <input
                  type="text"
                  placeholder="e.g. 017380199284"
                  value={phone}
                  onChange={e => setPhone(e.target.value)}
                  maxLength={12}
                  required
                  className="w-full px-4 py-3 rounded-xl bg-purple-950 text-white placeholder-purple-400 border border-purple-600 font-mono text-center text-sm font-bold outline-none focus:border-purple-400"
                />
              </div>
              <p className="text-[10px] text-purple-300 text-center flex items-center justify-center gap-1">
                <ShieldCheck size={14} /> Official DBBL Rocket Payment Gateway
              </p>
              <button
                type="submit"
                className="w-full py-3 bg-purple-500 hover:bg-purple-400 text-white font-extrabold text-xs rounded-xl transition-colors shadow-lg shadow-purple-900/50"
              >
                PROCEED TO PAYMENT
              </button>
            </form>
          )}

          {step === 'pin' && (
            <form onSubmit={handlePinSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-purple-200 mb-1">
                  Enter Your Rocket 4-Digit PIN
                </label>
                <input
                  type="password"
                  placeholder="••••"
                  value={pin}
                  onChange={e => setPin(e.target.value)}
                  maxLength={4}
                  required
                  className="w-full px-4 py-3 rounded-xl bg-purple-950 text-white placeholder-purple-400 border border-purple-600 font-mono text-center text-lg font-black tracking-widest outline-none focus:border-purple-400"
                />
              </div>
              <p className="text-[10px] text-purple-300 text-center">
                Merchant Acc: <strong className="font-mono text-white">01738019928</strong>
              </p>
              <button
                type="submit"
                className="w-full py-3 bg-purple-500 hover:bg-purple-400 text-white font-extrabold text-xs rounded-xl transition-colors shadow-lg"
              >
                CONFIRM PAYMENT (৳{amount})
              </button>
            </form>
          )}

          {step === 'success' && (
            <div className="text-center py-4 space-y-3">
              <div className="w-12 h-12 bg-emerald-500/20 text-emerald-300 rounded-full flex items-center justify-center mx-auto">
                <CheckCircle2 size={32} />
              </div>
              <h4 className="text-base font-bold text-white">Rocket Payment Successful!</h4>
              <p className="text-xs text-purple-200">
                TrxID: <strong className="font-mono text-white">{trxId}</strong>
              </p>
              <p className="text-[10px] text-purple-300">Paid to 01738019928</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
