import React, { useState } from 'react';
import { X, CheckCircle2, ShieldCheck } from 'lucide-react';

interface Props {
  amount: number;
  isOpen: boolean;
  onClose: () => void;
  onSuccess: (trxId: string) => void;
}

export const NagadPaymentModal: React.FC<Props> = ({ amount, isOpen, onClose, onSuccess }) => {
  const [step, setStep] = useState<'phone' | 'pin' | 'success'>('phone');
  const [phone, setPhone] = useState('');
  const [pin, setPin] = useState('');
  const [trxId, setTrxId] = useState('');
  const [error, setError] = useState('');

  if (!isOpen) return null;

  const handlePhoneSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!phone || phone.length < 11) {
      setError('Enter valid 11-digit Nagad account number');
      return;
    }
    setError('');
    setStep('pin');
  };

  const handlePinSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (pin.length !== 4) {
      setError('Enter 4-digit Nagad PIN');
      return;
    }
    setError('');
    const randomTrx = 'NAGAD' + Math.random().toString(36).substring(2, 9).toUpperCase();
    setTrxId(randomTrx);
    setStep('success');
    setTimeout(() => {
      onSuccess(randomTrx);
    }, 1500);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/70 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="relative w-full max-w-sm bg-orange-600 text-white rounded-3xl shadow-2xl overflow-hidden border border-orange-500">
        {/* Header */}
        <div className="p-5 bg-orange-700 flex items-center justify-between border-b border-orange-500">
          <div className="flex items-center gap-2">
            <span className="font-extrabold text-xl tracking-wider text-white bg-orange-800 px-2.5 py-1 rounded-xl">
              NAGAD
            </span>
            <span className="text-xs font-semibold text-orange-200">Merchant Payment</span>
          </div>
          <button onClick={onClose} className="p-1 text-orange-200 hover:text-white">
            <X size={20} />
          </button>
        </div>

        <div className="p-6">
          <div className="bg-orange-700/80 p-3 rounded-2xl mb-5 text-center border border-orange-500">
            <p className="text-[11px] text-orange-200 uppercase font-bold tracking-wider">Merchant / Acc: <strong className="text-white font-mono">01738019928</strong></p>
            <p className="text-2xl font-black text-white mt-0.5">৳{amount.toLocaleString()}</p>
          </div>

          {error && (
            <p className="text-xs font-bold text-amber-100 bg-red-900/80 p-2.5 rounded-xl mb-4 text-center">
              {error}
            </p>
          )}

          {step === 'phone' && (
            <form onSubmit={handlePhoneSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-orange-100 mb-1">
                  Your Nagad Account Number
                </label>
                <input
                  type="text"
                  placeholder="e.g. 01812345678"
                  value={phone}
                  onChange={e => setPhone(e.target.value)}
                  maxLength={11}
                  required
                  className="w-full px-4 py-3 rounded-xl bg-orange-800 text-white placeholder-orange-300 border border-orange-400 font-mono text-center text-sm font-bold outline-none"
                />
              </div>
              <p className="text-[10px] text-orange-200 text-center flex items-center justify-center gap-1">
                <ShieldCheck size={14} /> Official Nagad Payment Gateway
              </p>
              <button
                type="submit"
                className="w-full py-3 bg-white text-orange-800 font-extrabold text-xs rounded-xl hover:bg-orange-100 transition-colors shadow-lg"
              >
                PROCEED
              </button>
            </form>
          )}

          {step === 'pin' && (
            <form onSubmit={handlePinSubmit} className="space-y-4">
              <div className="text-center">
                <p className="text-xs font-semibold text-orange-200 mb-2">
                  Enter 4-digit Nagad PIN
                </p>
                <input
                  type="password"
                  placeholder="••••"
                  value={pin}
                  onChange={e => setPin(e.target.value)}
                  maxLength={4}
                  required
                  className="w-full px-4 py-3 rounded-xl bg-orange-800 text-white border border-orange-400 font-mono text-center text-xl tracking-widest font-bold outline-none"
                />
              </div>
              <button
                type="submit"
                className="w-full py-3 bg-white text-orange-800 font-extrabold text-xs rounded-xl hover:bg-orange-100 transition-colors shadow-lg"
              >
                CONFIRM PAYMENT
              </button>
            </form>
          )}

          {step === 'success' && (
            <div className="text-center py-6 space-y-3">
              <CheckCircle2 size={48} className="text-lime-300 mx-auto animate-bounce" />
              <h3 className="text-lg font-bold text-white">Nagad Payment Successful!</h3>
              <p className="text-xs text-orange-200">
                Transaction ID: <strong className="text-white font-mono">{trxId}</strong>
              </p>
              <p className="text-[11px] text-orange-200 font-medium">Finalizing order details...</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
