import React from 'react';
import { X, Printer, ShieldCheck, CheckCircle, Truck, Phone, Mail, MapPin } from 'lucide-react';
import { Order } from '../../types';

interface A5InvoiceModalProps {
  order: Order;
  onClose: () => void;
}

export const A5InvoiceModal: React.FC<A5InvoiceModalProps> = ({ order, onClose }) => {
  const handlePrint = () => {
    window.print();
  };

  const itemsSubtotal = order.subtotal || order.items.reduce((sum, item) => sum + (item.price * item.quantity), 0);
  const deliveryFee = typeof order.shippingCharge === 'number' ? order.shippingCharge : 70;
  const discountAmount = order.discount || 0;
  const grandTotal = order.grandTotal || (itemsSubtotal + deliveryFee - discountAmount);

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/80 backdrop-blur-sm flex items-center justify-center p-2 sm:p-4 overflow-y-auto print:p-0 print:bg-white print:static">
      {/* Container - Styled as A5 preview on screen, exact A5 on print */}
      <div className="bg-white text-slate-900 rounded-3xl max-w-2xl w-full p-6 sm:p-8 space-y-6 shadow-2xl border border-slate-200 dark:border-slate-800 max-h-[92vh] overflow-y-auto print:max-h-none print:shadow-none print:border-none print:p-0 print:w-full print:rounded-none">
        
        {/* Modal Action Controls (Hidden when printing) */}
        <div className="flex items-center justify-between border-b border-slate-200 pb-4 print:hidden">
          <div className="flex items-center gap-2">
            <span className="px-3 py-1 bg-emerald-100 text-emerald-800 text-xs font-black rounded-lg uppercase flex items-center gap-1">
              <ShieldCheck size={14} /> Official A5 Invoice
            </span>
            <span className="text-xs font-mono font-bold text-slate-500">#{order.id}</span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-xs rounded-xl flex items-center gap-2 shadow-lg shadow-emerald-600/20 transition-transform active:scale-95"
            >
              <Printer size={16} /> প্রিন্ট ইনভয়েস (Print A5 Invoice)
            </button>
            <button
              onClick={onClose}
              className="p-2 text-slate-400 hover:text-slate-600 hover:bg-slate-100 rounded-xl"
            >
              <X size={20} />
            </button>
          </div>
        </div>

        {/* PRINTABLE A5 AREA */}
        <div id="printable-a5-invoice" className="space-y-5 text-slate-900 bg-white font-sans text-xs">
          
          {/* Print specific A5 styling injected dynamically */}
          <style>{`
            @media print {
              body * {
                visibility: hidden !important;
              }
              #printable-a5-invoice, #printable-a5-invoice * {
                visibility: visible !important;
              }
              #printable-a5-invoice {
                position: absolute !important;
                left: 0 !important;
                top: 0 !important;
                width: 148mm !important;
                min-height: 210mm !important;
                padding: 8mm !important;
                margin: 0 !important;
                background: #ffffff !important;
                color: #000000 !important;
                font-size: 11px !important;
              }
              @page {
                size: A5 portrait;
                margin: 0mm;
              }
            }
          `}</style>

          {/* Invoice Header / Brand */}
          <div className="flex justify-between items-start border-b-2 border-emerald-600 pb-4">
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-emerald-800 text-white font-black flex items-center justify-center text-sm shadow">
                  🌿
                </div>
                <div>
                  <h1 className="text-base font-black text-emerald-950 uppercase tracking-tight">
                    Organic Mart Bangladesh
                  </h1>
                  <p className="text-[10px] text-emerald-700 font-bold">১০০% খাঁটি ও প্রাকৃতিক অর্গানিক শপ</p>
                </div>
              </div>
              <div className="text-[10px] text-slate-600 space-y-0.5 pt-1">
                <p className="flex items-center gap-1"><MapPin size={10} className="text-emerald-700" /> Plot 14, Road 12, Block D, Mirpur DOHS, Dhaka</p>
                <p className="flex items-center gap-1"><Phone size={10} className="text-emerald-700" /> Helpline: 01738019928 | Email: support@organicmart.bd</p>
              </div>
            </div>

            <div className="text-right space-y-1">
              <span className="inline-block px-3 py-1 bg-emerald-900 text-white font-black text-[11px] rounded uppercase tracking-wider">
                INVOICE / চালান
              </span>
              <p className="text-xs font-mono font-black text-emerald-700">{order.id}</p>
              <p className="text-[10px] text-slate-500">তারিখ: {new Date(order.createdAt).toLocaleDateString('bn-BD', { year: 'numeric', month: 'long', day: 'numeric' })}</p>
            </div>
          </div>

          {/* Customer & Shipping Details */}
          <div className="grid grid-cols-2 gap-3 p-3 bg-slate-50 rounded-xl border border-slate-200">
            <div className="space-y-1">
              <p className="text-[10px] font-black text-emerald-900 uppercase border-b border-slate-200 pb-0.5">
                গ্রাহক তথ্য (Customer Details)
              </p>
              <p className="font-extrabold text-slate-900 text-xs">{order.customerName}</p>
              <p className="font-mono text-slate-800 font-bold">{order.customerPhone}</p>
              {order.customerEmail && <p className="text-slate-600 text-[10px]">{order.customerEmail}</p>}
            </div>

            <div className="space-y-1">
              <p className="text-[10px] font-black text-emerald-900 uppercase border-b border-slate-200 pb-0.5">
                ডেলিভারি ঠিকানা (Shipping Address)
              </p>
              <p className="text-slate-800 text-[11px] font-medium leading-snug">
                {order.shippingAddress?.address || 'N/A'}
              </p>
              <p className="text-slate-600 text-[10px] font-bold">
                {order.shippingAddress?.thana ? `${order.shippingAddress.thana}, ` : ''}{order.shippingAddress?.district || 'Dhaka'}
              </p>
            </div>
          </div>

          {/* Payment & Courier Info Bar */}
          <div className="flex justify-between items-center text-[11px] p-2 bg-emerald-50 rounded-lg border border-emerald-200 font-medium">
            <div>
              <span>পেমেন্ট মেথড: </span>
              <strong className="uppercase font-bold text-emerald-900">{order.paymentMethod}</strong>
              <span className="ml-2 font-bold text-slate-600">({order.paymentStatus === 'Paid' ? 'পরিশোধিত / Paid' : 'বাকি / Cash On Delivery'})</span>
            </div>
            {order.deliveryCourier && (
              <div>
                <span>কুরিয়ার: </span>
                <strong className="font-bold text-slate-900">{order.deliveryCourier}</strong>
                {order.trackingNumber && <span className="ml-1 font-mono">({order.trackingNumber})</span>}
              </div>
            )}
          </div>

          {/* Product Items Table */}
          <div className="overflow-hidden border border-slate-200 rounded-xl">
            <table className="w-full text-left text-[11px]">
              <thead className="bg-emerald-900 text-white font-bold uppercase text-[10px]">
                <tr>
                  <th className="py-2 px-3">#</th>
                  <th className="py-2 px-3">পণ্য (Product Name)</th>
                  <th className="py-2 px-3 text-center">একক</th>
                  <th className="py-2 px-3 text-center">পরিমাণ</th>
                  <th className="py-2 px-3 text-right">মূল্য (Price)</th>
                  <th className="py-2 px-3 text-right">মোট (Total)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200">
                {order.items.map((item, idx) => (
                  <tr key={idx} className="hover:bg-slate-50">
                    <td className="py-2 px-3 text-slate-400 font-mono text-[10px]">{idx + 1}</td>
                    <td className="py-2 px-3 font-bold text-slate-900">{item.name}</td>
                    <td className="py-2 px-3 text-center text-slate-600">{item.unit}</td>
                    <td className="py-2 px-3 text-center font-bold text-slate-900">{item.quantity}</td>
                    <td className="py-2 px-3 text-right font-mono">৳{item.price}</td>
                    <td className="py-2 px-3 text-right font-mono font-bold text-slate-900">৳{item.price * item.quantity}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Calculation Summary: Subtotal + Delivery Charge - Discount = Grand Total */}
          <div className="flex justify-end pt-2">
            <div className="w-64 space-y-1.5 text-xs border border-slate-200 p-3 rounded-xl bg-slate-50">
              <div className="flex justify-between text-slate-700">
                <span>পণ্য মোট মূল্য (Products Price):</span>
                <span className="font-mono font-bold">৳{itemsSubtotal}</span>
              </div>

              <div className="flex justify-between text-slate-700">
                <span>ডেলিভারি চার্জ (Delivery Charge):</span>
                <span className="font-mono font-bold text-emerald-800">+ ৳{deliveryFee}</span>
              </div>

              {discountAmount > 0 && (
                <div className="flex justify-between text-emerald-700">
                  <span>ডিসকাউন্ট (Discount):</span>
                  <span className="font-mono font-bold">- ৳{discountAmount}</span>
                </div>
              )}

              <div className="flex justify-between items-center pt-2 border-t border-slate-300 font-black text-emerald-950 text-sm">
                <span>সর্বমোট প্রদেয় (Grand Total):</span>
                <span className="font-mono text-emerald-700 text-base">৳{grandTotal}</span>
              </div>
            </div>
          </div>

          {/* Footer Terms & Verification Note */}
          <div className="pt-4 border-t border-slate-200 flex justify-between items-end text-[10px] text-slate-500">
            <div className="space-y-1 max-w-xs">
              <p className="font-bold text-slate-700">• অর্গানিক খাদ্যদ্রব্য রিফান্ড গ্যারান্টি: ৭ দিন।</p>
              <p>• যেকোনো সহায়তায় কল করুন 01738019928 নম্বরে।</p>
              <p className="text-[9px] text-slate-400">Printed from Organic Mart Bangladesh • Official A5 Billing System</p>
            </div>

            <div className="text-center space-y-6">
              <div className="w-28 border-b border-slate-400 mx-auto" />
              <p className="font-bold text-slate-800">অনুমোদিত স্বাক্ষর (Authorized Seal)</p>
            </div>
          </div>

        </div>

        {/* Bottom Action Footer for Screen Display (Hidden on print) */}
        <div className="pt-4 border-t border-slate-200 flex items-center justify-between gap-3 print:hidden">
          <button
            onClick={onClose}
            className="px-5 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl"
          >
            বন্ধ করুন (Close)
          </button>

          <button
            onClick={handlePrint}
            className="px-6 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-xs rounded-xl flex items-center gap-2 shadow-lg shadow-emerald-600/30 transition-transform active:scale-95"
          >
            <Printer size={18} /> প্রিন্ট ইনভয়েস (Print Invoice Now)
          </button>
        </div>
      </div>
    </div>
  );
};
