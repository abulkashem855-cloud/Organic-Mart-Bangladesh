import React from 'react';
import { Leaf } from 'lucide-react';

interface LogoProps {
  className?: string;
  size?: 'sm' | 'md' | 'lg';
}

export const Logo: React.FC<LogoProps> = ({ className = '', size = 'md' }) => {
  const iconSize = size === 'sm' ? 20 : size === 'lg' ? 32 : 26;
  const textSize = size === 'sm' ? 'text-lg' : size === 'lg' ? 'text-2xl' : 'text-xl';

  return (
    <div className={`flex items-center gap-2.5 font-bold tracking-tight select-none ${className}`}>
      <div className="relative flex items-center justify-center p-2 rounded-xl bg-gradient-to-br from-emerald-500 to-emerald-700 text-white shadow-md shadow-emerald-500/20 dark:shadow-emerald-900/30">
        <Leaf size={iconSize} className="animate-pulse duration-1000" />
        <span className="absolute -top-1 -right-1 w-2.5 h-2.5 bg-lime-400 rounded-full border-2 border-white dark:border-slate-900" />
      </div>
      <div className="flex flex-col">
        <div className={`flex items-center ${textSize} leading-none font-extrabold text-slate-900 dark:text-white`}>
          <span className="text-emerald-600 dark:text-emerald-400">Organic</span>
          <span className="ml-1 text-slate-800 dark:text-slate-100">Mart</span>
        </div>
        <span className="text-[10px] tracking-widest uppercase font-semibold text-emerald-700 dark:text-emerald-300 mt-0.5">
          Bangladesh 🇧🇩
        </span>
      </div>
    </div>
  );
};
