import React, { useState, useEffect, useRef } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { 
  Search, ShoppingCart, Heart, RefreshCw, User as UserIcon, Sun, Moon, Menu, X, 
  ChevronDown, Phone, ShieldCheck, Truck, Sparkles, LogOut, LayoutDashboard 
} from 'lucide-react';
import { Logo } from './Logo';
import { useTheme } from '../../context/ThemeContext';
import { useAuth } from '../../context/AuthContext';
import { useCart } from '../../context/CartContext';
import { Product, Category } from '../../types';
import { renderCategoryIcon } from '../../pages/AdminDashboardPage';

export const Header: React.FC = () => {
  const { theme, toggleTheme } = useTheme();
  const { user, isAdmin, logout } = useAuth();
  const { cartTotalItems, subtotal, wishlist, compareList, setIsCartDrawerOpen, setIsCompareOpen, setQuickViewProduct } = useCart();
  const navigate = useNavigate();
  const location = useLocation();

  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isCategoryOpen, setIsCategoryOpen] = useState(false);
  const [isMobileCategoryOpen, setIsMobileCategoryOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [suggestions, setSuggestions] = useState<Product[]>([]);
  const [isSearching, setIsSearching] = useState(false);
  const [categories, setCategories] = useState<Category[]>([]);
  const searchRef = useRef<HTMLDivElement>(null);
  const categoryRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    fetch('/api/categories')
      .then(res => res.json())
      .then(data => setCategories(data))
      .catch(err => console.error(err));
  }, [isCategoryOpen, isMobileCategoryOpen, location.pathname]);

  // Live Search Suggestions
  useEffect(() => {
    if (!searchQuery.trim()) {
      setSuggestions([]);
      return;
    }

    const timer = setTimeout(() => {
      setIsSearching(true);
      fetch(`/api/products?search=${encodeURIComponent(searchQuery.trim())}`)
        .then(res => res.json())
        .then(data => {
          setSuggestions(data.products ? data.products.slice(0, 5) : []);
        })
        .finally(() => setIsSearching(false));
    }, 250);

    return () => clearTimeout(timer);
  }, [searchQuery]);

  // Click outside listener for category dropdown & search suggestions
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (searchRef.current && !searchRef.current.contains(e.target as Node)) {
        setSuggestions([]);
      }
      if (categoryRef.current && !categoryRef.current.contains(e.target as Node)) {
        setIsCategoryOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      navigate(`/shop?search=${encodeURIComponent(searchQuery.trim())}`);
      setSuggestions([]);
    }
  };

  const activePath = location.pathname;

  return (
    <header className="sticky top-0 z-40 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-b border-emerald-100 dark:border-slate-800 transition-colors">
      {/* Top Banner Announcement */}
      <div className="bg-gradient-to-r from-emerald-800 via-emerald-700 to-teal-800 text-white text-xs py-1.5 px-4">
        <div className="max-w-7xl mx-auto flex justify-between items-center">
          <div className="flex items-center gap-4">
            <span className="flex items-center gap-1.5 font-medium">
              <Truck size={14} className="text-lime-300" /> Express 2-Hour Delivery in Dhaka
            </span>
            <span className="hidden md:flex items-center gap-1.5">
              <ShieldCheck size={14} className="text-lime-300" /> 100% Certified Organic & Chemical-Free
            </span>
          </div>
          <div className="flex items-center gap-4 text-emerald-100">
            <span className="hidden sm:inline">Support: <a href="tel:+8801738019928" className="font-semibold text-white hover:underline">01738019928</a></span>
            <span className="text-lime-300 font-medium">Get 20% OFF code: <strong className="bg-emerald-900/80 px-1.5 py-0.5 rounded text-lime-300">ORGANIC20</strong></span>
          </div>
        </div>
      </div>

      {/* Main Bar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3">
        <div className="flex items-center justify-between gap-4">
          {/* Logo */}
          <Link to="/" className="flex-shrink-0">
            <Logo />
          </Link>

          {/* Live Search Bar */}
          <div ref={searchRef} className="hidden md:flex flex-1 max-w-xl relative">
            <form onSubmit={handleSearchSubmit} className="w-full flex items-center">
              <div className="relative w-full">
                <input
                  type="text"
                  placeholder="Search organic honey, kalijira rice, ghee, fresh fruits..."
                  value={searchQuery}
                  onChange={e => setSearchQuery(e.target.value)}
                  className="w-full pl-10 pr-24 py-2.5 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-900 dark:text-slate-100 text-sm border border-transparent focus:border-emerald-500 focus:bg-white dark:focus:bg-slate-900 outline-none transition-all shadow-inner"
                />
                <Search size={18} className="absolute left-3.5 top-3 text-slate-400" />
                <button
                  type="submit"
                  className="absolute right-1 top-1 bottom-1 px-4 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold rounded-full transition-colors flex items-center gap-1"
                >
                  Search
                </button>
              </div>
            </form>

            {/* Suggestions Popover */}
            {suggestions.length > 0 && (
              <div className="absolute top-full left-0 right-0 mt-2 bg-white dark:bg-slate-900 rounded-2xl shadow-xl border border-slate-200 dark:border-slate-800 py-2 z-50 overflow-hidden">
                <div className="px-3 py-1 text-xs font-bold text-slate-400 uppercase tracking-wider">
                  Products ({suggestions.length})
                </div>
                {suggestions.map(p => (
                  <div
                    key={p.id}
                    onClick={() => {
                      setQuickViewProduct(p);
                      setSuggestions([]);
                    }}
                    className="flex items-center gap-3 px-3 py-2 hover:bg-emerald-50 dark:hover:bg-slate-800/80 cursor-pointer transition-colors"
                  >
                    <img src={p.images[0]} alt={p.name} className="w-10 h-10 object-cover rounded-lg" />
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-slate-900 dark:text-slate-100 truncate">{p.name}</p>
                      <p className="text-xs text-emerald-600 font-semibold">৳{p.discountPrice || p.price} <span className="text-slate-400 font-normal">/ {p.unit}</span></p>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Action Buttons */}
          <div className="flex items-center gap-2 sm:gap-4">
            {/* Dark Mode Toggle */}
            <button
              onClick={toggleTheme}
              className="p-2.5 rounded-full text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
              title={theme === 'dark' ? 'Switch to Light Mode' : 'Switch to Dark Mode'}
            >
              {theme === 'dark' ? <Sun size={20} className="text-amber-400" /> : <Moon size={20} />}
            </button>

            {/* Compare Button */}
            <button
              onClick={() => setIsCompareOpen(true)}
              className="relative p-2.5 rounded-full text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors hidden sm:flex"
              title="Compare Products"
            >
              <RefreshCw size={20} />
              {compareList.length > 0 && (
                <span className="absolute -top-1 -right-1 bg-teal-600 text-white text-[10px] font-bold w-5 h-5 rounded-full flex items-center justify-center border-2 border-white dark:border-slate-900">
                  {compareList.length}
                </span>
              )}
            </button>

            {/* Wishlist Button */}
            <Link
              to="/account?tab=wishlist"
              className="relative p-2.5 rounded-full text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors hidden sm:flex"
              title="Wishlist"
            >
              <Heart size={20} />
              {wishlist.length > 0 && (
                <span className="absolute -top-1 -right-1 bg-emerald-600 text-white text-[10px] font-bold w-5 h-5 rounded-full flex items-center justify-center border-2 border-white dark:border-slate-900">
                  {wishlist.length}
                </span>
              )}
            </Link>

            {/* Cart Drawer Trigger */}
            <button
              onClick={() => setIsCartDrawerOpen(true)}
              className="flex items-center gap-2 bg-emerald-600 hover:bg-emerald-700 text-white px-3.5 py-2 rounded-full font-semibold text-xs transition-all shadow-md shadow-emerald-600/20 active:scale-95"
            >
              <div className="relative">
                <ShoppingCart size={18} />
                {cartTotalItems > 0 && (
                  <span className="absolute -top-2 -right-2 bg-lime-400 text-slate-900 text-[10px] font-black w-4 h-4 rounded-full flex items-center justify-center">
                    {cartTotalItems}
                  </span>
                )}
              </div>
              <span className="hidden md:inline font-bold">৳{subtotal.toLocaleString()}</span>
            </button>

            {/* User Profile / Admin / Login */}
            {user ? (
              <div className="relative group">
                <Link
                  to={isAdmin ? '/admin' : '/account'}
                  className="flex items-center gap-2 p-1.5 rounded-full bg-slate-100 dark:bg-slate-800 hover:bg-emerald-50 dark:hover:bg-slate-700 transition-colors"
                >
                  <img
                    src={user.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&auto=format&fit=crop&q=80'}
                    alt={user.name}
                    className="w-8 h-8 rounded-full object-cover border border-emerald-500"
                  />
                  <span className="hidden md:inline text-xs font-bold text-slate-800 dark:text-slate-200 pr-2">
                    {user.name}
                  </span>
                </Link>

                {/* Dropdown Menu */}
                <div className="absolute right-0 top-full mt-2 w-48 bg-white dark:bg-slate-900 rounded-2xl shadow-xl border border-slate-200 dark:border-slate-800 py-2 hidden group-hover:block z-50">
                  <div className="px-4 py-2 border-b border-slate-100 dark:border-slate-800">
                    <p className="text-xs font-bold text-slate-900 dark:text-white truncate">{user.name}</p>
                    <p className="text-[10px] text-slate-500 dark:text-slate-400 capitalize">{user.role} Account</p>
                  </div>
                  {isAdmin ? (
                    <Link
                      to="/admin"
                      className="flex items-center gap-2 px-4 py-2 text-xs text-emerald-600 dark:text-emerald-400 font-bold hover:bg-slate-50 dark:hover:bg-slate-800"
                    >
                      <LayoutDashboard size={14} /> Admin Dashboard
                    </Link>
                  ) : (
                    <Link
                      to="/account"
                      className="flex items-center gap-2 px-4 py-2 text-xs text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800"
                    >
                      <UserIcon size={14} /> My Account & Orders
                    </Link>
                  )}
                  <button
                    onClick={logout}
                    className="w-full flex items-center gap-2 px-4 py-2 text-xs text-red-600 hover:bg-red-50 dark:hover:bg-red-950/30 text-left font-medium"
                  >
                    <LogOut size={14} /> Log Out
                  </button>
                </div>
              </div>
            ) : (
              <Link
                to="/login"
                className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-bold text-slate-700 dark:text-slate-200 hover:text-emerald-600 transition-colors border border-slate-200 dark:border-slate-700 rounded-full"
              >
                <UserIcon size={16} />
                <span>Login</span>
              </Link>
            )}

            {/* Mobile Hamburger Toggle */}
            <button
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="p-2 rounded-xl text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 lg:hidden"
            >
              {isMobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>

        {/* Mobile Search Input */}
        <div className="mt-3 md:hidden">
          <form onSubmit={handleSearchSubmit} className="relative w-full">
            <input
              type="text"
              placeholder="Search organic products..."
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-4 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-900 dark:text-slate-100 text-xs border border-transparent focus:border-emerald-500 outline-none"
            />
            <Search size={16} className="absolute left-3 top-2.5 text-slate-400" />
          </form>
        </div>
      </div>

      {/* Navigation Bar */}
      <nav className="hidden lg:block border-t border-slate-100 dark:border-slate-800 bg-slate-50/80 dark:bg-slate-900/80">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center justify-between h-12 text-sm font-semibold text-slate-700 dark:text-slate-200">
          <div className="flex items-center gap-6">
            {/* Categories Menu */}
            <div
              ref={categoryRef}
              className="relative"
              onMouseEnter={() => setIsCategoryOpen(true)}
              onMouseLeave={() => setIsCategoryOpen(false)}
            >
              <button
                onClick={() => setIsCategoryOpen(prev => !prev)}
                className="flex items-center gap-2 bg-emerald-600 hover:bg-emerald-700 text-white px-4 py-2 rounded-xl text-xs font-bold tracking-wide transition-colors"
              >
                <Menu size={16} />
                <span>All Categories (সকল ক্যাটাগরি)</span>
                <ChevronDown size={14} className={`transition-transform duration-200 ${isCategoryOpen ? 'rotate-180' : ''}`} />
              </button>

              {isCategoryOpen && (
                <div className="absolute top-full left-0 w-72 bg-white dark:bg-slate-900 rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 py-2 z-50 grid grid-cols-1 divide-y divide-slate-100 dark:divide-slate-800/60 max-h-[80vh] overflow-y-auto">
                  {/* All Categories Option */}
                  <Link
                    to="/shop"
                    onClick={() => setIsCategoryOpen(false)}
                    className="flex items-center justify-between px-4 py-2.5 hover:bg-emerald-50 dark:hover:bg-slate-800 text-xs font-bold text-emerald-700 dark:text-emerald-400 transition-colors"
                  >
                    <span className="flex items-center gap-2">
                      <Sparkles size={14} className="text-emerald-600" />
                      All Categories (সকল ক্যাটাগরি)
                    </span>
                    <span className="text-[10px] text-emerald-600 bg-emerald-100 dark:bg-emerald-950 px-2 py-0.5 rounded-full font-bold">
                      All
                    </span>
                  </Link>

                  {/* Sub category buttons */}
                  {categories.map(cat => (
                    <Link
                      key={cat.id}
                      to={`/shop?category=${encodeURIComponent(cat.id)}`}
                      onClick={() => setIsCategoryOpen(false)}
                      className="flex items-center justify-between px-4 py-2.5 hover:bg-emerald-50 dark:hover:bg-slate-800 text-xs font-medium text-slate-800 dark:text-slate-200 transition-colors"
                    >
                      <span className="flex items-center gap-2 font-semibold truncate">
                        {renderCategoryIcon(cat.icon, 14, "text-emerald-600 dark:text-emerald-400 flex-shrink-0")}
                        <span className="truncate">{cat.name} ({cat.bnName})</span>
                      </span>
                      <span className="text-[10px] text-slate-400 bg-slate-100 dark:bg-slate-800 px-2 py-0.5 rounded-full flex-shrink-0 ml-2">
                        {cat.itemCount}
                      </span>
                    </Link>
                  ))}
                </div>
              )}
            </div>

            {/* Nav Links */}
            <Link
              to="/"
              className={`hover:text-emerald-600 transition-colors ${activePath === '/' ? 'text-emerald-600 font-bold' : ''}`}
            >
              Home
            </Link>
            <Link
              to="/shop"
              className={`hover:text-emerald-600 transition-colors ${activePath === '/shop' ? 'text-emerald-600 font-bold' : ''}`}
            >
              Shop
            </Link>
            <Link
              to="/offers"
              className="hover:text-emerald-600 transition-colors flex items-center gap-1 text-amber-600 dark:text-amber-400 font-bold"
            >
              <Sparkles size={14} /> Today's Deals
            </Link>
            <Link
              to="/track"
              className={`hover:text-emerald-600 transition-colors flex items-center gap-1 ${activePath === '/track' ? 'text-emerald-600 font-bold' : ''}`}
            >
              <Truck size={14} /> Track Order
            </Link>
            <Link
              to="/blog"
              className={`hover:text-emerald-600 transition-colors ${activePath === '/blog' ? 'text-emerald-600 font-bold' : ''}`}
            >
              Blog
            </Link>
            <Link
              to="/about"
              className={`hover:text-emerald-600 transition-colors ${activePath === '/about' ? 'text-emerald-600 font-bold' : ''}`}
            >
              About Us
            </Link>
            <Link
              to="/contact"
              className={`hover:text-emerald-600 transition-colors ${activePath === '/contact' ? 'text-emerald-600 font-bold' : ''}`}
            >
              Contact
            </Link>
          </div>

          <div className="flex items-center gap-3 text-xs text-emerald-700 dark:text-emerald-400 font-medium">
            <span>🌿 100% Organic Certificate #BSTI-2026</span>
          </div>
        </div>
      </nav>

      {/* Mobile Drawer */}
      {isMobileMenuOpen && (
        <div className="lg:hidden border-t border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 px-4 py-4 space-y-3">
          <div className="flex flex-col space-y-2 text-sm font-semibold">
            <button
              onClick={toggleTheme}
              className="p-2 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-800 dark:text-slate-200 flex items-center justify-between mb-2"
            >
              <span className="flex items-center gap-2">
                {theme === 'dark' ? <Sun size={18} className="text-amber-400" /> : <Moon size={18} className="text-slate-600" />}
                Theme Mode
              </span>
              <span className="text-xs px-2 py-0.5 rounded bg-emerald-600 text-white font-bold capitalize">
                {theme} Mode
              </span>
            </button>

            {/* Mobile Categories Accordion */}
            <div className="border border-emerald-200/80 dark:border-slate-800 rounded-xl overflow-hidden mb-2">
              <button
                onClick={() => setIsMobileCategoryOpen(!isMobileCategoryOpen)}
                className="w-full flex items-center justify-between p-3 bg-emerald-50 dark:bg-slate-800 text-emerald-800 dark:text-emerald-300 font-bold text-xs"
              >
                <span className="flex items-center gap-2">
                  <Menu size={16} /> All Categories (সকল ক্যাটাগরি)
                </span>
                <ChevronDown size={14} className={`transition-transform duration-200 ${isMobileCategoryOpen ? 'rotate-180' : ''}`} />
              </button>
              {isMobileCategoryOpen && (
                <div className="p-2 space-y-1 bg-white dark:bg-slate-900 max-h-60 overflow-y-auto divide-y divide-slate-100 dark:divide-slate-800">
                  <Link
                    to="/shop"
                    onClick={() => {
                      setIsMobileCategoryOpen(false);
                      setIsMobileMenuOpen(false);
                    }}
                    className="block px-3 py-2 text-xs font-bold text-emerald-700 dark:text-emerald-400 hover:bg-emerald-50 rounded-lg"
                  >
                    ✨ All Products (সকল প্রোডাক্ট)
                  </Link>
                  {categories.map(cat => (
                    <Link
                      key={cat.id}
                      to={`/shop?category=${encodeURIComponent(cat.id)}`}
                      onClick={() => {
                        setIsMobileCategoryOpen(false);
                        setIsMobileMenuOpen(false);
                      }}
                      className="flex items-center justify-between px-3 py-2 text-xs text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg"
                    >
                      <span className="flex items-center gap-2 font-medium">
                        {renderCategoryIcon(cat.icon, 14, "text-emerald-600")}
                        {cat.name} ({cat.bnName})
                      </span>
                      <span className="text-[10px] text-slate-400">({cat.itemCount})</span>
                    </Link>
                  ))}
                </div>
              )}
            </div>

            <Link to="/" onClick={() => setIsMobileMenuOpen(false)} className="p-2 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800">Home</Link>
            <Link to="/shop" onClick={() => setIsMobileMenuOpen(false)} className="p-2 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800">Shop All Products</Link>
            <Link to="/offers" onClick={() => setIsMobileMenuOpen(false)} className="p-2 rounded-lg text-amber-600 font-bold flex items-center gap-2">🔥 Today's Offers</Link>
            <Link to="/track" onClick={() => setIsMobileMenuOpen(false)} className="p-2 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 flex items-center gap-2"><Truck size={16} /> Track Order</Link>
            <Link to="/blog" onClick={() => setIsMobileMenuOpen(false)} className="p-2 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800">Organic Health Blog</Link>
            <Link to="/about" onClick={() => setIsMobileMenuOpen(false)} className="p-2 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800">About Us</Link>
            <Link to="/contact" onClick={() => setIsMobileMenuOpen(false)} className="p-2 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800">Contact</Link>
          </div>
        </div>
      )}
    </header>
  );
};
