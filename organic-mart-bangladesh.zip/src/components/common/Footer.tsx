import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Mail, Phone, MapPin, Send, ShieldCheck, Truck, Headphones, RotateCcw, Facebook, Instagram, Youtube } from 'lucide-react';
import { Logo } from './Logo';

export const Footer: React.FC = () => {
  const [email, setEmail] = useState('');
  const [subscribed, setSubscribed] = useState(false);

  const handleSubscribe = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) return;
    try {
      const res = await fetch('/api/newsletter', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email })
      });
      if (res.ok) {
        setSubscribed(true);
        setEmail('');
      }
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <footer className="bg-slate-900 text-slate-300 pt-16 pb-8 border-t border-slate-800">
      {/* Top Value Propositions */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-12 mb-12 border-b border-slate-800 grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="flex items-center gap-4 p-4 rounded-2xl bg-slate-800/50 border border-slate-800">
          <div className="p-3 bg-emerald-500/10 text-emerald-400 rounded-xl">
            <Truck size={28} />
          </div>
          <div>
            <h4 className="font-bold text-white text-sm">Express Delivery</h4>
            <p className="text-xs text-slate-400">Within 2 hours in Dhaka City</p>
          </div>
        </div>

        <div className="flex items-center gap-4 p-4 rounded-2xl bg-slate-800/50 border border-slate-800">
          <div className="p-3 bg-emerald-500/10 text-emerald-400 rounded-xl">
            <ShieldCheck size={28} />
          </div>
          <div>
            <h4 className="font-bold text-white text-sm">100% Organic Certified</h4>
            <p className="text-xs text-slate-400">Lab tested & BSTI approved</p>
          </div>
        </div>

        <div className="flex items-center gap-4 p-4 rounded-2xl bg-slate-800/50 border border-slate-800">
          <div className="p-3 bg-emerald-500/10 text-emerald-400 rounded-xl">
            <RotateCcw size={28} />
          </div>
          <div>
            <h4 className="font-bold text-white text-sm">Instant Return Policy</h4>
            <p className="text-xs text-slate-400">7-day hassle-free refund</p>
          </div>
        </div>

        <div className="flex items-center gap-4 p-4 rounded-2xl bg-slate-800/50 border border-slate-800">
          <div className="p-3 bg-emerald-500/10 text-emerald-400 rounded-xl">
            <Headphones size={28} />
          </div>
          <div>
            <h4 className="font-bold text-white text-sm">24/7 Customer Care</h4>
            <p className="text-xs text-slate-400">Dedicated support line</p>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-10">
        {/* Column 1: Brand Info */}
        <div className="lg:col-span-2 space-y-4">
          <Logo size="lg" />
          <p className="text-xs leading-relaxed text-slate-400 pr-6">
            Organic Mart Bangladesh is the premier destination for 100% chemical-free, lab-certified organic food, pure Sundarban honey, unpolished heirloom rice, cold-pressed oils, and fresh orchard fruits across Bangladesh.
          </p>

          <div className="space-y-2 text-xs">
            <p className="flex items-center gap-2 text-slate-300">
              <MapPin size={16} className="text-emerald-400 flex-shrink-0" />
              Paikpara, Khatupara, Santhia, Pabna.
            </p>
            <p className="flex items-center gap-2 text-slate-300">
              <Phone size={16} className="text-emerald-400 flex-shrink-0" />
              Mobile / WhatsApp: 01738019928
            </p>
            <p className="flex items-center gap-2 text-slate-300">
              <Mail size={16} className="text-emerald-400 flex-shrink-0" />
              kashemitca@gmail.com
            </p>
          </div>

          <div className="pt-2 flex items-center gap-3">
            <a href="https://www.facebook.com/arafataivideocreator" target="_blank" rel="noreferrer" className="w-9 h-9 rounded-full bg-slate-800 flex items-center justify-center hover:bg-emerald-600 hover:text-white transition-colors">
              <Facebook size={18} />
            </a>
            <a href="https://www.instagram.com/kashem019928" target="_blank" rel="noreferrer" className="w-9 h-9 rounded-full bg-slate-800 flex items-center justify-center hover:bg-emerald-600 hover:text-white transition-colors">
              <Instagram size={18} />
            </a>
            <a href="https://www.youtube.com/@tamjidislamarafat" target="_blank" rel="noreferrer" className="w-9 h-9 rounded-full bg-slate-800 flex items-center justify-center hover:bg-emerald-600 hover:text-white transition-colors">
              <Youtube size={18} />
            </a>
          </div>
        </div>

        {/* Column 2: Quick Links */}
        <div>
          <h3 className="text-sm font-bold uppercase text-white tracking-wider mb-4 border-l-2 border-emerald-500 pl-2">
            Quick Links
          </h3>
          <ul className="space-y-2.5 text-xs text-slate-400">
            <li><Link to="/" className="hover:text-emerald-400 transition-colors">Home Page</Link></li>
            <li><Link to="/shop" className="hover:text-emerald-400 transition-colors">All Products</Link></li>
            <li><Link to="/offers" className="hover:text-emerald-400 transition-colors">Special Offers & Deals</Link></li>
            <li><Link to="/track" className="hover:text-emerald-400 transition-colors">Track Your Order</Link></li>
            <li><Link to="/blog" className="hover:text-emerald-400 transition-colors">Organic Health Blog</Link></li>
            <li><Link to="/about" className="hover:text-emerald-400 transition-colors">About Our Organic Farm</Link></li>
            <li><Link to="/contact" className="hover:text-emerald-400 transition-colors">Contact Us</Link></li>
          </ul>
        </div>

        {/* Column 3: Customer Policies */}
        <div>
          <h3 className="text-sm font-bold uppercase text-white tracking-wider mb-4 border-l-2 border-emerald-500 pl-2">
            Policies & Info
          </h3>
          <ul className="space-y-2.5 text-xs text-slate-400">
            <li><Link to="/privacy-policy" className="hover:text-emerald-400 transition-colors">Privacy Policy</Link></li>
            <li><Link to="/terms-conditions" className="hover:text-emerald-400 transition-colors">Terms & Conditions</Link></li>
            <li><Link to="/refund-policy" className="hover:text-emerald-400 transition-colors">Refund & Return Policy</Link></li>
            <li><Link to="/shipping-policy" className="hover:text-emerald-400 transition-colors">Shipping & Delivery Info</Link></li>
            <li><Link to="/faq" className="hover:text-emerald-400 transition-colors">Frequently Asked Questions (FAQ)</Link></li>
            <li><Link to="/account" className="hover:text-emerald-400 transition-colors">Customer Account</Link></li>
            <li><Link to="/admin" className="hover:text-emerald-400 text-amber-400 font-medium transition-colors">Admin Portal Login</Link></li>
          </ul>
        </div>

        {/* Column 4: Newsletter */}
        <div>
          <h3 className="text-sm font-bold uppercase text-white tracking-wider mb-4 border-l-2 border-emerald-500 pl-2">
            Join Newsletter
          </h3>
          <p className="text-xs text-slate-400 mb-3">
            Subscribe for seasonal harvest updates, special discounts & organic recipes.
          </p>

          {subscribed ? (
            <div className="p-3 bg-emerald-950/60 border border-emerald-800 text-emerald-400 text-xs rounded-xl font-medium">
              ✓ Thank you! You are subscribed to Organic Mart updates.
            </div>
          ) : (
            <form onSubmit={handleSubscribe} className="space-y-2">
              <input
                type="email"
                placeholder="Enter your email address"
                value={email}
                onChange={e => setEmail(e.target.value)}
                required
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-xs text-white placeholder-slate-500 focus:border-emerald-500 outline-none"
              />
              <button
                type="submit"
                className="w-full bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs py-2.5 rounded-xl flex items-center justify-center gap-2 transition-colors"
              >
                <span>Subscribe Now</span>
                <Send size={14} />
              </button>
            </form>
          )}

          {/* Payment Methods Badges */}
          <div className="mt-6 pt-4 border-t border-slate-800">
            <p className="text-[10px] uppercase font-bold text-slate-400 mb-2">Accepted Payment Methods in Bangladesh</p>
            <div className="flex flex-wrap items-center gap-1.5">
              <span className="px-2 py-1 bg-pink-600 text-white font-bold text-[10px] rounded">bKash</span>
              <span className="px-2 py-1 bg-orange-600 text-white font-bold text-[10px] rounded">Nagad</span>
              <span className="px-2 py-1 bg-purple-700 text-white font-bold text-[10px] rounded">Rocket</span>
              <span className="px-2 py-1 bg-blue-600 text-white font-bold text-[10px] rounded">SSLCommerz</span>
              <span className="px-2 py-1 bg-emerald-700 text-white font-bold text-[10px] rounded">COD</span>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Bar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-12 pt-6 border-t border-slate-800 flex flex-col md:flex-row items-center justify-between text-xs text-slate-500 gap-4">
        <p>© 2026 Organic Mart Bangladesh. All Rights Reserved. Crafted for Healthy Living.</p>
        <div className="flex items-center gap-4 text-slate-400">
          <span>BSTI Certified</span>
          <span>•</span>
          <span>100% Pure Organic Guarantee</span>
        </div>
      </div>
    </footer>
  );
};
