import React, { useState, useEffect } from 'react';
import { ArrowUp, MessageSquare, Phone } from 'lucide-react';

export const FloatingAction: React.FC = () => {
  const [showBackToTop, setShowBackToTop] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 300) {
        setShowBackToTop(true);
      } else {
        setShowBackToTop(false);
      }
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="fixed bottom-6 right-6 z-50 flex flex-col items-center gap-3">
      {/* Floating WhatsApp Button */}
      <a
        href="https://wa.me/8801738019928?text=Hello%20Organic%20Mart!%20I%20have%20an%20inquiry%20about%20organic%20products."
        target="_blank"
        rel="noreferrer"
        className="w-12 h-12 bg-emerald-500 hover:bg-emerald-600 text-white rounded-full flex items-center justify-center shadow-lg shadow-emerald-500/30 hover:scale-110 transition-all duration-300 group relative"
        title="Chat on WhatsApp"
      >
        <Phone size={22} className="fill-current" />
        <span className="absolute right-14 bg-slate-900 text-white text-xs px-2.5 py-1 rounded-lg opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap shadow-md pointer-events-none">
          WhatsApp Support 💬
        </span>
      </a>

      {/* Floating Messenger Button */}
      <a
        href="https://www.facebook.com/arafataivideocreator"
        target="_blank"
        rel="noreferrer"
        className="w-12 h-12 bg-sky-500 hover:bg-sky-600 text-white rounded-full flex items-center justify-center shadow-lg shadow-sky-500/30 hover:scale-110 transition-all duration-300 group relative"
        title="Messenger Support"
      >
        <MessageSquare size={22} />
        <span className="absolute right-14 bg-slate-900 text-white text-xs px-2.5 py-1 rounded-lg opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap shadow-md pointer-events-none">
          Facebook Messenger
        </span>
      </a>

      {/* Back to Top Button */}
      {showBackToTop && (
        <button
          onClick={scrollToTop}
          className="w-11 h-11 bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900 rounded-full flex items-center justify-center shadow-xl hover:scale-110 transition-all duration-300 border border-slate-700 dark:border-slate-300"
          title="Back to Top"
        >
          <ArrowUp size={20} />
        </button>
      )}
    </div>
  );
};
