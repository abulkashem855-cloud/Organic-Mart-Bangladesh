import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { X, Trash2, Plus, Minus, ShoppingBag, ArrowRight, Tag, CheckCircle } from 'lucide-react';
import { useCart } from '../../context/CartContext';

export const CartDrawer: React.FC = () => {
  const {
    cart,
    removeFromCart,
    updateQuantity,
    subtotal,
    shippingZone,
    setShippingZone,
    appliedCoupon,
    applyCoupon,
    removeCoupon,
    isCartDrawerOpen,
    setIsCartDrawerOpen
  } = useCart();

  const navigate = useNavigate();
  const [couponInput, setCouponInput] = useState('');
  const [couponMsg, setCouponMsg] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  const [storeSettings, setStoreSettings] = useState({
    insideDhakaFee: 70,
    outsideDhakaFee: 120,
    freeShippingMin: 1500
  });

  useEffect(() => {
    if (isCartDrawerOpen) {
      fetch('/api/settings')
        .then(r => r.json())
        .then(d => {
          if (d && typeof d.insideDhakaFee === 'number') {
            setStoreSettings(d);
          }
        })
        .catch(() => {});
    }
  }, [isCartDrawerOpen]);

  if (!isCartDrawerOpen) return null;

  const handleApplyCoupon = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!couponInput.trim()) return;
    const res = await applyCoupon(couponInput.trim());
    if (res.success) {
      setCouponMsg({ type: 'success', text: res.message });
      setCouponInput('');
    } else {
      setCouponMsg({ type: 'error', text: res.message });
    }
  };

  const discountVal = appliedCoupon ? appliedCoupon.discountAmount : 0;
  const isInsideDhaka = shippingZone === 'dhaka';
  const insideFee = storeSettings.insideDhakaFee;
  const outsideFee = storeSettings.outsideDhakaFee;
  const freeMin = storeSettings.freeShippingMin || 1500;

  let shippingCharge = 0;
  if (cart.length > 0) {
    if (isInsideDhaka) {
      shippingCharge = (freeMin > 0 && subtotal >= freeMin) ? 0 : insideFee;
    } else {
      shippingCharge = outsideFee;
    }
  }

  const grandTotal = Math.max(0, subtotal - discountVal + shippingCharge);

  return (
    <div className="fixed inset-0 z-50 overflow-hidden">
      {/* Backdrop */}
      <div
        onClick={() => setIsCartDrawerOpen(false)}
        className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm transition-opacity"
      />

      <div className="fixed inset-y-0 right-0 max-w-full flex pl-10">
        <div className="w-screen max-w-md bg-white dark:bg-slate-900 shadow-2xl flex flex-col border-l border-slate-200 dark:border-slate-800">
          {/* Header */}
          <div className="px-6 py-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between bg-slate-50 dark:bg-slate-800/50">
            <div className="flex items-center gap-2">
              <ShoppingBag size={20} className="text-emerald-600" />
              <h2 className="text-lg font-bold text-slate-900 dark:text-white">Your Shopping Cart</h2>
              <span className="bg-emerald-100 dark:bg-emerald-950/80 text-emerald-700 dark:text-emerald-400 text-xs font-bold px-2.5 py-0.5 rounded-full">
                {cart.length} items
              </span>
            </div>
            <button
              onClick={() => setIsCartDrawerOpen(false)}
              className="p-1.5 rounded-full text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-200 dark:hover:bg-slate-800 transition-colors"
            >
              <X size={20} />
            </button>
          </div>

          {/* Cart Items List */}
          <div className="flex-1 overflow-y-auto px-6 py-4 divide-y divide-slate-100 dark:divide-slate-800">
            {cart.length === 0 ? (
              <div className="h-full flex flex-col items-center justify-center text-center py-12">
                <div className="w-20 h-20 rounded-full bg-emerald-50 dark:bg-slate-800 flex items-center justify-center text-emerald-600 dark:text-emerald-400 mb-4">
                  <ShoppingBag size={36} />
                </div>
                <h3 className="text-base font-bold text-slate-900 dark:text-white mb-1">Your Cart is Empty</h3>
                <p className="text-xs text-slate-500 max-w-xs mb-6">
                  Explore our pure organic honey, aromatic rice, cold-pressed oils, and fresh orchard fruits.
                </p>
                <button
                  onClick={() => {
                    setIsCartDrawerOpen(false);
                    navigate('/shop');
                  }}
                  className="bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold px-6 py-3 rounded-xl transition-colors shadow-md shadow-emerald-600/20"
                >
                  Start Organic Shopping
                </button>
              </div>
            ) : (
              cart.map(({ product, quantity }) => {
                const price = product.discountPrice || product.price;
                return (
                  <div key={product.id} className="py-4 flex gap-4 items-center">
                    <img
                      src={product.images[0]}
                      alt={product.name}
                      className="w-16 h-16 rounded-xl object-cover border border-slate-100 dark:border-slate-800 flex-shrink-0"
                    />
                    <div className="flex-1 min-w-0">
                      <h4 className="text-xs font-bold text-slate-900 dark:text-slate-100 truncate mb-1">
                        {product.name}
                      </h4>
                      <p className="text-xs text-slate-500 dark:text-slate-400 mb-2">
                        Unit: {product.unit} • <span className="text-emerald-600 dark:text-emerald-400 font-semibold">৳{price}</span>
                      </p>

                      {/* Quantity Selector */}
                      <div className="flex items-center gap-2">
                        <div className="flex items-center border border-slate-200 dark:border-slate-700 rounded-lg overflow-hidden bg-slate-50 dark:bg-slate-800">
                          <button
                            onClick={() => updateQuantity(product.id, quantity - 1)}
                            className="p-1 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-600 dark:text-slate-300 transition-colors"
                          >
                            <Minus size={12} />
                          </button>
                          <span className="px-3 text-xs font-bold text-slate-800 dark:text-slate-200">
                            {quantity}
                          </span>
                          <button
                            onClick={() => updateQuantity(product.id, quantity + 1)}
                            className="p-1 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-600 dark:text-slate-300 transition-colors"
                          >
                            <Plus size={12} />
                          </button>
                        </div>

                        <span className="text-xs font-bold text-slate-900 dark:text-white ml-auto">
                          ৳{(price * quantity).toLocaleString()}
                        </span>
                      </div>
                    </div>

                    <button
                      onClick={() => removeFromCart(product.id)}
                      className="p-1.5 text-slate-400 hover:text-red-500 transition-colors"
                      title="Remove item"
                    >
                      <Trash2 size={16} />
                    </button>
                  </div>
                );
              })
            )}
          </div>

          {/* Footer & Order Summary */}
          {cart.length > 0 && (
            <div className="px-6 py-4 border-t border-slate-200 dark:border-slate-800 bg-slate-50/80 dark:bg-slate-800/80 space-y-3">
              {/* Coupon Form */}
              <div>
                {appliedCoupon ? (
                  <div className="flex items-center justify-between p-2.5 bg-emerald-100 dark:bg-emerald-950/80 text-emerald-800 dark:text-emerald-300 rounded-xl text-xs font-semibold">
                    <span className="flex items-center gap-1.5">
                      <CheckCircle size={16} className="text-emerald-600" />
                      Coupon <strong className="uppercase">{appliedCoupon.code}</strong> (-৳{appliedCoupon.discountAmount})
                    </span>
                    <button
                      onClick={removeCoupon}
                      className="text-red-600 dark:text-red-400 underline text-[11px] font-bold"
                    >
                      Remove
                    </button>
                  </div>
                ) : (
                  <form onSubmit={handleApplyCoupon} className="flex gap-2">
                    <div className="relative flex-1">
                      <input
                        type="text"
                        placeholder="Coupon (e.g. ORGANIC20)"
                        value={couponInput}
                        onChange={e => setCouponInput(e.target.value)}
                        className="w-full pl-8 pr-3 py-2 text-xs uppercase rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white outline-none focus:border-emerald-500"
                      />
                      <Tag size={14} className="absolute left-2.5 top-2.5 text-slate-400" />
                    </div>
                    <button
                      type="submit"
                      className="px-4 py-2 bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900 text-xs font-bold rounded-xl hover:bg-emerald-600 transition-colors"
                    >
                      Apply
                    </button>
                  </form>
                )}
                {couponMsg && (
                  <p className={`text-[11px] mt-1 font-medium ${couponMsg.type === 'success' ? 'text-emerald-600' : 'text-red-500'}`}>
                    {couponMsg.text}
                  </p>
                )}
              </div>

              {/* Delivery Charge Zone Selector */}
              <div className="pt-2 border-t border-slate-200 dark:border-slate-700">
                <p className="text-[11px] font-bold text-slate-800 dark:text-slate-200 mb-1.5 flex items-center justify-between">
                  <span>Delivery Area:</span>
                  <span className="text-emerald-600 dark:text-emerald-400 font-mono text-[10px]">
                    {isInsideDhaka ? `Inside Dhaka (৳${insideFee})` : `Outside Dhaka (৳${outsideFee})`}
                  </span>
                </p>
                <div className="grid grid-cols-2 gap-2 text-[11px] font-bold">
                  <button
                    type="button"
                    onClick={() => setShippingZone('dhaka')}
                    className={`py-1.5 px-2 rounded-xl border text-center transition-all ${
                      shippingZone === 'dhaka'
                        ? 'bg-emerald-600 text-white border-emerald-600 shadow-sm'
                        : 'bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700 hover:border-emerald-500'
                    }`}
                  >
                    Inside Dhaka (৳{insideFee})
                  </button>
                  <button
                    type="button"
                    onClick={() => setShippingZone('outside')}
                    className={`py-1.5 px-2 rounded-xl border text-center transition-all ${
                      shippingZone === 'outside'
                        ? 'bg-emerald-600 text-white border-emerald-600 shadow-sm'
                        : 'bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700 hover:border-emerald-500'
                    }`}
                  >
                    Outside Dhaka (৳{outsideFee})
                  </button>
                </div>
              </div>

              {/* Price Breakdown */}
              <div className="space-y-1.5 text-xs text-slate-600 dark:text-slate-300 pt-2 border-t border-slate-200 dark:border-slate-700">
                <div className="flex justify-between">
                  <span>Subtotal:</span>
                  <span className="font-semibold text-slate-900 dark:text-white">৳{subtotal.toLocaleString()}</span>
                </div>
                {discountVal > 0 && (
                  <div className="flex justify-between text-emerald-600 font-semibold">
                    <span>Discount:</span>
                    <span>-৳{discountVal.toLocaleString()}</span>
                  </div>
                )}
                <div className="flex justify-between">
                  <span>Delivery Charge ({isInsideDhaka ? 'Dhaka Metro' : 'Outside Dhaka'}):</span>
                  <span className="font-semibold">
                    {shippingCharge === 0 ? <span className="text-emerald-600 font-bold">FREE</span> : `৳${shippingCharge}`}
                  </span>
                </div>
                <div className="flex justify-between text-sm font-extrabold text-slate-900 dark:text-white pt-2 border-t border-slate-200 dark:border-slate-700">
                  <span>Grand Total:</span>
                  <span className="text-emerald-600 dark:text-emerald-400">৳{grandTotal.toLocaleString()}</span>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="grid grid-cols-2 gap-3 pt-2">
                <button
                  onClick={() => {
                    setIsCartDrawerOpen(false);
                    navigate('/cart');
                  }}
                  className="w-full py-3 border border-slate-300 dark:border-slate-700 text-slate-800 dark:text-slate-200 text-xs font-bold rounded-xl hover:bg-slate-200 dark:hover:bg-slate-800 transition-colors text-center"
                >
                  View Full Cart
                </button>
                <button
                  onClick={() => {
                    setIsCartDrawerOpen(false);
                    navigate('/checkout');
                  }}
                  className="w-full py-3 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl transition-colors flex items-center justify-center gap-1.5 shadow-md shadow-emerald-600/20"
                >
                  <span>Checkout Now</span>
                  <ArrowRight size={14} />
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
