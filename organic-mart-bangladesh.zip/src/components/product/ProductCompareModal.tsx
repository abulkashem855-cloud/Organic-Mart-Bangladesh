import React from 'react';
import { X, Trash2, ShoppingCart, Star } from 'lucide-react';
import { useCart } from '../../context/CartContext';

export const ProductCompareModal: React.FC = () => {
  const { compareList, toggleCompare, clearCompare, isCompareOpen, setIsCompareOpen, addToCart } = useCart();

  if (!isCompareOpen) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="relative w-full max-w-5xl bg-white dark:bg-slate-900 rounded-3xl shadow-2xl border border-slate-200 dark:border-slate-800 p-6 max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between pb-4 border-b border-slate-200 dark:border-slate-800">
          <div>
            <h3 className="text-lg font-bold text-slate-900 dark:text-white">Compare Organic Products</h3>
            <p className="text-xs text-slate-500">Side-by-side comparison of selected items ({compareList.length}/4)</p>
          </div>
          <div className="flex items-center gap-2">
            {compareList.length > 0 && (
              <button
                onClick={clearCompare}
                className="text-xs text-red-600 font-semibold hover:underline"
              >
                Clear All
              </button>
            )}
            <button
              onClick={() => setIsCompareOpen(false)}
              className="p-1.5 rounded-full text-slate-400 hover:text-slate-800 dark:hover:text-white transition-colors"
            >
              <X size={20} />
            </button>
          </div>
        </div>

        {compareList.length === 0 ? (
          <div className="text-center py-12">
            <p className="text-sm text-slate-500 font-medium mb-4">No products selected for comparison yet.</p>
            <button
              onClick={() => setIsCompareOpen(false)}
              className="px-6 py-2.5 bg-emerald-600 text-white font-bold rounded-xl text-xs"
            >
              Browse Shop
            </button>
          </div>
        ) : (
          <div className="mt-6 overflow-x-auto">
            <table className="w-full text-left border-collapse min-w-[600px]">
              <thead>
                <tr className="border-b border-slate-200 dark:border-slate-800">
                  <th className="p-3 text-xs font-bold text-slate-400 uppercase w-32">Product</th>
                  {compareList.map(p => (
                    <th key={p.id} className="p-3 text-center min-w-[180px]">
                      <div className="relative group">
                        <button
                          onClick={() => toggleCompare(p)}
                          className="absolute -top-1 -right-1 p-1 bg-red-100 text-red-600 rounded-full hover:bg-red-600 hover:text-white transition-colors"
                          title="Remove from compare"
                        >
                          <Trash2 size={12} />
                        </button>
                        <img src={p.images[0]} alt={p.name} className="w-20 h-20 object-cover rounded-xl mx-auto mb-2 border border-slate-100 dark:border-slate-800" />
                        <h4 className="text-xs font-bold text-slate-900 dark:text-white line-clamp-2">{p.name}</h4>
                      </div>
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800 text-xs">
                <tr>
                  <td className="p-3 font-bold text-slate-500">Price</td>
                  {compareList.map(p => (
                    <td key={p.id} className="p-3 text-center font-black text-emerald-600 dark:text-emerald-400 text-sm">
                      ৳{p.discountPrice || p.price} <span className="text-[10px] text-slate-400 font-normal">/ {p.unit}</span>
                    </td>
                  ))}
                </tr>
                <tr>
                  <td className="p-3 font-bold text-slate-500">Brand</td>
                  {compareList.map(p => (
                    <td key={p.id} className="p-3 text-center text-slate-800 dark:text-slate-200 font-medium">
                      {p.brand}
                    </td>
                  ))}
                </tr>
                <tr>
                  <td className="p-3 font-bold text-slate-500">Rating</td>
                  {compareList.map(p => (
                    <td key={p.id} className="p-3 text-center">
                      <div className="flex items-center justify-center gap-1 text-amber-400 font-bold">
                        <Star size={14} className="fill-amber-400" />
                        <span>{p.rating}</span>
                      </div>
                    </td>
                  ))}
                </tr>
                <tr>
                  <td className="p-3 font-bold text-slate-500">Category</td>
                  {compareList.map(p => (
                    <td key={p.id} className="p-3 text-center text-slate-600 dark:text-slate-400">
                      {p.categoryName}
                    </td>
                  ))}
                </tr>
                <tr>
                  <td className="p-3 font-bold text-slate-500">Stock Status</td>
                  {compareList.map(p => (
                    <td key={p.id} className="p-3 text-center font-bold">
                      <span className={p.stock > 0 ? 'text-emerald-600' : 'text-red-500'}>
                        {p.stock > 0 ? 'In Stock' : 'Out of Stock'}
                      </span>
                    </td>
                  ))}
                </tr>
                <tr>
                  <td className="p-3 font-bold text-slate-500">Action</td>
                  {compareList.map(p => (
                    <td key={p.id} className="p-3 text-center">
                      <button
                        onClick={() => addToCart(p, 1)}
                        className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl text-xs flex items-center justify-center gap-1 mx-auto"
                      >
                        <ShoppingCart size={14} /> Add to Cart
                      </button>
                    </td>
                  ))}
                </tr>
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
