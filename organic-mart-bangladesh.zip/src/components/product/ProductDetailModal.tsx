import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { X, Star, Heart, RefreshCw, ShoppingCart, ShieldCheck, Truck, Check, Share2, Plus, Minus } from 'lucide-react';
import { useCart } from '../../context/CartContext';
import { Product } from '../../types';

export const ProductDetailModal: React.FC = () => {
  const { quickViewProduct, setQuickViewProduct, addToCart, toggleWishlist, isInWishlist, toggleCompare, isInCompare } = useCart();
  const navigate = useNavigate();

  const [selectedImgIndex, setSelectedImgIndex] = useState(0);
  const [quantity, setQuantity] = useState(1);
  const [activeTab, setActiveTab] = useState<'desc' | 'benefits' | 'nutrition' | 'reviews'>('desc');

  // Review submission state
  const [reviewerName, setReviewerName] = useState('');
  const [rating, setRating] = useState(5);
  const [comment, setComment] = useState('');
  const [reviewSubmitted, setReviewSubmitted] = useState(false);

  if (!quickViewProduct) return null;

  const product = quickViewProduct;
  const inWish = isInWishlist(product.id);
  const inComp = isInCompare(product.id);
  const price = product.discountPrice || product.price;

  const handleReviewSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!reviewerName || !comment) return;

    try {
      const res = await fetch(`/api/products/${product.id}/reviews`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userName: reviewerName, rating, comment })
      });

      if (res.ok) {
        const newRev = await res.json();
        product.reviews = [newRev, ...(product.reviews || [])];
        setReviewSubmitted(true);
        setReviewerName('');
        setComment('');
      }
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4 sm:p-6">
      <div className="relative w-full max-w-4xl bg-white dark:bg-slate-900 rounded-3xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden my-8">
        {/* Close Button */}
        <button
          onClick={() => setQuickViewProduct(null)}
          className="absolute top-4 right-4 z-10 p-2 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-500 hover:text-slate-900 dark:hover:text-white transition-colors"
        >
          <X size={20} />
        </button>

        <div className="p-6 sm:p-8 max-h-[85vh] overflow-y-auto">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {/* Image Gallery */}
            <div className="space-y-4">
              <div className="relative aspect-square rounded-2xl overflow-hidden bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-800">
                <img
                  src={product.images[selectedImgIndex] || product.images[0]}
                  alt={product.name}
                  className="w-full h-full object-cover"
                />
                {product.discountPercent && (
                  <span className="absolute top-3 left-3 bg-red-500 text-white font-extrabold text-xs px-3 py-1 rounded-full shadow-md">
                    -{product.discountPercent}% OFF
                  </span>
                )}
              </div>

              {/* Thumbnails */}
              {product.images.length > 1 && (
                <div className="flex gap-3">
                  {product.images.map((img, idx) => (
                    <button
                      key={idx}
                      onClick={() => setSelectedImgIndex(idx)}
                      className={`w-16 h-16 rounded-xl overflow-hidden border-2 transition-all ${
                        selectedImgIndex === idx
                          ? 'border-emerald-500 ring-2 ring-emerald-500/20'
                          : 'border-slate-200 dark:border-slate-800 opacity-60 hover:opacity-100'
                      }`}
                    >
                      <img src={img} alt="" className="w-full h-full object-cover" />
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Product Meta & Actions */}
            <div className="space-y-5">
              <div>
                <span className="text-xs font-bold uppercase tracking-wider text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/60 px-2.5 py-1 rounded-md">
                  {product.categoryName}
                </span>
                <h2 className="text-xl sm:text-2xl font-extrabold text-slate-900 dark:text-white mt-2 leading-tight">
                  {product.name}
                </h2>
                {product.bnName && (
                  <p className="text-sm font-semibold text-emerald-700 dark:text-emerald-300 mt-0.5">
                    {product.bnName}
                  </p>
                )}

                {/* Rating & Stock */}
                <div className="flex items-center gap-4 mt-3 text-xs">
                  <div className="flex items-center gap-1 text-amber-400 font-bold">
                    <Star size={16} className="fill-amber-400" />
                    <span>{product.rating}</span>
                    <span className="text-slate-400 font-normal">({product.reviewCount} reviews)</span>
                  </div>
                  <span className="text-slate-300">•</span>
                  <span className="text-slate-500">SKU: <strong className="text-slate-800 dark:text-slate-200">{product.sku}</strong></span>
                  <span className="text-slate-300">•</span>
                  <span className={product.stock > 0 ? 'text-emerald-600 font-bold' : 'text-red-500 font-bold'}>
                    {product.stock > 0 ? `In Stock (${product.stock})` : 'Out of Stock'}
                  </span>
                </div>
              </div>

              {/* Pricing */}
              <div className="flex items-baseline gap-3 p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-100 dark:border-slate-800">
                <span className="text-2xl sm:text-3xl font-black text-emerald-600 dark:text-emerald-400">
                  ৳{price}
                </span>
                {product.discountPrice && (
                  <span className="text-base text-slate-400 line-through font-semibold">
                    ৳{product.price}
                  </span>
                )}
                <span className="text-xs font-semibold text-slate-500 ml-auto">
                  Unit: <strong className="text-slate-900 dark:text-white">{product.unit}</strong>
                </span>
              </div>

              {/* Quantity Selector & Action Buttons */}
              <div className="space-y-3">
                <div className="flex items-center gap-4">
                  <span className="text-xs font-bold text-slate-700 dark:text-slate-300">Quantity:</span>
                  <div className="flex items-center border border-slate-200 dark:border-slate-700 rounded-xl overflow-hidden bg-slate-50 dark:bg-slate-800">
                    <button
                      onClick={() => setQuantity(Math.max(1, quantity - 1))}
                      className="px-3 py-2 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors"
                    >
                      <Minus size={14} />
                    </button>
                    <span className="px-4 text-xs font-bold text-slate-900 dark:text-white">
                      {quantity}
                    </span>
                    <button
                      onClick={() => setQuantity(quantity + 1)}
                      className="px-3 py-2 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors"
                    >
                      <Plus size={14} />
                    </button>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3 pt-2">
                  <button
                    onClick={() => addToCart(product, quantity)}
                    className="py-3 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl transition-colors flex items-center justify-center gap-2 shadow-md shadow-emerald-600/20"
                  >
                    <ShoppingCart size={16} /> Add to Cart
                  </button>

                  <button
                    onClick={() => {
                      addToCart(product, quantity);
                      setQuickViewProduct(null);
                      navigate('/checkout');
                    }}
                    className="py-3 bg-slate-900 dark:bg-slate-100 hover:bg-emerald-800 text-white dark:text-slate-900 text-xs font-bold rounded-xl transition-colors"
                  >
                    Buy Now
                  </button>
                </div>

                <div className="flex items-center justify-between text-xs pt-2">
                  <button
                    onClick={() => toggleWishlist(product)}
                    className={`flex items-center gap-1.5 font-semibold transition-colors ${
                      inWish ? 'text-red-500' : 'text-slate-600 dark:text-slate-400 hover:text-red-500'
                    }`}
                  >
                    <Heart size={16} className={inWish ? 'fill-red-500' : ''} />
                    <span>{inWish ? 'In Wishlist' : 'Add to Wishlist'}</span>
                  </button>

                  <button
                    onClick={() => toggleCompare(product)}
                    className={`flex items-center gap-1.5 font-semibold transition-colors ${
                      inComp ? 'text-emerald-600' : 'text-slate-600 dark:text-slate-400 hover:text-emerald-600'
                    }`}
                  >
                    <RefreshCw size={16} />
                    <span>{inComp ? 'In Compare' : 'Compare'}</span>
                  </button>
                </div>
              </div>

              {/* Value Badges */}
              <div className="pt-4 border-t border-slate-100 dark:border-slate-800 grid grid-cols-2 gap-2 text-[11px] text-slate-500">
                <span className="flex items-center gap-1.5"><ShieldCheck size={14} className="text-emerald-500" /> BSTI Organic Certified</span>
                <span className="flex items-center gap-1.5"><Truck size={14} className="text-emerald-500" /> Express Dhaka Shipping</span>
              </div>
            </div>
          </div>

          {/* Product Tabs Details */}
          <div className="mt-10 pt-6 border-t border-slate-200 dark:border-slate-800">
            <div className="flex gap-4 border-b border-slate-200 dark:border-slate-800 overflow-x-auto pb-2">
              <button
                onClick={() => setActiveTab('desc')}
                className={`text-xs font-bold pb-2 border-b-2 transition-colors whitespace-nowrap ${
                  activeTab === 'desc'
                    ? 'border-emerald-600 text-emerald-600 dark:text-emerald-400'
                    : 'border-transparent text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
                }`}
              >
                Description
              </button>
              <button
                onClick={() => setActiveTab('benefits')}
                className={`text-xs font-bold pb-2 border-b-2 transition-colors whitespace-nowrap ${
                  activeTab === 'benefits'
                    ? 'border-emerald-600 text-emerald-600 dark:text-emerald-400'
                    : 'border-transparent text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
                }`}
              >
                Health Benefits
              </button>
              <button
                onClick={() => setActiveTab('nutrition')}
                className={`text-xs font-bold pb-2 border-b-2 transition-colors whitespace-nowrap ${
                  activeTab === 'nutrition'
                    ? 'border-emerald-600 text-emerald-600 dark:text-emerald-400'
                    : 'border-transparent text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
                }`}
              >
                Nutrition Info
              </button>
              <button
                onClick={() => setActiveTab('reviews')}
                className={`text-xs font-bold pb-2 border-b-2 transition-colors whitespace-nowrap ${
                  activeTab === 'reviews'
                    ? 'border-emerald-600 text-emerald-600 dark:text-emerald-400'
                    : 'border-transparent text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
                }`}
              >
                Reviews ({product.reviewCount})
              </button>
            </div>

            <div className="pt-4 text-xs leading-relaxed text-slate-600 dark:text-slate-300">
              {activeTab === 'desc' && (
                <div>
                  <p className="mb-3">{product.description}</p>
                  {product.ingredients && (
                    <div className="mt-4 p-3 bg-slate-50 dark:bg-slate-800 rounded-xl">
                      <strong className="text-slate-900 dark:text-white">Ingredients: </strong>
                      {product.ingredients.join(', ')}
                    </div>
                  )}
                </div>
              )}

              {activeTab === 'benefits' && (
                <ul className="space-y-2">
                  {product.benefits?.map((b, i) => (
                    <li key={i} className="flex items-center gap-2 text-slate-800 dark:text-slate-200 font-medium">
                      <Check size={14} className="text-emerald-500" />
                      {b}
                    </li>
                  )) || <li>100% pure organic food product with zero artificial chemical additives.</li>}
                </ul>
              )}

              {activeTab === 'nutrition' && (
                <div className="max-w-md border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden">
                  <table className="w-full text-left border-collapse">
                    <tbody>
                      {product.nutrition ? (
                        Object.entries(product.nutrition).map(([key, val]) => (
                          <tr key={key} className="border-b border-slate-100 dark:border-slate-800">
                            <td className="p-2.5 font-bold text-slate-800 dark:text-slate-200 capitalize">{key}</td>
                            <td className="p-2.5 text-emerald-600 font-semibold">{val}</td>
                          </tr>
                        ))
                      ) : (
                        <tr>
                          <td className="p-3">Nutritional details available on product packaging.</td>
                        </tr>
                      )}
                    </tbody>
                  </table>
                </div>
              )}

              {activeTab === 'reviews' && (
                <div className="space-y-6">
                  {/* Reviews List */}
                  <div className="space-y-3">
                    {product.reviews && product.reviews.length > 0 ? (
                      product.reviews.map(rev => (
                        <div key={rev.id} className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-100 dark:border-slate-800">
                          <div className="flex items-center justify-between mb-1">
                            <span className="font-bold text-slate-900 dark:text-white">{rev.userName}</span>
                            <div className="flex text-amber-400">
                              {[...Array(5)].map((_, i) => (
                                <Star key={i} size={12} className={i < rev.rating ? 'fill-amber-400' : 'text-slate-300'} />
                              ))}
                            </div>
                          </div>
                          <p className="text-slate-600 dark:text-slate-300">{rev.comment}</p>
                          <span className="text-[10px] text-slate-400">{new Date(rev.date).toLocaleDateString()}</span>
                        </div>
                      ))
                    ) : (
                      <p className="text-slate-400">No reviews yet. Be the first to review this organic item!</p>
                    )}
                  </div>

                  {/* Add Review Form */}
                  <div className="p-4 bg-slate-50 dark:bg-slate-800/60 rounded-2xl border border-slate-200 dark:border-slate-700">
                    <h4 className="font-bold text-slate-900 dark:text-white mb-3">Write a Customer Review</h4>
                    {reviewSubmitted ? (
                      <p className="text-emerald-600 font-bold">✓ Thank you! Your review has been added.</p>
                    ) : (
                      <form onSubmit={handleReviewSubmit} className="space-y-3">
                        <div>
                          <label className="block text-[11px] font-bold text-slate-700 dark:text-slate-300 mb-1">Your Name</label>
                          <input
                            type="text"
                            value={reviewerName}
                            onChange={e => setReviewerName(e.target.value)}
                            required
                            className="w-full px-3 py-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 outline-none text-xs"
                          />
                        </div>
                        <div>
                          <label className="block text-[11px] font-bold text-slate-700 dark:text-slate-300 mb-1">Rating</label>
                          <select
                            value={rating}
                            onChange={e => setRating(Number(e.target.value))}
                            className="px-3 py-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 outline-none text-xs"
                          >
                            <option value={5}>⭐⭐⭐⭐⭐ (5 - Excellent)</option>
                            <option value={4}>⭐⭐⭐⭐ (4 - Very Good)</option>
                            <option value={3}>⭐⭐⭐ (3 - Average)</option>
                            <option value={2}>⭐⭐ (2 - Fair)</option>
                            <option value={1}>⭐ (1 - Poor)</option>
                          </select>
                        </div>
                        <div>
                          <label className="block text-[11px] font-bold text-slate-700 dark:text-slate-300 mb-1">Comment</label>
                          <textarea
                            rows={3}
                            value={comment}
                            onChange={e => setComment(e.target.value)}
                            required
                            className="w-full px-3 py-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 outline-none text-xs"
                          />
                        </div>
                        <button
                          type="submit"
                          className="px-5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl text-xs transition-colors"
                        >
                          Submit Review
                        </button>
                      </form>
                    )}
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
