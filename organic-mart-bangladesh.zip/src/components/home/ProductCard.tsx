import React from 'react';
import { Star, Heart, RefreshCw, Eye, ShoppingCart } from 'lucide-react';
import { useCart } from '../../context/CartContext';
import { Product } from '../../types';

interface ProductCardProps {
  product: Product;
}

export const ProductCard: React.FC<ProductCardProps> = ({ product }) => {
  const { addToCart, toggleWishlist, isInWishlist, toggleCompare, isInCompare, setQuickViewProduct } = useCart();

  const isWish = isInWishlist(product.id);
  const isComp = isInCompare(product.id);
  const price = product.discountPrice || product.price;

  return (
    <div className="group relative flex flex-col bg-white dark:bg-slate-800/90 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm hover:shadow-xl hover:border-emerald-500/40 transition-all duration-300 overflow-hidden">
      {/* Product Image Container */}
      <div className="relative aspect-square overflow-hidden bg-slate-50 dark:bg-slate-900">
        <img
          src={product.images[0]}
          alt={product.name}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
        />

        {/* Discount Badge */}
        {product.discountPercent && (
          <span className="absolute top-2.5 left-2.5 bg-red-500 text-white font-extrabold text-[10px] px-2 py-0.5 rounded-full shadow">
            -{product.discountPercent}% OFF
          </span>
        )}

        {/* Quick Actions Floating Overlay */}
        <div className="absolute top-2.5 right-2.5 flex flex-col gap-1.5 opacity-0 group-hover:opacity-100 transition-opacity duration-200">
          <button
            onClick={() => toggleWishlist(product)}
            className={`p-2 rounded-full shadow-md backdrop-blur-md transition-colors ${
              isWish
                ? 'bg-red-500 text-white'
                : 'bg-white/90 dark:bg-slate-800/90 text-slate-600 hover:text-red-500'
            }`}
            title="Wishlist"
          >
            <Heart size={14} className={isWish ? 'fill-current' : ''} />
          </button>

          <button
            onClick={() => toggleCompare(product)}
            className={`p-2 rounded-full shadow-md backdrop-blur-md transition-colors ${
              isComp
                ? 'bg-emerald-600 text-white'
                : 'bg-white/90 dark:bg-slate-800/90 text-slate-600 hover:text-emerald-600'
            }`}
            title="Compare"
          >
            <RefreshCw size={14} />
          </button>

          <button
            onClick={() => setQuickViewProduct(product)}
            className="p-2 bg-white/90 dark:bg-slate-800/90 text-slate-600 hover:text-emerald-600 rounded-full shadow-md backdrop-blur-md transition-colors"
            title="Quick View"
          >
            <Eye size={14} />
          </button>
        </div>
      </div>

      {/* Content */}
      <div className="p-4 flex-1 flex flex-col justify-between">
        <div>
          <div className="flex items-center justify-between text-[10px] text-slate-400 font-semibold mb-1">
            <span className="uppercase tracking-wider text-emerald-600 dark:text-emerald-400">{product.categoryName}</span>
            <span>{product.brand}</span>
          </div>

          <h3
            onClick={() => setQuickViewProduct(product)}
            className="text-xs font-bold text-slate-900 dark:text-slate-100 group-hover:text-emerald-600 transition-colors cursor-pointer line-clamp-2 min-h-[32px]"
          >
            {product.name}
          </h3>

          {product.bnName && (
            <p className="text-[11px] font-medium text-emerald-700 dark:text-emerald-400 truncate mt-0.5">
              {product.bnName}
            </p>
          )}

          {/* Rating */}
          <div className="flex items-center gap-1 text-[11px] text-amber-400 font-bold mt-1.5">
            <Star size={12} className="fill-amber-400" />
            <span>{product.rating}</span>
            <span className="text-slate-400 font-normal">({product.reviewCount})</span>
          </div>
        </div>

        {/* Pricing & Add to Cart */}
        <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between">
          <div>
            <div className="flex items-baseline gap-1.5">
              <span className="text-base font-extrabold text-emerald-600 dark:text-emerald-400">
                ৳{price}
              </span>
              {product.discountPrice && (
                <span className="text-xs text-slate-400 line-through">
                  ৳{product.price}
                </span>
              )}
            </div>
            <span className="text-[10px] text-slate-400 block font-medium">Unit: {product.unit}</span>
          </div>

          <button
            onClick={() => addToCart(product, 1)}
            className="p-2.5 bg-emerald-600 hover:bg-emerald-700 active:scale-95 text-white rounded-xl shadow-md shadow-emerald-600/20 transition-all"
            title="Add to Cart"
          >
            <ShoppingCart size={16} />
          </button>
        </div>
      </div>
    </div>
  );
};
