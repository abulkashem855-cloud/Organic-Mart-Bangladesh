import React from 'react';
import { Star, Quote, CheckCircle } from 'lucide-react';

export const Testimonials: React.FC = () => {
  const reviews = [
    {
      id: 1,
      name: 'Tanvir Ahmed',
      location: 'Gulshan, Dhaka',
      role: 'Verified Buyer',
      image: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
      comment: 'The Sundarban honey from Organic Mart is 100% authentic. It has that distinct wild aroma and rich thickness. Delivery in Gulshan took less than 2 hours!',
      rating: 5,
      product: 'Pure Sundarban Wild Honey'
    },
    {
      id: 2,
      name: 'Nusrat Jahan',
      location: 'Dhanmondi, Dhaka',
      role: 'Verified Buyer',
      image: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
      comment: 'Finally found real Ghani mustard oil! Cooking bhorta and fish curry with this oil brings back childhood village memories. Smells incredible.',
      rating: 5,
      product: 'Kachi Ghani Mustard Oil'
    },
    {
      id: 3,
      name: 'Dr. Shahriar Rahman',
      location: 'Uttara, Dhaka',
      role: 'Verified Buyer',
      image: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&auto=format&fit=crop&q=80',
      comment: 'As a doctor, I strictly recommend organic unpolished red rice for diabetes control. The quality and cleanliness from Organic Mart is top notch.',
      rating: 5,
      product: 'Organic Red Rice / Lal Chawl'
    }
  ];

  return (
    <section className="py-12">
      <div className="text-center max-w-2xl mx-auto mb-10">
        <span className="text-xs font-bold text-emerald-600 dark:text-emerald-400 uppercase tracking-wider">
          Customer Love
        </span>
        <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white mt-1">
          Loved by 25,000+ Bangladeshi Families
        </h2>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {reviews.map(r => (
          <div
            key={r.id}
            className="p-6 rounded-3xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-800 shadow-sm relative flex flex-col justify-between"
          >
            <Quote size={36} className="text-emerald-100 dark:text-slate-700 absolute top-4 right-4" />

            <div>
              <div className="flex text-amber-400 mb-3">
                {[...Array(r.rating)].map((_, i) => (
                  <Star key={i} size={16} className="fill-amber-400" />
                ))}
              </div>
              <p className="text-xs leading-relaxed text-slate-600 dark:text-slate-300 italic mb-4">
                "{r.comment}"
              </p>
            </div>

            <div className="flex items-center gap-3 pt-4 border-t border-slate-100 dark:border-slate-700/60">
              <img src={r.image} alt={r.name} className="w-10 h-10 rounded-full object-cover border border-emerald-500" />
              <div>
                <h4 className="text-xs font-bold text-slate-900 dark:text-white flex items-center gap-1">
                  {r.name} <CheckCircle size={12} className="text-emerald-500" />
                </h4>
                <p className="text-[10px] text-slate-400">{r.location} • Bought {r.product}</p>
              </div>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
};
