import React, { useState } from 'react';
import { ChevronDown, HelpCircle } from 'lucide-react';

export const FaqSection: React.FC = () => {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  const faqs = [
    {
      q: 'How do you guarantee that your honey is 100% pure Sundarban honey?',
      a: 'Our honey is collected directly by licensed Moumachi honey hunters from deep Sundarban mangrove forests. Each batch undergoes moisture & pollen lab tests before bottling without heat processing or syrup blending.'
    },
    {
      q: 'What are the delivery charges and delivery times for Dhaka and outside Dhaka?',
      a: 'Inside Dhaka City, we provide Express 2-Hour Delivery for ৳70 (FREE on orders over ৳1500). Outside Dhaka, shipping takes 24-48 hours via Pathao or RedX courier for ৳130.'
    },
    {
      q: 'Which payment methods do you accept?',
      a: 'We accept bKash, Nagad, Rocket, SSLCommerz (Visa, Mastercard, City Bank, BRAC Bank), Cash On Delivery (COD), and direct Bank Transfer.'
    },
    {
      q: 'What is your return and refund policy if a product arrives damaged?',
      a: 'We offer an instant 7-day hassle-free return and replacement policy. If any jar or package is damaged during courier transit, contact us on WhatsApp (+880 1711-000000) for instant free replacement or refund.'
    },
    {
      q: 'Are your spices and oils completely chemical-free?',
      a: 'Yes! Our turmeric, red chili, and coriander are sun-dried and stone ground without synthetic dye polishing. Our mustard oil is cold-pressed in wooden Ghani at low temperature.'
    }
  ];

  return (
    <section className="py-12 my-6">
      <div className="text-center max-w-2xl mx-auto mb-8">
        <span className="text-xs font-bold text-emerald-600 dark:text-emerald-400 uppercase tracking-wider flex items-center justify-center gap-1">
          <HelpCircle size={14} /> Got Questions?
        </span>
        <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white mt-1">
          Frequently Asked Questions
        </h2>
      </div>

      <div className="max-w-3xl mx-auto space-y-3">
        {faqs.map((faq, idx) => {
          const isOpen = openIndex === idx;
          return (
            <div
              key={idx}
              className="rounded-2xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-800 overflow-hidden shadow-sm transition-all"
            >
              <button
                onClick={() => setOpenIndex(isOpen ? null : idx)}
                className="w-full text-left p-4 sm:p-5 flex items-center justify-between font-bold text-xs sm:text-sm text-slate-900 dark:text-white hover:text-emerald-600 transition-colors"
              >
                <span>{faq.q}</span>
                <ChevronDown
                  size={18}
                  className={`text-slate-400 transition-transform duration-300 ${
                    isOpen ? 'rotate-180 text-emerald-600' : ''
                  }`}
                />
              </button>

              {isOpen && (
                <div className="px-4 pb-5 sm:px-5 text-xs text-slate-600 dark:text-slate-300 border-t border-slate-100 dark:border-slate-700/60 pt-3 leading-relaxed">
                  {faq.a}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </section>
  );
};
