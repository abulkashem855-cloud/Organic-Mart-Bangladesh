import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, ChevronLeft, ChevronRight, ShieldCheck, Sparkles } from 'lucide-react';

interface Slide {
  id: number;
  title: string;
  bnTitle: string;
  subtitle: string;
  badge: string;
  image: string;
  ctaText: string;
  ctaLink: string;
  bgGradient: string;
}

const slides: Slide[] = [
  {
    id: 1,
    title: '100% Pure Sundarban Wild Honey',
    bnTitle: 'সুন্দরবনের খাঁটি প্রাকৃতিক মধু',
    subtitle: 'Collected naturally by Moumachi honey hunters. Rich in immune-boosting antioxidants & natural enzymes.',
    badge: '10% OFF TODAY',
    image: 'https://images.unsplash.com/photo-1587049352846-4a222e784d38?w=1200&auto=format&fit=crop&q=80',
    ctaText: 'Shop Honey Collection',
    ctaLink: '/shop?category=honey',
    bgGradient: 'from-emerald-950/80 via-emerald-900/60 to-transparent'
  },
  {
    id: 2,
    title: 'Fragrant Kalijira & Unpolished Red Rice',
    bnTitle: 'সুগন্ধি কালিজিরা ও দেশি লাল চাল',
    subtitle: 'Grown naturally in Sherpur without chemical fertilizers. Perfect for royal Polao, Biryani & Firni.',
    badge: 'FRESH HARVEST',
    image: 'https://images.unsplash.com/photo-1586201375761-83865001e31c?w=1200&auto=format&fit=crop&q=80',
    ctaText: 'Explore Organic Rice',
    ctaLink: '/shop?category=rice',
    bgGradient: 'from-emerald-950/80 via-emerald-900/60 to-transparent'
  },
  {
    id: 3,
    title: 'Cold-Pressed Wooden Ghani Mustard Oil',
    bnTitle: 'গাছের ঘানি ভাঙা খাঁটি সরিষার তেল',
    subtitle: 'Extracted slowly at low temperature to preserve natural aroma, heart health fats & traditional flavor.',
    badge: 'BESTSELLER',
    image: 'https://images.unsplash.com/photo-1474979266404-7eaacbcd87c5?w=1200&auto=format&fit=crop&q=80',
    ctaText: 'Buy Ghani Oil',
    ctaLink: '/shop?category=oil',
    bgGradient: 'from-emerald-950/80 via-emerald-900/60 to-transparent'
  }
];

export const HeroSlider: React.FC = () => {
  const [currentSlide, setCurrentSlide] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentSlide(prev => (prev + 1) % slides.length);
    }, 6000);
    return () => clearInterval(timer);
  }, []);

  const nextSlide = () => setCurrentSlide((currentSlide + 1) % slides.length);
  const prevSlide = () => setCurrentSlide((currentSlide - 1 + slides.length) % slides.length);

  const slide = slides[currentSlide];

  return (
    <div className="relative w-full h-[460px] sm:h-[520px] rounded-3xl overflow-hidden shadow-2xl my-4 border border-slate-200 dark:border-slate-800">
      {/* Background Image */}
      <img
        src={slide.image}
        alt={slide.title}
        className="absolute inset-0 w-full h-full object-cover transition-all duration-700 scale-105"
      />

      {/* Dark Overlay Gradient */}
      <div className={`absolute inset-0 bg-gradient-to-r ${slide.bgGradient}`} />

      {/* Slide Content */}
      <div className="relative z-10 h-full max-w-7xl mx-auto px-6 sm:px-12 flex flex-col justify-center max-w-2xl text-white">
        <div className="inline-flex items-center gap-2 bg-emerald-500/90 text-white px-3 py-1 rounded-full text-xs font-bold w-fit mb-3 shadow-md backdrop-blur-sm">
          <Sparkles size={14} className="text-lime-300" />
          <span>{slide.badge}</span>
        </div>

        <h1 className="text-2xl sm:text-4xl lg:text-5xl font-black leading-tight tracking-tight drop-shadow-md">
          {slide.title}
        </h1>

        <p className="text-sm sm:text-base font-semibold text-emerald-300 mt-1">
          {slide.bnTitle}
        </p>

        <p className="text-xs sm:text-sm text-slate-200 mt-3 leading-relaxed line-clamp-3">
          {slide.subtitle}
        </p>

        <div className="mt-6 flex items-center gap-4">
          <Link
            to={slide.ctaLink}
            className="px-6 py-3 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs sm:text-sm rounded-xl flex items-center gap-2 transition-all shadow-lg shadow-emerald-600/30 hover:scale-105"
          >
            <span>{slide.ctaText}</span>
            <ArrowRight size={16} />
          </Link>

          <span className="hidden sm:flex items-center gap-1.5 text-xs text-slate-300 font-medium">
            <ShieldCheck size={16} className="text-emerald-400" /> BSTI Lab Certified
          </span>
        </div>
      </div>

      {/* Slider Controls */}
      <button
        onClick={prevSlide}
        className="absolute left-4 top-1/2 -translate-y-1/2 p-2.5 rounded-full bg-slate-900/50 hover:bg-emerald-600 text-white transition-colors backdrop-blur-sm"
      >
        <ChevronLeft size={20} />
      </button>

      <button
        onClick={nextSlide}
        className="absolute right-4 top-1/2 -translate-y-1/2 p-2.5 rounded-full bg-slate-900/50 hover:bg-emerald-600 text-white transition-colors backdrop-blur-sm"
      >
        <ChevronRight size={20} />
      </button>

      {/* Dots Indicator */}
      <div className="absolute bottom-5 left-1/2 -translate-x-1/2 flex gap-2">
        {slides.map((s, idx) => (
          <button
            key={s.id}
            onClick={() => setCurrentSlide(idx)}
            className={`h-2.5 rounded-full transition-all ${
              currentSlide === idx ? 'w-8 bg-lime-400' : 'w-2.5 bg-white/50 hover:bg-white'
            }`}
          />
        ))}
      </div>
    </div>
  );
};
