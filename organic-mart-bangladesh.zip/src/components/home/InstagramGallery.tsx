import React from 'react';
import { Instagram } from 'lucide-react';

export const InstagramGallery: React.FC = () => {
  const images = [
    { url: 'https://images.unsplash.com/photo-1540420773420-3366772f4999?w=500&auto=format&fit=crop&q=80', tag: '#OrganicHarvest' },
    { url: 'https://images.unsplash.com/photo-1587049352846-4a222e784d38?w=500&auto=format&fit=crop&q=80', tag: '#SundarbanHoney' },
    { url: 'https://images.unsplash.com/photo-1586201375761-83865001e31c?w=500&auto=format&fit=crop&q=80', tag: '#KalijiraRice' },
    { url: 'https://images.unsplash.com/photo-1474979266404-7eaacbcd87c5?w=500&auto=format&fit=crop&q=80', tag: '#KachiGhani' },
    { url: 'https://images.unsplash.com/photo-1610832958506-aa56368176cf?w=500&auto=format&fit=crop&q=80', tag: '#RajshahiMango' },
    { url: 'https://images.unsplash.com/photo-1576092768241-dec231879fc3?w=500&auto=format&fit=crop&q=80', tag: '#SreemangalTea' }
  ];

  return (
    <section className="py-10">
      <div className="text-center mb-8">
        <span className="text-xs font-bold text-emerald-600 dark:text-emerald-400 uppercase tracking-wider flex items-center justify-center gap-1">
          <Instagram size={14} /> Follow Us On Instagram @OrganicMartBD
        </span>
        <h2 className="text-xl sm:text-2xl font-extrabold text-slate-900 dark:text-white mt-1">
          Farm Fresh Moments & Harvest Stories
        </h2>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-3">
        {images.map((img, i) => (
          <a
            key={i}
            href="https://instagram.com"
            target="_blank"
            rel="noreferrer"
            className="group relative aspect-square rounded-2xl overflow-hidden border border-slate-200 dark:border-slate-800 shadow-sm"
          >
            <img src={img.url} alt="" className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" />
            <div className="absolute inset-0 bg-emerald-950/70 opacity-0 group-hover:opacity-100 transition-opacity flex flex-col items-center justify-center text-white p-2 text-center">
              <Instagram size={24} className="mb-1" />
              <span className="text-[10px] font-bold">{img.tag}</span>
            </div>
          </a>
        ))}
      </div>
    </section>
  );
};
