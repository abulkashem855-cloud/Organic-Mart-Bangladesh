import React from 'react';
import { ShieldCheck, Sprout, Truck, CreditCard, Award, HeartHandshake } from 'lucide-react';

export const WhyChooseUs: React.FC = () => {
  const features = [
    {
      icon: <Sprout className="text-emerald-500" size={32} />,
      title: 'Direct From Rural Organic Farms',
      desc: 'We source directly from chemical-free partner orchards in Rajshahi, Sherpur, Sundarbans & Sylhet.'
    },
    {
      icon: <ShieldCheck className="text-emerald-500" size={32} />,
      title: 'BSTI & Lab Tested Purity',
      desc: '100% free from formalin, calcium carbide, artificial color dyes, or heavy metal residues.'
    },
    {
      icon: <Truck className="text-emerald-500" size={32} />,
      title: 'Express 2-Hour Dhaka Delivery',
      desc: 'Temperature controlled eco-friendly packaging ensuring fresh farm arrival at your doorstep.'
    },
    {
      icon: <CreditCard className="text-emerald-500" size={32} />,
      title: 'bKash, Nagad & Cash On Delivery',
      desc: 'Pay easily with bKash, Nagad, Rocket, credit cards, or cash when receiving your items.'
    },
    {
      icon: <Award className="text-emerald-500" size={32} />,
      title: '100% Satisfaction Guarantee',
      desc: 'If you are dissatisfied with product quality, enjoy our instant 7-day no-questions refund.'
    },
    {
      icon: <HeartHandshake className="text-emerald-500" size={32} />,
      title: 'Empowering Bangladeshi Farmers',
      desc: 'Every purchase directly supports fair wages and sustainable organic farming communities.'
    }
  ];

  return (
    <section className="py-12 my-6 bg-slate-50 dark:bg-slate-800/40 rounded-3xl p-8 border border-slate-200 dark:border-slate-800">
      <div className="text-center max-w-2xl mx-auto mb-10">
        <span className="text-xs font-bold text-emerald-600 dark:text-emerald-400 uppercase tracking-wider">
          Why Choose Organic Mart
        </span>
        <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white mt-1">
          Purity, Freshness & Trust You Can Taste
        </h2>
        <p className="text-xs text-slate-500 dark:text-slate-400 mt-2">
          Promoting healthy living across Bangladesh through unadulterated organic nutrition.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {features.map((f, i) => (
          <div
            key={i}
            className="p-6 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-800 shadow-sm hover:shadow-md transition-all"
          >
            <div className="w-14 h-14 rounded-2xl bg-emerald-50 dark:bg-emerald-950/60 flex items-center justify-center mb-4">
              {f.icon}
            </div>
            <h3 className="text-sm font-bold text-slate-900 dark:text-white mb-1.5">{f.title}</h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">{f.desc}</p>
          </div>
        ))}
      </div>
    </section>
  );
};
