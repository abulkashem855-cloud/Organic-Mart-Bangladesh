import React from 'react';
import { Link } from 'react-router-dom';
import { Category } from '../../types';

interface Props {
  categories: Category[];
}

export const CategoryGrid: React.FC<Props> = ({ categories }) => {
  return (
    <section className="py-10">
      <div className="flex flex-col md:flex-row md:items-end justify-between mb-8">
        <div>
          <span className="text-xs font-bold text-emerald-600 dark:text-emerald-400 uppercase tracking-wider">
            Pure & Chemical Free
          </span>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white mt-1">
            Featured Organic Categories
          </h2>
        </div>
        <Link
          to="/shop"
          className="text-xs font-bold text-emerald-600 dark:text-emerald-400 hover:underline mt-2 md:mt-0 flex items-center gap-1"
        >
          View All Categories →
        </Link>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
        {categories.map(cat => (
          <Link
            key={cat.id}
            to={`/shop?category=${cat.id}`}
            className="group relative flex flex-col items-center p-4 rounded-2xl bg-white dark:bg-slate-800/80 border border-slate-200 dark:border-slate-800 shadow-sm hover:shadow-xl hover:border-emerald-500/50 hover:-translate-y-1 transition-all duration-300 text-center overflow-hidden"
          >
            <div className="w-16 h-16 rounded-full overflow-hidden mb-3 border-2 border-emerald-100 dark:border-slate-700 group-hover:scale-110 transition-transform">
              <img
                src={cat.image}
                alt={cat.name}
                className="w-full h-full object-cover"
              />
            </div>
            <h3 className="text-xs font-bold text-slate-900 dark:text-slate-100 group-hover:text-emerald-600 transition-colors">
              {cat.name}
            </h3>
            <p className="text-[11px] font-medium text-emerald-600 dark:text-emerald-400 mt-0.5">
              {cat.bnName}
            </p>
            <span className="mt-2 text-[10px] text-slate-400 bg-slate-100 dark:bg-slate-700/60 px-2 py-0.5 rounded-full font-semibold">
              {cat.itemCount} items
            </span>
          </Link>
        ))}
      </div>
    </section>
  );
};
