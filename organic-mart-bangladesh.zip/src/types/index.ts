export interface StoreSettings {
  insideDhakaFee: number;
  outsideDhakaFee: number;
  freeShippingMin?: number;
}

export type CategoryId = string;

export interface Category {
  id: CategoryId;
  name: string;
  bnName: string;
  icon: string;
  image: string;
  description: string;
  itemCount: number;
}

export interface Review {
  id: string;
  userName: string;
  userAvatar?: string;
  rating: number;
  comment: string;
  date: string;
  verifiedPurchase?: boolean;
}

export interface Product {
  id: string;
  name: string;
  bnName?: string;
  sku: string;
  categoryId: CategoryId;
  categoryName: string;
  brand: string;
  price: number; // in BDT
  discountPrice?: number; // discounted price in BDT
  discountPercent?: number;
  rating: number;
  reviewCount: number;
  stock: number;
  unit: string; // e.g., '1 kg', '500g', '1 Dozen', '1 Liter'
  images: string[];
  featured?: boolean;
  bestSeller?: boolean;
  todayDeal?: boolean;
  seasonal?: boolean;
  newArrival?: boolean;
  description: string;
  ingredients?: string[];
  benefits?: string[];
  nutrition?: Record<string, string>; // e.g. { Calories: '120 kcal', Fat: '0.2g' }
  reviews?: Review[];
  tags?: string[];
  createdAt: string;
}

export interface CartItem {
  product: Product;
  quantity: number;
}

export interface Coupon {
  code: string;
  discountType: 'percent' | 'fixed';
  discountValue: number;
  minSpend: number;
  maxDiscount?: number;
  expiryDate: string;
  active: boolean;
}

export interface User {
  id: string;
  name: string;
  email: string;
  phone?: string;
  role: 'user' | 'admin';
  avatar?: string;
  addresses?: ShippingAddress[];
  createdAt: string;
}

export interface ShippingAddress {
  id: string;
  fullName: string;
  phone: string;
  division: string;
  district: string;
  thana: string;
  address: string;
  isDefault?: boolean;
}

export type PaymentMethod = 'bkash' | 'nagad' | 'rocket' | 'sslcommerz' | 'cod' | 'bank';

export type OrderStatus = 'Pending' | 'Confirmed' | 'Packed' | 'Shipped' | 'Delivered' | 'Cancelled' | 'Refunded';

export interface OrderItem {
  productId: string;
  name: string;
  price: number;
  quantity: number;
  image: string;
  unit: string;
}

export interface Order {
  id: string; // e.g. OMB-2026-9821
  userId?: string;
  customerName: string;
  customerEmail: string;
  customerPhone: string;
  shippingAddress: ShippingAddress;
  items: OrderItem[];
  subtotal: number;
  discount: number;
  couponCode?: string;
  shippingCharge: number;
  tax: number;
  grandTotal: number;
  paymentMethod: PaymentMethod;
  paymentStatus: 'Pending' | 'Paid' | 'Failed';
  transactionId?: string;
  status: OrderStatus;
  statusHistory: { status: OrderStatus; timestamp: string; note?: string }[];
  deliveryCourier?: string;
  trackingNumber?: string;
  createdAt: string;
  updatedAt: string;
}

export interface BlogPost {
  id: string;
  title: string;
  slug: string;
  excerpt: string;
  content: string;
  author: string;
  category: string;
  image: string;
  readTime: string;
  date: string;
  tags: string[];
}

export interface ContactMessage {
  id: string;
  name: string;
  email: string;
  phone: string;
  subject: string;
  message: string;
  date: string;
  read: boolean;
}

export interface DashboardStats {
  todaySales: number;
  monthlySales: number;
  totalOrders: number;
  totalRevenue: number;
  totalVisitors: number;
  activeProducts: number;
  totalCustomers: number;
  recentOrders: Order[];
  topSellingProducts: { product: Product; totalQuantitySold: number; totalRevenue: number }[];
  salesByMonth: { month: string; sales: number }[];
}
