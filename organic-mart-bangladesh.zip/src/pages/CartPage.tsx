import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { ShoppingBag, Trash2, Plus, Minus, ArrowRight, Tag, ShieldCheck, Truck } from 'lucide-react';
import { useCart } from '../context/CartContext';
import { StoreSettings } from '../types';

export const CartPage: React.FC = () => {
  const {
    cart,
    removeFromCart,
    updateQuantity,
    subtotal,
    shippingZone,
    setShippingZone,
    appliedCoupon,
    applyCoupon,
    removeCoupon
  } = useCart();

  const navigate = useNavigate();
  const [couponInput, setCouponInput] = useState('');
  const [couponMsg, setCouponMsg] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  const [storeSettings, setStoreSettings] = useState<StoreSettings>({
    insideDhakaFee: 70,
    outsideDhakaFee: 120,
    freeShippingMin: 1500
  });

  useEffect(() => {
    fetch('/api/settings')
      .then(res => res.json())
      .then(data => {
        if (data && typeof data.insideDhakaFee === 'number') {
          setStoreSettings(data);
        }
      })
      .catch(() => {});
  }, []);

  const handleApplyCoupon = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!couponInput.trim()) return;
    const res = await applyCoupon(couponInput.trim());
    if (res.success) {
      setCouponMsg({ type: 'success', text: res.message });
      setCouponInput('');
    } else {
      setCouponMsg({ type: 'error', text: res.message });
    }
  };

  const discountVal = appliedCoupon ? appliedCoupon.discountAmount : 0;
  const freeMin = storeSettings.freeShippingMin || 1500;
  const insideFee = storeSettings.insideDhakaFee;
  const outsideFee = storeSettings.outsideDhakaFee;

  let shippingCharge = 0;
  if (cart.length > 0) {
    if (shippingZone === 'dhaka') {
      shippingCharge = freeMin > 0 && subtotal >= freeMin ? 0 : insideFee;
    } else {
      shippingCharge = outsideFee;
    }
  }

  const grandTotal = Math.max(0, subtotal - discountVal + shippingCharge);

  if (cart.length === 0) {
    return (
      <div className="max-w-3xl mx-auto px-4 py-16 text-center space-y-4">
        <div className="w-24 h-24 rounded-full bg-emerald-50 dark:bg-slate-800 text-emerald-600 flex items-center justify-center mx-auto mb-4">
          <ShoppingBag size={48} />
        </div>
        <h1 className="text-2xl font-black text-slate-900 dark:text-white">Your Shopping Cart is Empty</h1>
        <p className="text-xs text-slate-500 max-w-sm mx-auto">
          Start adding pure Sundarban honey, unpolished red rice, Ghani mustard oil, and fresh fruits to your cart.
        </p>
        <Link
          to="/shop"
          className="inline-flex items-center gap-2 px-8 py-3.5 bg-emerald-600 text-white font-extrabold text-xs rounded-2xl hover:bg-emerald-700 transition-colors shadow-lg shadow-emerald-600/20"
        >
          Explore Shop
        </Link>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8">
      <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white">
        Shopping Cart ({cart.length} items)
      </h1>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Cart Items Table */}
        <div className="lg:col-span-2 space-y-4">
          <div className="bg-white dark:bg-slate-800 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden divide-y divide-slate-100 dark:divide-slate-800">
            {cart.map(({ product, quantity }) => {
              const price = product.discountPrice || product.price;
              return (
                <div key={product.id} className="p-4 sm:p-6 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                  <div className="flex items-center gap-4 flex-1 min-w-0">
                    <img
                      src={product.images[0]}
                      alt={product.name}
                      className="w-20 h-20 rounded-2xl object-cover border border-slate-100 dark:border-slate-800 flex-shrink-0"
                    />
                    <div className="min-w-0">
                      <span className="text-[10px] font-bold uppercase text-emerald-600">{product.categoryName}</span>
                      <h3 className="text-sm font-bold text-slate-900 dark:text-white truncate">{product.name}</h3>
                      <p className="text-xs text-slate-500 mt-0.5">Unit: {product.unit} • Price: ৳{price}</p>
                    </div>
                  </div>

                  <div className="flex items-center justify-between w-full sm:w-auto gap-6 pt-2 sm:pt-0 border-t sm:border-t-0 border-slate-100 dark:border-slate-800">
                    {/* Quantity Control */}
                    <div className="flex items-center border border-slate-200 dark:border-slate-700 rounded-xl overflow-hidden bg-slate-50 dark:bg-slate-900">
                      <button
                        onClick={() => updateQuantity(product.id, quantity - 1)}
                        className="p-1.5 hover:bg-slate-200 dark:hover:bg-slate-800 text-slate-600 dark:text-slate-300"
                      >
                        <Minus size={14} />
                      </button>
                      <span className="px-3 text-xs font-bold text-slate-900 dark:text-white">{quantity}</span>
                      <button
                        onClick={() => updateQuantity(product.id, quantity + 1)}
                        className="p-1.5 hover:bg-slate-200 dark:hover:bg-slate-800 text-slate-600 dark:text-slate-300"
                      >
                        <Plus size={14} />
                      </button>
                    </div>

                    <span className="text-sm font-black text-slate-900 dark:text-white min-w-[70px] text-right">
                      ৳{(price * quantity).toLocaleString()}
                    </span>

                    <button
                      onClick={() => removeFromCart(product.id)}
                      className="p-1.5 text-slate-400 hover:text-red-500 transition-colors"
                      title="Remove"
                    >
                      <Trash2 size={18} />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Summary Sidebar */}
        <div className="space-y-6">
          <div className="bg-white dark:bg-slate-800 p-6 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-6">
            <h2 className="text-base font-bold text-slate-900 dark:text-white border-b border-slate-100 dark:border-slate-800 pb-3">
              Order Summary
            </h2>

            {/* Shipping Zone Switcher */}
            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-2 flex items-center gap-1.5">
                <Truck size={14} className="text-emerald-600" /> Delivery Zone
              </label>
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => setShippingZone('dhaka')}
                  className={`p-2.5 rounded-xl text-xs font-bold border transition-colors ${
                    shippingZone === 'dhaka'
                      ? 'bg-emerald-600 text-white border-emerald-600'
                      : 'bg-slate-50 dark:bg-slate-900 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700'
                  }`}
                >
                  Inside Dhaka (৳{insideFee})
                </button>

                <button
                  type="button"
                  onClick={() => setShippingZone('outside')}
                  className={`p-2.5 rounded-xl text-xs font-bold border transition-colors ${
                    shippingZone === 'outside'
                      ? 'bg-emerald-600 text-white border-emerald-600'
                      : 'bg-slate-50 dark:bg-slate-900 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700'
                  }`}
                >
                  Outside Dhaka (৳{outsideFee})
                </button>
              </div>
            </div>

            {/* Coupon Code Input */}
            <div>
              {appliedCoupon ? (
                <div className="p-3 bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300 rounded-2xl text-xs font-semibold flex items-center justify-between">
                  <span>Coupon <strong>{appliedCoupon.code}</strong> (-৳{appliedCoupon.discountAmount})</span>
                  <button onClick={removeCoupon} className="text-red-600 underline font-bold">Remove</button>
                </div>
              ) : (
                <form onSubmit={handleApplyCoupon} className="flex gap-2">
                  <div className="relative flex-1">
                    <input
                      type="text"
                      placeholder="Coupon Code"
                      value={couponInput}
                      onChange={e => setCouponInput(e.target.value)}
                      className="w-full pl-8 pr-3 py-2 text-xs uppercase rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-slate-900 dark:text-white outline-none focus:border-emerald-500"
                    />
                    <Tag size={14} className="absolute left-2.5 top-2.5 text-slate-400" />
                  </div>
                  <button
                    type="submit"
                    className="px-4 py-2 bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900 text-xs font-bold rounded-xl"
                  >
                    Apply
                  </button>
                </form>
              )}
              {couponMsg && (
                <p className={`text-[11px] mt-1 font-medium ${couponMsg.type === 'success' ? 'text-emerald-600' : 'text-red-500'}`}>
                  {couponMsg.text}
                </p>
              )}
            </div>

            {/* Price Calculations */}
            <div className="space-y-2 text-xs text-slate-600 dark:text-slate-300 pt-2 border-t border-slate-100 dark:border-slate-800">
              <div className="flex justify-between">
                <span>Items Subtotal:</span>
                <span className="font-bold text-slate-900 dark:text-white">৳{subtotal.toLocaleString()}</span>
              </div>
              {discountVal > 0 && (
                <div className="flex justify-between text-emerald-600 font-bold">
                  <span>Coupon Discount:</span>
                  <span>-৳{discountVal.toLocaleString()}</span>
                </div>
              )}
              <div className="flex justify-between">
                <span>Shipping Charge:</span>
                <span className="font-bold">
                  {shippingCharge === 0 ? <span className="text-emerald-600">FREE</span> : `৳${shippingCharge}`}
                </span>
              </div>
              <div className="flex justify-between text-base font-black text-slate-900 dark:text-white pt-3 border-t border-slate-200 dark:border-slate-700">
                <span>Grand Total:</span>
                <span className="text-emerald-600 dark:text-emerald-400">৳{grandTotal.toLocaleString()}</span>
              </div>
            </div>

            <button
              onClick={() => navigate('/checkout')}
              className="w-full py-4 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-extrabold rounded-2xl transition-all shadow-lg shadow-emerald-600/20 flex items-center justify-center gap-2"
            >
              <span>Proceed to Checkout</span>
              <ArrowRight size={16} />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
