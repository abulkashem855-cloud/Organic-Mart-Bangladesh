import React from 'react';
import { ShieldCheck, Award, Heart, Users, Sprout, CheckCircle2 } from 'lucide-react';

export const AboutPage: React.FC = () => {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-12">
      {/* Hero Banner */}
      <div className="bg-gradient-to-r from-emerald-900 via-emerald-800 to-teal-900 rounded-3xl p-8 sm:p-12 text-white shadow-2xl space-y-4 text-center max-w-4xl mx-auto border border-emerald-700/60">
        <span className="bg-lime-400 text-slate-950 font-extrabold text-xs px-3 py-1 rounded-full uppercase">
          Empowering Organic Bangladesh
        </span>
        <h1 className="text-3xl sm:text-5xl font-black">
          Our Journey to 100% Pure, Chemical-Free Living
        </h1>
        <p className="text-xs sm:text-sm text-emerald-100 max-w-2xl mx-auto leading-relaxed">
          Founded in 2021 in Gulshan, Dhaka, Organic Mart Bangladesh was born out of a passion to eliminate artificial chemicals, formalin, and adulteration from everyday Bangladeshi dining tables.
        </p>
      </div>

      {/* Core Values */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="p-8 rounded-3xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-800 shadow-sm text-center space-y-3">
          <div className="w-14 h-14 bg-emerald-50 dark:bg-emerald-950 text-emerald-600 rounded-2xl flex items-center justify-center mx-auto">
            <Sprout size={32} />
          </div>
          <h3 className="text-base font-bold text-slate-900 dark:text-white">Direct Farm Partnering</h3>
          <p className="text-xs text-slate-500 leading-relaxed">
            We work directly with 1,200+ trained organic smallholder farmers across Rajshahi, Sherpur, Sundarbans & Sylhet without middlemen.
          </p>
        </div>

        <div className="p-8 rounded-3xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-800 shadow-sm text-center space-y-3">
          <div className="w-14 h-14 bg-emerald-50 dark:bg-emerald-950 text-emerald-600 rounded-2xl flex items-center justify-center mx-auto">
            <ShieldCheck size={32} />
          </div>
          <h3 className="text-base font-bold text-slate-900 dark:text-white">BSTI & Lab Verified</h3>
          <p className="text-xs text-slate-500 leading-relaxed">
            Every harvest batch undergoes strict chemical residue, heavy metal, and adulteration testing before bottling.
          </p>
        </div>

        <div className="p-8 rounded-3xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-800 shadow-sm text-center space-y-3">
          <div className="w-14 h-14 bg-emerald-50 dark:bg-emerald-950 text-emerald-600 rounded-2xl flex items-center justify-center mx-auto">
            <Award size={32} />
          </div>
          <h3 className="text-base font-bold text-slate-900 dark:text-white">Eco-Friendly Packaging</h3>
          <p className="text-xs text-slate-500 leading-relaxed">
            We use recyclable glass jars, unbleached jute bags, and biodegradable paper boxes to protect Bangladesh's environment.
          </p>
        </div>
      </div>

      {/* Organic Certifications */}
      <div className="p-8 bg-slate-50 dark:bg-slate-800/40 rounded-3xl border border-slate-200 dark:border-slate-800 flex flex-col md:flex-row items-center justify-between gap-6">
        <div>
          <h3 className="text-xl font-black text-slate-900 dark:text-white">Certified Organic Standards</h3>
          <p className="text-xs text-slate-500 mt-1">Compliant with BSTI, USDA Organic, and ISO 22000 Food Safety Standards.</p>
        </div>
        <div className="flex flex-wrap gap-3">
          <span className="px-4 py-2 bg-emerald-600 text-white font-bold text-xs rounded-xl flex items-center gap-1.5">
            <CheckCircle2 size={16} /> BSTI Approved
          </span>
          <span className="px-4 py-2 bg-emerald-600 text-white font-bold text-xs rounded-xl flex items-center gap-1.5">
            <CheckCircle2 size={16} /> USDA Organic
          </span>
          <span className="px-4 py-2 bg-emerald-600 text-white font-bold text-xs rounded-xl flex items-center gap-1.5">
            <CheckCircle2 size={16} /> ISO 22000
          </span>
        </div>
      </div>
    </div>
  );
};
