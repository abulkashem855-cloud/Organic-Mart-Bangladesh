import React, { useEffect, useState } from 'react';
import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import {
  User, Package, Heart, MapPin, LogOut, Truck, Clock, Shield, Lock, Check, Sparkles,
  Edit2, Save, Phone, Mail, Building2, AlertCircle, Eye, ShoppingBag, Printer
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useCart } from '../context/CartContext';
import { Order, ShippingAddress } from '../types';
import { ProductCard } from '../components/home/ProductCard';
import { A5InvoiceModal } from '../components/common/A5InvoiceModal';

export const UserAccountPage: React.FC = () => {
  const { user, token, logout, updateUser } = useAuth();
  const { wishlist } = useCart();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();

  const [activeTab, setActiveTab] = useState<'orders' | 'wishlist' | 'profile' | 'security'>('orders');
  const [orders, setOrders] = useState<Order[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [invoiceOrder, setInvoiceOrder] = useState<Order | null>(null);

  // Profile Edit State
  const [isEditingProfile, setIsEditingProfile] = useState(false);
  const [profileForm, setProfileForm] = useState({
    name: '',
    phone: '',
    email: '',
    address: '',
    district: 'Dhaka',
    thana: 'Mirpur',
    emergencyPhone: ''
  });

  // Security Form State
  const [passwordForm, setPasswordForm] = useState({
    currentPassword: '',
    newPassword: '',
    confirmPassword: ''
  });

  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3000);
  };

  useEffect(() => {
    const tabParam = searchParams.get('tab');
    if (tabParam === 'wishlist' || tabParam === 'profile' || tabParam === 'security') {
      setActiveTab(tabParam as any);
    }
  }, [searchParams]);

  useEffect(() => {
    if (!user) {
      navigate('/login');
      return;
    }

    setProfileForm({
      name: user.name || '',
      phone: user.phone || '',
      email: user.email || '',
      address: user.addresses?.[0]?.address || 'Road 12, Mirpur DOHS',
      district: user.addresses?.[0]?.district || 'Dhaka',
      thana: user.addresses?.[0]?.thana || 'Mirpur',
      emergencyPhone: user.phone || '01738019928'
    });

    fetch(`/api/orders?userId=${user.id}`)
      .then(res => res.json())
      .then(data => setOrders(Array.isArray(data) ? data : []))
      .catch(err => console.error(err))
      .finally(() => setIsLoading(false));
  }, [user, navigate]);

  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;

    const updatedAddresses: ShippingAddress[] = [
      {
        id: 'addr-1',
        fullName: profileForm.name,
        phone: profileForm.phone,
        division: 'Dhaka',
        district: profileForm.district,
        thana: profileForm.thana,
        address: profileForm.address,
        isDefault: true
      }
    ];

    updateUser({
      name: profileForm.name,
      phone: profileForm.phone,
      email: profileForm.email,
      addresses: updatedAddresses
    });

    setIsEditingProfile(false);
    showToast('আপনার প্রোফাইল তথ্য সফলভাবে আপডেট হয়েছে! (Profile updated successfully)');
  };

  const handleUpdatePassword = (e: React.FormEvent) => {
    e.preventDefault();
    if (passwordForm.newPassword !== passwordForm.confirmPassword) {
      alert('নতুন পাসওয়ার্ড মেলেনি! (New passwords do not match)');
      return;
    }
    if (passwordForm.newPassword.length < 6) {
      alert('পাসওয়ার্ড কমপক্ষে ৬ অক্ষরের হতে হবে। (Password must be at least 6 characters)');
      return;
    }

    setPasswordForm({ currentPassword: '', newPassword: '', confirmPassword: '' });
    showToast('পাসওয়ার্ড সফলভাবে পরিবর্তন করা হয়েছে! (Password updated successfully)');
  };

  if (!user) return null;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8">
      {/* Toast Alert */}
      {toastMessage && (
        <div className="fixed top-20 right-4 z-50 bg-emerald-950 text-white px-5 py-3 rounded-2xl shadow-2xl border border-emerald-500 font-bold text-xs flex items-center gap-2 animate-bounce">
          <Sparkles size={16} className="text-lime-400" />
          {toastMessage}
        </div>
      )}

      {/* Customer Header Profile Card */}
      <div className="bg-gradient-to-r from-emerald-950 via-slate-900 to-teal-950 rounded-3xl p-6 sm:p-8 text-white shadow-xl flex flex-col sm:flex-row items-center justify-between gap-6 border border-emerald-800/80">
        <div className="flex items-center gap-4">
          <div className="w-16 h-16 rounded-2xl bg-emerald-700 flex items-center justify-center text-2xl font-black text-lime-300 border-2 border-lime-400 shadow-lg">
            {user.name.charAt(0).toUpperCase()}
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-xl sm:text-2xl font-black text-white">{user.name}</h1>
              {user.role === 'admin' ? (
                <span className="px-2.5 py-0.5 bg-lime-400 text-slate-950 text-[10px] font-black rounded uppercase">
                  Admin
                </span>
              ) : (
                <span className="px-2 py-0.5 bg-emerald-800 text-emerald-200 text-[10px] font-bold rounded uppercase">
                  Verified Customer
                </span>
              )}
            </div>
            <p className="text-xs text-emerald-200 mt-1 flex items-center gap-3">
              <span>📞 {user.phone || '01738019928'}</span>
              <span>•</span>
              <span>✉️ {user.email}</span>
            </p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={() => {
              setActiveTab('profile');
              setIsEditingProfile(true);
            }}
            className="px-4 py-2 bg-emerald-800 hover:bg-emerald-700 text-emerald-100 font-bold text-xs rounded-xl flex items-center gap-1.5 border border-emerald-600 transition-colors"
          >
            <Edit2 size={14} /> প্রোফাইল এডিট (Edit Profile)
          </button>
          <button
            onClick={logout}
            className="px-4 py-2 bg-red-600/80 hover:bg-red-600 text-white font-bold text-xs rounded-xl flex items-center gap-1.5 transition-colors"
          >
            <LogOut size={14} /> লগআউট (Log Out)
          </button>
        </div>
      </div>

      {/* Tabs Navigation Toolbar */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2 border-b border-slate-200 dark:border-slate-800 text-xs font-bold scrollbar-none">
        <button
          onClick={() => setActiveTab('orders')}
          className={`px-4 py-2.5 rounded-2xl flex items-center gap-2 shrink-0 transition-all ${
            activeTab === 'orders'
              ? 'bg-emerald-600 text-white shadow-md font-extrabold'
              : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-700'
          }`}
        >
          <Package size={16} /> আমার অর্ডারসমূহ (My Orders - {orders.length})
        </button>

        <button
          onClick={() => setActiveTab('wishlist')}
          className={`px-4 py-2.5 rounded-2xl flex items-center gap-2 shrink-0 transition-all ${
            activeTab === 'wishlist'
              ? 'bg-emerald-600 text-white shadow-md font-extrabold'
              : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-700'
          }`}
        >
          <Heart size={16} /> পছন্দের তালিকা (Wishlist - {wishlist.length})
        </button>

        <button
          onClick={() => setActiveTab('profile')}
          className={`px-4 py-2.5 rounded-2xl flex items-center gap-2 shrink-0 transition-all ${
            activeTab === 'profile'
              ? 'bg-emerald-600 text-white shadow-md font-extrabold'
              : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-700'
          }`}
        >
          <User size={16} /> প্রোফাইল ও ডেলিভারি ঠিকানা (Profile & Address)
        </button>

        <button
          onClick={() => setActiveTab('security')}
          className={`px-4 py-2.5 rounded-2xl flex items-center gap-2 shrink-0 transition-all ${
            activeTab === 'security'
              ? 'bg-emerald-600 text-white shadow-md font-extrabold'
              : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-700'
          }`}
        >
          <Shield size={16} /> অ্যাকাউন্ট সিকিউরিটি (Security & Password)
        </button>
      </div>

      {/* TAB 1: ORDERS */}
      {activeTab === 'orders' && (
        <div className="space-y-4">
          {isLoading ? (
            <p className="text-xs text-slate-500 font-bold">আপনার পূর্বের অর্ডার বিবরণী লোড হচ্ছে...</p>
          ) : orders.length === 0 ? (
            <div className="text-center py-16 bg-white dark:bg-slate-800 rounded-3xl border border-slate-200 dark:border-slate-800 space-y-3">
              <ShoppingBag size={48} className="text-slate-400 mx-auto" />
              <p className="text-base font-extrabold text-slate-900 dark:text-white">এখনো কোনো অর্ডার করা হয়নি</p>
              <p className="text-xs text-slate-500 max-w-sm mx-auto">
                আমাদের শপ থেকে খাঁটি সুন্দরবনের মধু, ঘি ও কেমিক্যালমুক্ত চাল অর্ডার করুন।
              </p>
              <Link to="/shop" className="inline-block px-6 py-2.5 bg-emerald-600 text-white font-bold rounded-xl text-xs shadow-lg shadow-emerald-600/20">
                শপ ব্রাউজ করুন (Browse Shop)
              </Link>
            </div>
          ) : (
            orders.map(order => (
              <div
                key={order.id}
                className="p-6 rounded-3xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4"
              >
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-4 border-b border-slate-100 dark:border-slate-700/60">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-mono font-black text-emerald-600 dark:text-emerald-400">{order.id}</span>
                      <span className="text-[10px] bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300 px-2 py-0.5 rounded font-bold">
                        {order.items.length} Items
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-400 mt-0.5">অর্ডারের তারিখ: {new Date(order.createdAt).toLocaleDateString()}</p>
                  </div>

                  <div className="flex flex-wrap items-center gap-2">
                    <span className="px-3 py-1 bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300 font-extrabold text-[10px] rounded-full uppercase">
                      {order.status}
                    </span>
                    <button
                      onClick={() => setInvoiceOrder(order)}
                      className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 dark:bg-slate-700 dark:hover:bg-slate-600 text-slate-800 dark:text-white text-xs font-bold rounded-xl flex items-center gap-1 shadow-sm transition-colors"
                    >
                      <Printer size={12} /> ইনভয়েস (A5 Print)
                    </button>
                    <Link
                      to={`/track?query=${order.id}`}
                      className="px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl flex items-center gap-1 shadow"
                    >
                      <Truck size={12} /> ট্র্যাকিং (Track)
                    </Link>
                  </div>
                </div>

                <div className="space-y-2">
                  {order.items.map((item, idx) => (
                    <div key={idx} className="flex items-center gap-3 text-xs p-2 rounded-xl bg-slate-50 dark:bg-slate-900/50">
                      <img src={item.image} alt="" className="w-12 h-12 rounded-xl object-cover" />
                      <div className="flex-1 min-w-0">
                        <p className="font-bold text-slate-900 dark:text-white truncate">{item.name}</p>
                        <p className="text-[10px] text-slate-400">পরিমাণ: {item.quantity} x ৳{item.price}</p>
                      </div>
                      <span className="font-extrabold text-slate-900 dark:text-white">৳{item.price * item.quantity}</span>
                    </div>
                  ))}
                </div>

                <div className="pt-3 border-t border-slate-100 dark:border-slate-700/60 text-xs space-y-1">
                  <div className="flex justify-between text-slate-500">
                    <span>পণ্য মোট মূল্য (Products Subtotal):</span>
                    <span className="font-mono font-bold">৳{order.subtotal || order.items.reduce((sum, item) => sum + (item.price * item.quantity), 0)}</span>
                  </div>
                  <div className="flex justify-between text-slate-500">
                    <span>ডেলিভারি চার্জ (Delivery Charge):</span>
                    <span className="font-mono font-bold text-emerald-600">+ ৳{order.shippingCharge ?? 70}</span>
                  </div>
                  {order.discount > 0 && (
                    <div className="flex justify-between text-emerald-600">
                      <span>ডিসকাউন্ট (Discount):</span>
                      <span className="font-mono font-bold">- ৳{order.discount}</span>
                    </div>
                  )}
                  <div className="flex justify-between items-center pt-2 border-t border-slate-200 dark:border-slate-700">
                    <span className="text-slate-600 dark:text-slate-400 font-medium">পেমেন্ট মেথড: <strong className="uppercase text-slate-800 dark:text-slate-200">{order.paymentMethod}</strong></span>
                    <span className="font-black text-slate-900 dark:text-white text-sm">
                      সর্বমোট প্রদেয়: <strong className="text-emerald-600 dark:text-emerald-400 font-mono text-base">৳{order.grandTotal}</strong>
                    </span>
                  </div>
                </div>
              </div>
            ))
          )}

          {/* A5 INVOICE PRINT MODAL */}
          {invoiceOrder && (
            <A5InvoiceModal order={invoiceOrder} onClose={() => setInvoiceOrder(null)} />
          )}
        </div>
      )}

      {/* TAB 2: WISHLIST */}
      {activeTab === 'wishlist' && (
        <div>
          {wishlist.length === 0 ? (
            <div className="text-center py-16 bg-white dark:bg-slate-800 rounded-3xl border border-slate-200 dark:border-slate-800 space-y-3">
              <Heart size={48} className="text-slate-400 mx-auto" />
              <p className="text-base font-extrabold text-slate-900 dark:text-white">উইশলিস্ট এখনো খালি</p>
              <p className="text-xs text-slate-500">পছন্দের অর্গানিক পণ্যের পাশের লাভ আইকনে ক্লিক করে সংরক্ষণ করুন।</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {wishlist.map(p => (
                <ProductCard key={p.id} product={p} />
              ))}
            </div>
          )}
        </div>
      )}

      {/* TAB 3: PROFILE & ADDRESS */}
      {activeTab === 'profile' && (
        <div className="bg-white dark:bg-slate-800 rounded-3xl border border-slate-200 dark:border-slate-800 p-6 sm:p-8 space-y-6 shadow-sm">
          <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-700 pb-4">
            <div>
              <h3 className="text-lg font-black text-slate-900 dark:text-white">গ্রাহক প্রোফাইল ও ডেলিভারি তথ্য</h3>
              <p className="text-xs text-slate-500">ঢাকা ও দেশের যেকোনো জেলায় পণ্য প্রেরণের জন্য সঠিক ঠিকানা সংরক্ষণ করুন।</p>
            </div>
            {!isEditingProfile && (
              <button
                onClick={() => setIsEditingProfile(true)}
                className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl flex items-center gap-1.5 shadow"
              >
                <Edit2 size={14} /> পরিবর্তন করুন (Edit)
              </button>
            )}
          </div>

          <form onSubmit={handleSaveProfile} className="space-y-4 text-xs font-semibold">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-slate-700 dark:text-slate-300 font-bold mb-1">
                  পূর্ণ নাম (Full Name) *
                </label>
                <input
                  type="text"
                  required
                  disabled={!isEditingProfile}
                  value={profileForm.name}
                  onChange={e => setProfileForm({ ...profileForm, name: e.target.value })}
                  className="w-full px-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-slate-900 dark:text-white outline-none disabled:opacity-75 font-bold"
                />
              </div>

              <div>
                <label className="block text-slate-700 dark:text-slate-300 font-bold mb-1">
                  মোবাইল নম্বর (Phone Number) *
                </label>
                <input
                  type="text"
                  required
                  disabled={!isEditingProfile}
                  value={profileForm.phone}
                  onChange={e => setProfileForm({ ...profileForm, phone: e.target.value })}
                  className="w-full px-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-slate-900 dark:text-white outline-none disabled:opacity-75 font-bold"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-slate-700 dark:text-slate-300 font-bold mb-1">
                  ইমেইল এড্রেস (Email Address)
                </label>
                <input
                  type="email"
                  disabled={!isEditingProfile}
                  value={profileForm.email}
                  onChange={e => setProfileForm({ ...profileForm, email: e.target.value })}
                  className="w-full px-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-slate-900 dark:text-white outline-none disabled:opacity-75"
                />
              </div>

              <div>
                <label className="block text-slate-700 dark:text-slate-300 font-bold mb-1">
                  জেলা (District) *
                </label>
                <input
                  type="text"
                  required
                  disabled={!isEditingProfile}
                  value={profileForm.district}
                  onChange={e => setProfileForm({ ...profileForm, district: e.target.value })}
                  className="w-full px-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-slate-900 dark:text-white outline-none disabled:opacity-75 font-bold"
                />
              </div>
            </div>

            <div>
              <label className="block text-slate-700 dark:text-slate-300 font-bold mb-1">
                সম্পূর্ণ হোম ডেলিভারি ঠিকানা (Detailed Delivery Address) *
              </label>
              <textarea
                rows={3}
                required
                disabled={!isEditingProfile}
                value={profileForm.address}
                onChange={e => setProfileForm({ ...profileForm, address: e.target.value })}
                placeholder="বাসা নম্বর, রোড নম্বর, এলাকা, ল্যান্ডমার্ক..."
                className="w-full px-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-slate-900 dark:text-white outline-none disabled:opacity-75"
              />
            </div>

            {isEditingProfile && (
              <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-200 dark:border-slate-700">
                <button
                  type="button"
                  onClick={() => setIsEditingProfile(false)}
                  className="px-5 py-2.5 bg-slate-100 dark:bg-slate-700 text-slate-700 dark:text-slate-300 font-bold rounded-xl"
                >
                  বাতিল (Cancel)
                </button>
                <button
                  type="submit"
                  className="px-6 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold rounded-xl shadow-lg shadow-emerald-600/20 flex items-center gap-2"
                >
                  <Save size={16} /> সেভ করুন (Save Address)
                </button>
              </div>
            )}
          </form>
        </div>
      )}

      {/* TAB 4: SECURITY & PASSWORD */}
      {activeTab === 'security' && (
        <div className="bg-white dark:bg-slate-800 rounded-3xl border border-slate-200 dark:border-slate-800 p-6 sm:p-8 space-y-6 shadow-sm max-w-xl">
          <div className="border-b border-slate-200 dark:border-slate-700 pb-4">
            <h3 className="text-lg font-black text-slate-900 dark:text-white flex items-center gap-2">
              <Lock className="text-emerald-600" size={20} />
              পাসওয়ার্ড পরিবর্তন করুন (Update Password)
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">আপনার অ্যাকাউন্টের সুরক্ষায় শক্তিশালী পাসওয়ার্ড ব্যবহার করুন।</p>
          </div>

          <form onSubmit={handleUpdatePassword} className="space-y-4 text-xs font-semibold">
            <div>
              <label className="block text-slate-700 dark:text-slate-300 font-bold mb-1">
                বর্তমান পাসওয়ার্ড (Current Password) *
              </label>
              <input
                type="password"
                required
                value={passwordForm.currentPassword}
                onChange={e => setPasswordForm({ ...passwordForm, currentPassword: e.target.value })}
                className="w-full px-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-slate-900 dark:text-white outline-none focus:border-emerald-500"
              />
            </div>

            <div>
              <label className="block text-slate-700 dark:text-slate-300 font-bold mb-1">
                নতুন পাসওয়ার্ড (New Password) *
              </label>
              <input
                type="password"
                required
                value={passwordForm.newPassword}
                onChange={e => setPasswordForm({ ...passwordForm, newPassword: e.target.value })}
                className="w-full px-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-slate-900 dark:text-white outline-none focus:border-emerald-500"
              />
            </div>

            <div>
              <label className="block text-slate-700 dark:text-slate-300 font-bold mb-1">
                নতুন পাসওয়ার্ড নিশ্চিত করুন (Confirm New Password) *
              </label>
              <input
                type="password"
                required
                value={passwordForm.confirmPassword}
                onChange={e => setPasswordForm({ ...passwordForm, confirmPassword: e.target.value })}
                className="w-full px-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-slate-900 dark:text-white outline-none focus:border-emerald-500"
              />
            </div>

            <button
              type="submit"
              className="w-full py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold rounded-xl shadow-lg shadow-emerald-600/20"
            >
              পাসওয়ার্ড আপডেট করুন (Update Password)
            </button>
          </form>
        </div>
      )}
    </div>
  );
};
