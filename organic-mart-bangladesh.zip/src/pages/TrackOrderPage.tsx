import React, { useState } from 'react';
import { Search, Truck, CheckCircle2, Clock, Package, MapPin, Phone, ShieldCheck, Printer } from 'lucide-react';
import { Order, OrderStatus } from '../types';
import { A5InvoiceModal } from '../components/common/A5InvoiceModal';

export const TrackOrderPage: React.FC = () => {
  const [query, setQuery] = useState('');
  const [order, setOrder] = useState<Order | null>(null);
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [showInvoiceModal, setShowInvoiceModal] = useState(false);

  const handleTrack = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!query.trim()) return;

    setIsLoading(true);
    setError('');
    setOrder(null);

    try {
      const res = await fetch(`/api/orders/track/${encodeURIComponent(query.trim())}`);
      const data = await res.json();
      if (res.ok) {
        setOrder(data);
      } else {
        setError(data.error || 'No order found with this tracking ID or Phone Number.');
      }
    } catch (err) {
      setError('Failed to connect to order tracking server.');
    } finally {
      setIsLoading(false);
    }
  };

  const steps: OrderStatus[] = ['Pending', 'Confirmed', 'Packed', 'Shipped', 'Delivered'];

  const getStepIndex = (status: OrderStatus) => {
    const idx = steps.indexOf(status);
    return idx === -1 ? 0 : idx;
  };

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-8">
      {/* Header */}
      <div className="text-center max-w-xl mx-auto">
        <span className="text-xs font-bold text-emerald-600 dark:text-emerald-400 uppercase tracking-wider flex items-center justify-center gap-1">
          <Truck size={16} /> Live Delivery Tracking
        </span>
        <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white mt-1">
          Track Your Organic Order
        </h1>
        <p className="text-xs text-slate-500 dark:text-slate-400 mt-2">
          Enter your Order ID (e.g. OMB-2026-8941) or phone number to see real-time delivery status.
        </p>
      </div>

      {/* Search Form */}
      <div className="bg-white dark:bg-slate-800 p-6 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-md">
        <form onSubmit={handleTrack} className="flex flex-col sm:flex-row gap-3">
          <div className="relative flex-1">
            <input
              type="text"
              placeholder="e.g. OMB-2026-8941 or 01712345678"
              value={query}
              onChange={e => setQuery(e.target.value)}
              required
              className="w-full pl-10 pr-4 py-3 rounded-2xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-slate-900 dark:text-white font-mono text-sm outline-none focus:border-emerald-500"
            />
            <Search size={18} className="absolute left-3.5 top-3.5 text-slate-400" />
          </div>

          <button
            type="submit"
            disabled={isLoading}
            className="px-8 py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-xs rounded-2xl transition-colors shadow-md shadow-emerald-600/20 flex items-center justify-center gap-2"
          >
            {isLoading ? 'Searching...' : 'Track Order Progress'}
          </button>
        </form>

        {error && (
          <p className="mt-4 text-xs font-bold text-red-500 bg-red-50 dark:bg-red-950/50 p-3 rounded-xl text-center">
            {error}
          </p>
        )}
      </div>

      {/* Track Result Card */}
      {order && (
        <div className="bg-white dark:bg-slate-800 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-xl overflow-hidden divide-y divide-slate-100 dark:divide-slate-800">
          {/* Order Header Summary */}
          <div className="p-6 bg-emerald-950 text-white flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
            <div>
              <span className="text-[10px] text-lime-300 font-bold uppercase tracking-wider">
                Order Reference Number
              </span>
              <h2 className="text-xl font-black font-mono tracking-wider text-white">
                {order.id}
              </h2>
              <p className="text-xs text-emerald-200 mt-0.5">
                Placed on {new Date(order.createdAt).toLocaleString()}
              </p>
            </div>

            <div className="flex items-center gap-3">
              <span className="px-3 py-1 bg-lime-400 text-slate-950 font-extrabold text-xs rounded-full uppercase">
                {order.status}
              </span>
              <span className="px-3 py-1 bg-emerald-800 text-emerald-200 font-semibold text-xs rounded-full uppercase">
                Payment: {order.paymentStatus} ({order.paymentMethod.toUpperCase()})
              </span>
            </div>
          </div>

          {/* Stepper Status Timeline */}
          <div className="p-6">
            <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-6">
              Delivery Progress
            </h3>

            <div className="relative flex justify-between items-center max-w-2xl mx-auto">
              <div className="absolute top-1/2 left-0 right-0 h-1 bg-slate-200 dark:bg-slate-700 -translate-y-1/2 z-0" />
              <div
                className="absolute top-1/2 left-0 h-1 bg-emerald-500 -translate-y-1/2 z-0 transition-all duration-500"
                style={{
                  width: `${(getStepIndex(order.status) / (steps.length - 1)) * 100}%`
                }}
              />

              {steps.map((step, idx) => {
                const isCompleted = idx <= getStepIndex(order.status);
                const isCurrent = idx === getStepIndex(order.status);

                return (
                  <div key={step} className="relative z-10 flex flex-col items-center">
                    <div
                      className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-xs transition-all ${
                        isCompleted
                          ? 'bg-emerald-600 text-white shadow-md shadow-emerald-600/30 ring-4 ring-emerald-100 dark:ring-emerald-950'
                          : 'bg-slate-200 dark:bg-slate-700 text-slate-500'
                      }`}
                    >
                      {isCompleted ? <CheckCircle2 size={16} /> : idx + 1}
                    </div>
                    <span
                      className={`text-[11px] font-bold mt-2 whitespace-nowrap ${
                        isCurrent
                          ? 'text-emerald-600 dark:text-emerald-400'
                          : isCompleted
                          ? 'text-slate-800 dark:text-slate-200'
                          : 'text-slate-400'
                      }`}
                    >
                      {step}
                    </span>
                  </div>
                );
              })}
            </div>

            {/* Courier Tracking Note */}
            {order.deliveryCourier && (
              <div className="mt-8 p-4 bg-emerald-50 dark:bg-slate-900 rounded-2xl border border-emerald-200 dark:border-slate-700 flex items-center justify-between text-xs">
                <div className="flex items-center gap-2">
                  <Truck className="text-emerald-600" size={18} />
                  <span>Courier Partner: <strong className="text-slate-900 dark:text-white">{order.deliveryCourier}</strong></span>
                </div>
                {order.trackingNumber && (
                  <span className="font-mono font-bold text-emerald-700 dark:text-emerald-400">
                    Waybill #: {order.trackingNumber}
                  </span>
                )}
              </div>
            )}
          </div>

          {/* Customer & Address Info */}
          <div className="p-6 grid grid-cols-1 md:grid-cols-2 gap-6 text-xs">
            <div>
              <h4 className="font-bold text-slate-900 dark:text-white mb-2 flex items-center gap-1.5">
                <MapPin size={16} className="text-emerald-600" /> Shipping Destination
              </h4>
              <p className="font-bold text-slate-800 dark:text-slate-200">{order.customerName}</p>
              <p className="text-slate-500">{order.shippingAddress.address}</p>
              <p className="text-slate-500">{order.shippingAddress.thana}, {order.shippingAddress.district}, {order.shippingAddress.division}</p>
              <p className="text-slate-500 mt-1 flex items-center gap-1"><Phone size={12} /> {order.customerPhone}</p>
            </div>

            <div>
              <div className="flex items-center justify-between mb-2">
                <h4 className="font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
                  <Package size={16} className="text-emerald-600" /> Order Breakdown
                </h4>
                <button
                  onClick={() => setShowInvoiceModal(true)}
                  className="px-3 py-1 bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-[11px] rounded-lg flex items-center gap-1 shadow"
                >
                  <Printer size={12} /> A5 Invoice Print
                </button>
              </div>
              <div className="space-y-1 text-slate-600 dark:text-slate-300">
                <div className="flex justify-between"><span>Products Subtotal:</span><span className="font-mono font-bold">৳{order.subtotal}</span></div>
                <div className="flex justify-between"><span>Delivery Charge:</span><span className="font-mono font-bold text-emerald-600">+ ৳{order.shippingCharge}</span></div>
                {order.discount > 0 && <div className="flex justify-between text-emerald-600"><span>Discount:</span><span className="font-mono font-bold">- ৳{order.discount}</span></div>}
                <div className="flex justify-between font-extrabold text-slate-900 dark:text-white pt-1 border-t border-slate-200 dark:border-slate-700">
                  <span>Grand Total:</span><span className="text-emerald-600 font-mono text-sm">৳{order.grandTotal}</span>
                </div>
              </div>
            </div>
          </div>

          {/* Items Table */}
          <div className="p-6 bg-slate-50 dark:bg-slate-900/50">
            <h4 className="font-bold text-xs uppercase text-slate-400 mb-3">Order Items ({order.items.length})</h4>
            <div className="space-y-3">
              {order.items.map((item, idx) => (
                <div key={idx} className="flex items-center gap-3 bg-white dark:bg-slate-800 p-3 rounded-2xl border border-slate-200 dark:border-slate-700">
                  <img src={item.image} alt="" className="w-12 h-12 rounded-xl object-cover" />
                  <div className="flex-1 min-w-0">
                    <p className="text-xs font-bold text-slate-900 dark:text-white truncate">{item.name}</p>
                    <p className="text-[11px] text-slate-400">{item.unit} • Quantity: {item.quantity}</p>
                  </div>
                  <span className="text-xs font-bold text-emerald-600 font-mono">৳{item.price * item.quantity}</span>
                </div>
              ))}
            </div>
          </div>

          {showInvoiceModal && (
            <A5InvoiceModal order={order} onClose={() => setShowInvoiceModal(false)} />
          )}
        </div>
      )}
    </div>
  );
};
