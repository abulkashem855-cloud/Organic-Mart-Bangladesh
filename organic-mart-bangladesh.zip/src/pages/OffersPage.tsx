import React, { useEffect, useState } from 'react';
import { Tag, Sparkles, Copy, Check, Flame } from 'lucide-react';
import { ProductCard } from '../components/home/ProductCard';
import { Product, Coupon } from '../types';

export const OffersPage: React.FC = () => {
  const [coupons, setCoupons] = useState<Coupon[]>([]);
  const [deals, setDeals] = useState<Product[]>([]);
  const [copiedCode, setCopiedCode] = useState<string | null>(null);

  useEffect(() => {
    fetch('/api/coupons')
      .then(res => res.json())
      .then(data => setCoupons(data || []))
      .catch(err => console.error(err));

    fetch('/api/products?todayDeal=true')
      .then(res => res.json())
      .then(data => setDeals(data.products || []))
      .catch(err => console.error(err));
  }, []);

  const copyCoupon = (code: string) => {
    navigator.clipboard.writeText(code);
    setCopiedCode(code);
    setTimeout(() => setCopiedCode(null), 2000);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-10">
      {/* Page Header */}
      <div className="bg-gradient-to-r from-amber-600 via-orange-600 to-red-600 rounded-3xl p-8 text-white shadow-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <span className="inline-flex items-center gap-1.5 bg-amber-400 text-slate-950 text-xs font-black px-3 py-1 rounded-full uppercase mb-2">
            <Sparkles size={14} /> Today's Savings
          </span>
          <h1 className="text-2xl sm:text-4xl font-extrabold">
            Exclusive Organic Coupon Codes & Deals
          </h1>
          <p className="text-xs text-amber-100 mt-1">
            Apply coupons at checkout for discounts on pure honey, Ghani oil, Kalijira rice & organic tea.
          </p>
        </div>
      </div>

      {/* Coupons Grid */}
      <section className="space-y-4">
        <h2 className="text-xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
          <Tag className="text-amber-500" size={20} /> Active Promo Coupons
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {coupons.map((c, i) => (
            <div
              key={i}
              className="p-6 rounded-3xl bg-white dark:bg-slate-800 border-2 border-dashed border-amber-400 dark:border-amber-600/60 shadow-md relative overflow-hidden flex flex-col justify-between"
            >
              <div className="absolute -right-8 -top-8 w-20 h-20 bg-amber-400/20 rounded-full" />

              <div>
                <span className="text-[10px] uppercase font-bold text-amber-600 dark:text-amber-400 tracking-wider">
                  {c.discountType === 'percent' ? `${c.discountValue}% Discount` : `৳${c.discountValue} OFF`}
                </span>
                <h3 className="text-2xl font-black text-slate-900 dark:text-white mt-1 uppercase tracking-wider font-mono">
                  {c.code}
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-2">
                  Minimum spend of ৳{c.minSpend}. Valid till {new Date(c.expiryDate).toLocaleDateString()}
                </p>
              </div>

              <div className="mt-6 pt-4 border-t border-slate-100 dark:border-slate-700/60 flex items-center justify-between">
                <span className="text-[11px] font-semibold text-emerald-600">Active</span>
                <button
                  onClick={() => copyCoupon(c.code)}
                  className="px-4 py-2 bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold text-xs rounded-xl flex items-center gap-1.5 transition-colors shadow-sm"
                >
                  {copiedCode === c.code ? (
                    <>
                      <Check size={14} /> Copied!
                    </>
                  ) : (
                    <>
                      <Copy size={14} /> Copy Code
                    </>
                  )}
                </button>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Today's Flash Sale Items */}
      <section className="space-y-6 pt-6">
        <h2 className="text-xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
          <Flame className="text-red-500" size={20} /> Today's Discounted Organic Deals
        </h2>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {deals.map(p => (
            <ProductCard key={p.id} product={p} />
          ))}
        </div>
      </section>
    </div>
  );
};
