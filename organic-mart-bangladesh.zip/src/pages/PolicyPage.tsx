import React, { useState, useEffect } from 'react';
import { useLocation, Link } from 'react-router-dom';
import {
  ShieldCheck, FileText, RefreshCw, Truck, HelpCircle, ChevronDown, ChevronUp,
  Lock, CheckCircle2, Phone, Mail, MessageCircle, Search, Sparkles, MapPin, AlertCircle
} from 'lucide-react';

interface PolicyPageProps {
  defaultTab?: 'privacy' | 'terms' | 'refund' | 'shipping' | 'faq';
}

export const PolicyPage: React.FC<PolicyPageProps> = ({ defaultTab }) => {
  const location = useLocation();
  const [activeTab, setActiveTab] = useState<'privacy' | 'terms' | 'refund' | 'shipping' | 'faq'>('privacy');
  const [faqSearch, setFaqSearch] = useState('');
  const [openFaqIndex, setOpenFaqIndex] = useState<number | null>(0);

  useEffect(() => {
    if (defaultTab) {
      setActiveTab(defaultTab);
    } else if (location.pathname.includes('privacy')) {
      setActiveTab('privacy');
    } else if (location.pathname.includes('terms')) {
      setActiveTab('terms');
    } else if (location.pathname.includes('refund')) {
      setActiveTab('refund');
    } else if (location.pathname.includes('shipping')) {
      setActiveTab('shipping');
    } else if (location.pathname.includes('faq')) {
      setActiveTab('faq');
    }
  }, [defaultTab, location.pathname]);

  const faqItems = [
    {
      q: 'সুন্দরবনের মধু শতভাগ খাঁটি কীভাবে নিশ্চিত হব? (How do I verify pure Sundarban Honey?)',
      a: 'আমাদের সুন্দরবনের কাঁচা মধু সরাসরি মৌয়ালদের থেকে সংগৃহীত এবং কোনো প্রকার কেমিক্যাল বা উচ্চ তাপে প্রসেস করা হয় না। প্রতিটি ব্যাচ বিএসটিআই (BSTI) ও স্বীকৃত ল্যাব টেস্টে উত্তীর্ণ। জমাট না বাঁধা এবং প্রাকৃতিক সুবাস খাঁটিত্বের অন্যতম প্রমাণ।'
    },
    {
      q: 'ঢাকার ভেতরে এবং বাইরে ডেলিভারি চার্জ কত? (What are the shipping charges?)',
      a: 'ঢাকার ভেতরে এক্সপ্রেস ২-৪ ঘণ্টায় হোম ডেলিভারি চার্জ ৳৭০। ৳১৫০০ টাকার বেশি অর্ডারে ঢাকার ভেতরে ডেলিভারি একদম ফ্রী! ঢাকার বাইরে সমগ্র বাংলাদেশে সুন্দরবন, পাঠান বা রেডএক্স কুরিয়ারের মাধ্যমে ১-২ দিনে ডেলিভারি চার্জ ৳১২০।'
    },
    {
      q: 'ক্যাশ অন ডেলিভারিতে (COD) পণ্য দেখে টাকা দেওয়া যাবে কি? (Can I inspect COD orders?)',
      a: 'হ্যাঁ, অবশ্যই! ডেলিভারি ম্যানের সামনে প্যাকেট খুলে অর্ডারের পণ্য ঠিক আছে কিনা দেখে মূল্য পরিশোধ করতে পারবেন। কোনো অসঙ্গতি থাকলে সাথে সাথে ডেলিভারি পারসনকে ফেরত দিতে পারবেন।'
    },
    {
      q: 'পরিবহনকালে কাঁচের জার বা তরল জাতীয় পণ্য ভেঙে গেলে করণীয় কী? (What if glass bottles break during shipping?)',
      a: 'আমরা শক-প্রুফ বাবল র‍্যাপ এবং শক্ত কার্টনে কাঁচের বয়াম প্যাক করি। এরপরও কুরিয়ারে ক্ষয়ক্ষতি হলে আমরা সম্পূর্ণ বিনামূল্যে তাৎক্ষণিক রিপ্লেসমেন্ট প্রদান করি। কোনো অতিরিক্ত খরচ দিতে হবে না।'
    },
    {
      q: 'অর্ডার ট্র্যাকিং করব কীভাবে? (How do I track my order status?)',
      a: 'অর্ডার সম্পন্ন হলে আপনার মোবাইলে এসএমএস বা ইমেইলে একটি ইউনিক ট্র্যাকিং কোড (যেমন: OMB-2026-9821) চলে যাবে। আমাদের ওয়েবসাইটের "Track Order" পাতায় মোবাইল নম্বর বা অর্ডার আইডি দিয়ে সরাসরি লাইভ স্ট্যাটাস দেখতে পারবেন।'
    },
    {
      q: 'পণ্য পছন্দ না হলে ফেরত দেওয়ার সময়সীমা কত দিন? (What is the return period?)',
      a: 'পণ্য পাওয়ার ৭ দিনের মধ্যে যেকোনো মানগত সমস্যা, ভুল পণ্য বা কুরিয়ার ড্যামেজের ক্ষেত্রে ১০০% মানিব্যাক রিফান্ড অথবা ফ্রী পণ্য পরিবর্তন সুবিধা পাবেন।'
    },
    {
      q: 'কোন কোন পেমেন্ট মেথড গ্রহণ করা হয়? (Which payment methods are accepted?)',
      a: 'আমরা বিকাশ (bKash), নগদ (Nagad), রকেট (Rocket), কার্ড (Visa/Mastercard) এবং ক্যাশ অন ডেলিভারি (Cash on Delivery) পেমেন্ট গ্রহণ করে থাকি।'
    }
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-10">
      {/* Top Banner Header */}
      <div className="bg-gradient-to-r from-emerald-950 via-slate-900 to-teal-950 rounded-3xl p-8 sm:p-12 text-white border border-emerald-800/60 shadow-2xl space-y-4 text-center md:text-left relative overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />
        
        <div className="relative z-10 space-y-3 max-w-3xl">
          <span className="inline-flex items-center gap-2 px-3 py-1 bg-emerald-900/80 border border-emerald-600 text-lime-300 font-extrabold text-[11px] rounded-full uppercase tracking-wider">
            <ShieldCheck size={14} /> Official Customer Center
          </span>
          <h1 className="text-3xl sm:text-5xl font-black text-white tracking-tight leading-tight">
            Policies, Terms & FAQ Guidance
          </h1>
          <p className="text-xs sm:text-sm text-emerald-200 leading-relaxed">
            Everything you need to know about 100% organic product guarantees, bKash/Nagad security, express Dhaka delivery, 7-day refund policy, and customer account protection.
          </p>
        </div>
      </div>

      {/* Navigation Tabs Header */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2 border-b border-slate-200 dark:border-slate-800 text-xs font-bold scrollbar-none">
        {[
          { id: 'privacy', label: 'প্রাইভেসি পলিসি (Privacy Policy)', icon: Lock },
          { id: 'terms', label: 'শর্তাবলী (Terms & Conditions)', icon: FileText },
          { id: 'refund', label: 'রিফান্ড ও রিটার্ন (Refund Policy)', icon: RefreshCw },
          { id: 'shipping', label: 'শিপিং ও ডেলিভারি (Shipping Info)', icon: Truck },
          { id: 'faq', label: 'সচরাচর জিজ্ঞাসা (FAQ)', icon: HelpCircle }
        ].map(tab => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`px-4 py-3 rounded-2xl flex items-center gap-2 shrink-0 transition-all ${
                isActive
                  ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-600/30 font-extrabold'
                  : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-700/60 hover:bg-slate-100'
              }`}
            >
              <Icon size={16} />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* TAB CONTENT SECTIONS */}
      <div className="bg-white dark:bg-slate-800 rounded-3xl border border-slate-200 dark:border-slate-800 p-6 sm:p-10 shadow-sm leading-relaxed text-slate-700 dark:text-slate-300 text-xs sm:text-sm space-y-8">
        
        {/* 1. PRIVACY POLICY TAB */}
        {activeTab === 'privacy' && (
          <div className="space-y-6">
            <div className="border-b border-slate-200 dark:border-slate-700 pb-4">
              <h2 className="text-xl font-extrabold text-slate-900 dark:text-white flex items-center gap-2">
                <Lock className="text-emerald-600" size={22} />
                প্রাইভেসি পলিসি (Privacy Policy)
              </h2>
              <p className="text-xs text-slate-400 mt-1">সর্বশেষ আপডেট: জুলাই ২০২৬ • অর্গানিক মার্ট বাংলাদেশ</p>
            </div>

            <div className="space-y-4">
              <div className="p-4 rounded-2xl bg-emerald-50 dark:bg-slate-900/60 border-l-4 border-emerald-500 font-medium">
                অর্গানিক মার্ট বাংলাদেশ (Organic Mart Bangladesh) গ্রাহকের ব্যক্তিগত তথ্যের সর্বোচ্চ নিরাপত্তা প্রদানে অঙ্গীকারবদ্ধ। আপনার মোবাইল নম্বর, নাম, ঠিকানা এবং পেমেন্ট সংক্রান্ত তথ্য সম্পূর্ণরূপে এনক্রিপ্টেড এবং নিরাপদ রাখা হয়।
              </div>

              <div className="space-y-3">
                <h3 className="font-bold text-slate-900 dark:text-white text-base">১. আমরা কী কী তথ্য সংগ্রহ করি (Information We Collect):</h3>
                <ul className="list-disc pl-5 space-y-1 text-slate-600 dark:text-slate-300">
                  <li><strong>গ্রাহকের পরিচয়:</strong> নাম, মোবাইল নম্বর, ইমেইল এড্রেস এবং অ্যাকাউন্ট পাসওয়ার্ড।</li>
                  <li><strong>ডেলিভারি ঠিকানা:</strong> জেলা, থানা, বাড়ি/রোড নম্বর এবং ডেলিভারির জন্য জরুরি মোবাইল নম্বর।</li>
                  <li><strong>অর্ডার বিবরণী:</strong> আপনার ক্রয়কৃত পণ্য তালিকা, ট্রানজেকশন আইডি (bKash/Nagad/SSLCommerz)।</li>
                </ul>
              </div>

              <div className="space-y-3">
                <h3 className="font-bold text-slate-900 dark:text-white text-base">২. তথ্যের নিরাপত্তা ও ব্যবহার (Data Protection & Usage):</h3>
                <p>
                  আপনার তথ্য শুধুমাত্র গ্রোসারী অর্ডারের প্রসেসিং, কুরিয়ার মারফত হোম ডেলিভারি নিশ্চিতকরণ এবং আপনার মোবাইল নম্বরে অর্ডারের ট্র্যাকিং কোড পাঠানোর জন্য ব্যবহার করা হয়। আমরা কখনোই আপনার কোনো ব্যক্তিগত তথ্য তৃতীয় পক্ষের কাছে বিক্রি বা শেয়ার করি না।
                </p>
              </div>

              <div className="space-y-3">
                <h3 className="font-bold text-slate-900 dark:text-white text-base">৩. পেমেন্ট ও বিকাশ/নগদ সিকিউরিটি (Payment Gateway Security):</h3>
                <p>
                  বিকাশ, নগদ, রকেট ও অনলাইন ব্যাংক পেমেন্টের এনক্রিপ্টেড পেমেন্ট গেটওয়ে গেটওয়ে সার্ভিস (SSLCommerz) ব্যবহার করা হয়। আমাদের সার্ভারে গ্রাহকের কোনো পিন (PIN), ওটিপি (OTP) বা কার্ডের গোপনীয় নম্বর সংরক্ষণ করা হয় না।
                </p>
              </div>

              <div className="space-y-3">
                <h3 className="font-bold text-slate-900 dark:text-white text-base">৪. কাস্টমার সাপোর্ট ও ডাটা রিকুয়েস্ট (Customer Rights):</h3>
                <p>
                  যেকোনো সময়ে আপনার অ্যাকাউন্ট থেকে তথ্য মুছে ফেলা বা পরিবর্তন করার অধিকার আপনার রয়েছে। যেকোনো সহায়তার জন্য আমাদের হেল্পলাইন <strong>01738019928</strong> নম্বরে যোগাযোগ করতে পারেন।
                </p>
              </div>
            </div>
          </div>
        )}

        {/* 2. TERMS & CONDITIONS TAB */}
        {activeTab === 'terms' && (
          <div className="space-y-6">
            <div className="border-b border-slate-200 dark:border-slate-700 pb-4">
              <h2 className="text-xl font-extrabold text-slate-900 dark:text-white flex items-center gap-2">
                <FileText className="text-emerald-600" size={22} />
                শর্তাবলী (Terms & Conditions)
              </h2>
              <p className="text-xs text-slate-400 mt-1">অর্গানিক মার্ট ওয়েবসাইট ব্যবহারের সাধারণ নিয়মাবলী</p>
            </div>

            <div className="space-y-4">
              <div className="space-y-2">
                <h3 className="font-bold text-slate-900 dark:text-white text-base">১. ১০০% খাঁটি অর্গানিক পণ্যের নিশ্চয়তা:</h3>
                <p>
                  অর্গানিক মার্ট বাংলাদেশের সকল খাদ্যদ্রব্য (সুন্দরবনের মধু, ঘি, ঘানির খাঁটি সরিষার তেল, কালিজিরা চাল) কেমিক্যাল বা কৃত্রিম ভেজালমুক্ত। বিএসটিআই এবং ল্যাব টেস্টের গুণগত মান নিশ্চিত করেই পণ্য বাজারজাত করা হয়।
                </p>
              </div>

              <div className="space-y-2">
                <h3 className="font-bold text-slate-900 dark:text-white text-base">২. মূল্য নির্ধারণ ও স্টক নিয়মাবলী:</h3>
                <p>
                  ওয়েবসাইটে প্রদর্শিত সকল মূল্য বাংলাদেশি টাকায় (৳ BDT) নির্ধারিত। প্রাকৃতিক ফসল বা প্রাকৃতিক মধুর মৌসুমী সংগ্রহের উপর ভিত্তি করে কোনো পণ্যের প্রাইজ ও স্টক সাময়িক পরিবর্তিত হতে পারে।
                </p>
              </div>

              <div className="space-y-2">
                <h3 className="font-bold text-slate-900 dark:text-white text-base">৩. ক্যাশ অন ডেলিভারি (COD) পলিসি:</h3>
                <p>
                  গ্রাহক ডেলিভারি ম্যানের উপস্থিতিতে পার্সেল চেক করে মূল্য পরিশোধের সুযোগ পাবেন। পার্সেল খোলার সময় কোনো ত্রুটি দেখা গেলে সঙ্গে সঙ্গে হেল্পলাইনে কল দিন।
                </p>
              </div>

              <div className="space-y-2">
                <h3 className="font-bold text-slate-900 dark:text-white text-base">৪. কুপন কোড ও প্রমোশনাল অফার:</h3>
                <p>
                  প্রমোশনাল কুপন কোড (যেমন: ORGANIC20) নির্ধারিত মেয়াদের মধ্যে ব্যবহার করতে হবে। একটি অর্ডারে সর্বোচ্চ একটি কুপন কোড প্রযোজ্য হবে।
                </p>
              </div>
            </div>
          </div>
        )}

        {/* 3. REFUND & RETURN POLICY TAB */}
        {activeTab === 'refund' && (
          <div className="space-y-6">
            <div className="border-b border-slate-200 dark:border-slate-700 pb-4">
              <h2 className="text-xl font-extrabold text-slate-900 dark:text-white flex items-center gap-2">
                <RefreshCw className="text-emerald-600" size={22} />
                রিফান্ড ও রিটার্ন পলিসি (Refund & Return Policy)
              </h2>
              <p className="text-xs text-slate-400 mt-1">৭ দিনের ১০০% মানিব্যাক ও ফ্রি রিপ্লেসমেন্ট গ্যারান্টি</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 space-y-2">
                <CheckCircle2 className="text-emerald-600" size={24} />
                <h4 className="font-bold text-slate-900 dark:text-white">১. কুরিয়ার ড্যামেজ</h4>
                <p className="text-xs text-slate-500">পরিবহনকালে কাঁচের জার বা বোতল ভেঙে গেলে সম্পূর্ণ নতুন পণ্য ফ্রী দেওয়া হয়।</p>
              </div>

              <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 space-y-2">
                <CheckCircle2 className="text-emerald-600" size={24} />
                <h4 className="font-bold text-slate-900 dark:text-white">২. মানের অসন্তোষ</h4>
                <p className="text-xs text-slate-500">পণ্যের গুণগত মানে অসন্তুষ্ট হলে ৭ দিনের মধ্যে ফেরত দিয়ে টাকা ফেরত নিতে পারেন।</p>
              </div>

              <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 space-y-2">
                <CheckCircle2 className="text-emerald-600" size={24} />
                <h4 className="font-bold text-slate-900 dark:text-white">৩. দ্রুত রিফান্ড প্রসেস</h4>
                <p className="text-xs text-slate-500">রিটার্ন অনুমোদিত হলে ২৪-৪৮ ঘণ্টার মধ্যে বিকাশ বা নগদে টাকা ফেরত পাঠানো হয়।</p>
              </div>
            </div>

            <div className="space-y-3 pt-4">
              <h3 className="font-bold text-slate-900 dark:text-white text-base">কীভাবে রিটার্ন রিকোয়েস্ট পাঠাবেন (How to Request Return):</h3>
              <ol className="list-decimal pl-5 space-y-2 text-slate-600 dark:text-slate-300">
                <li>পণ্য পাওয়ার পর কোনো ত্রুটি দেখা গেলে একটি ছোট ছবি বা ভিডিও তুলুন।</li>
                <li>আমাদের হেল্পলাইন নম্বর <strong>01738019928</strong> এ কল দিন অথবা ফেসবুকে মেসেজ দিন।</li>
                <li>আমাদের সাপোর্ট টিম আপনার কুরিয়ার এড্রেস থেকে ড্যামেজড প্রডাক্ট পিকআপ করে নতুন পণ্য পাঠিয়ে দেবে।</li>
              </ol>
            </div>
          </div>
        )}

        {/* 4. SHIPPING & DELIVERY INFO TAB */}
        {activeTab === 'shipping' && (
          <div className="space-y-6">
            <div className="border-b border-slate-200 dark:border-slate-700 pb-4">
              <h2 className="text-xl font-extrabold text-slate-900 dark:text-white flex items-center gap-2">
                <Truck className="text-emerald-600" size={22} />
                শিপিং ও ডেলিভারি তথ্য (Shipping & Delivery Info)
              </h2>
              <p className="text-xs text-slate-400 mt-1">ঢাকা সিটি ও সারা বাংলাদেশে নিরাপদ হোম ডেলিভারি সেবা</p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              <div className="p-6 rounded-3xl bg-emerald-950 text-white space-y-3 border border-emerald-800">
                <span className="px-3 py-1 bg-lime-400 text-slate-950 font-black text-[10px] rounded-full uppercase">
                  Dhaka City Express
                </span>
                <h3 className="text-lg font-bold">ঢাকার ভেতরে হোম ডেলিভারি</h3>
                <ul className="text-xs text-emerald-200 space-y-1.5">
                  <li>• ডেলিভারির সময়: ২ থেকে ৪ ঘণ্টা</li>
                  <li>• ডেলিভারি চার্জ: <strong>৳৭০</strong></li>
                  <li>• <strong>৳১৫০০+ অর্ডারে ফ্রি ডেলিভারি!</strong></li>
                </ul>
              </div>

              <div className="p-6 rounded-3xl bg-slate-900 text-white space-y-3 border border-slate-800">
                <span className="px-3 py-1 bg-emerald-500 text-white font-black text-[10px] rounded-full uppercase">
                  Nationwide Courier
                </span>
                <h3 className="text-lg font-bold">ঢাকার বাইরে সারা বাংলাদেশ</h3>
                <ul className="text-xs text-slate-300 space-y-1.5">
                  <li>• কুরিয়ার পার্টনার: পাঠাও, রেডএক্স, সুন্দরবন</li>
                  <li>• ডেলিভারির সময়: ২৪ থেকে ৪৮ ঘণ্টা</li>
                  <li>• ডেলিভারি চার্জ: <strong>৳১২০</strong></li>
                </ul>
              </div>
            </div>

            <div className="p-4 rounded-2xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800 flex items-start gap-3">
              <AlertCircle className="text-amber-600 shrink-0 mt-0.5" size={20} />
              <div className="text-xs text-amber-900 dark:text-amber-200 space-y-1">
                <strong className="font-bold">সুরক্ষিত বাবল-র‍্যাপ প্যাকেজিং:</strong>
                <p>আমাদের সকল ঘি, মধু এবং সরিষার তেলের জার বিশেষ শক-প্রুফ বাবল প্যাকেটে প্যাক করা হয় যাতে পরিবহনকালে জার ভাঙা বা লিক করার কোনো সুযোগ না থাকে।</p>
              </div>
            </div>
          </div>
        )}

        {/* 5. FAQ TAB */}
        {activeTab === 'faq' && (
          <div className="space-y-6">
            <div className="border-b border-slate-200 dark:border-slate-700 pb-4 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
              <div>
                <h2 className="text-xl font-extrabold text-slate-900 dark:text-white flex items-center gap-2">
                  <HelpCircle className="text-emerald-600" size={22} />
                  সচরাচর জিজ্ঞাসা (FAQ - Frequently Asked Questions)
                </h2>
                <p className="text-xs text-slate-400 mt-1">পণ্য অর্ডার, ডেলিভারি ও মান সম্পর্কে সাধারণ প্রশ্নের উত্তর</p>
              </div>

              <div className="relative w-full md:w-64">
                <Search size={16} className="absolute left-3 top-2.5 text-slate-400" />
                <input
                  type="text"
                  placeholder="প্রশ্ন খুঁজুন (Search FAQ)..."
                  value={faqSearch}
                  onChange={e => setFaqSearch(e.target.value)}
                  className="w-full pl-9 pr-3 py-2 rounded-xl text-xs border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 outline-none focus:border-emerald-500"
                />
              </div>
            </div>

            <div className="space-y-3">
              {faqItems
                .filter(item => !faqSearch || item.q.toLowerCase().includes(faqSearch.toLowerCase()) || item.a.toLowerCase().includes(faqSearch.toLowerCase()))
                .map((item, idx) => {
                  const isOpen = openFaqIndex === idx;
                  return (
                    <div
                      key={idx}
                      className="border border-slate-200 dark:border-slate-700 rounded-2xl overflow-hidden transition-colors"
                    >
                      <button
                        onClick={() => setOpenFaqIndex(isOpen ? null : idx)}
                        className="w-full text-left p-4 bg-slate-50 dark:bg-slate-900/60 hover:bg-slate-100 dark:hover:bg-slate-900 flex items-center justify-between font-bold text-slate-900 dark:text-white text-xs sm:text-sm gap-3"
                      >
                        <span className="flex items-center gap-2">
                          <span className="w-2 h-2 rounded-full bg-emerald-500 shrink-0" />
                          {item.q}
                        </span>
                        {isOpen ? <ChevronUp size={18} className="text-emerald-600 shrink-0" /> : <ChevronDown size={18} className="text-slate-400 shrink-0" />}
                      </button>

                      {isOpen && (
                        <div className="p-4 text-xs text-slate-600 dark:text-slate-300 bg-white dark:bg-slate-800 border-t border-slate-100 dark:border-slate-700/60 leading-relaxed">
                          {item.a}
                        </div>
                      )}
                    </div>
                  );
                })}
            </div>
          </div>
        )}

        {/* Emergency Direct Contact Callout */}
        <div className="pt-8 border-t border-slate-200 dark:border-slate-700 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-emerald-100 dark:bg-emerald-950 flex items-center justify-center text-emerald-600 shrink-0">
              <Phone size={18} />
            </div>
            <div>
              <p className="font-bold text-slate-900 dark:text-white">জরুরি সহায়তার প্রয়োজন? (Need Direct Support?)</p>
              <p className="text-slate-400">কল করুন: <strong>01738019928</strong> (সকাল ১০টা - রাত ১০টা)</p>
            </div>
          </div>

          <a
            href="https://www.facebook.com/arafataivideocreator"
            target="_blank"
            rel="noreferrer"
            className="px-5 py-2.5 bg-sky-500 hover:bg-sky-600 text-white font-extrabold rounded-xl shadow flex items-center gap-2 shrink-0 transition-transform hover:scale-105"
          >
            <MessageCircle size={16} />
            মেসেঞ্জারে চ্যাট করুন (Messenger)
          </a>
        </div>
      </div>
    </div>
  );
};
