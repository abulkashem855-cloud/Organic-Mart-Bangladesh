import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Calendar, User, Clock, ArrowRight, Plus, Edit2, Trash2, X, Sparkles, ShieldCheck } from 'lucide-react';
import { BlogPost } from '../types';
import { useAuth } from '../context/AuthContext';

export const BlogPage: React.FC = () => {
  const { isAdmin, token } = useAuth();
  const [blogs, setBlogs] = useState<BlogPost[]>([]);
  const [editingBlog, setEditingBlog] = useState<Partial<BlogPost> | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3000);
  };

  const fetchBlogs = () => {
    fetch('/api/blogs')
      .then(res => res.json())
      .then(data => setBlogs(data || []))
      .catch(err => console.error(err));
  };

  useEffect(() => {
    fetchBlogs();
  }, []);

  const handleOpenAdd = () => {
    setEditingBlog({
      title: '',
      category: 'Organic Living',
      author: 'Admin Kashem',
      readTime: '3 min read',
      image: 'https://images.unsplash.com/photo-1542838132-92c53300491e?auto=format&fit=crop&w=800&q=80',
      excerpt: '',
      content: ''
    });
    setIsModalOpen(true);
  };

  const handleOpenEdit = (e: React.MouseEvent, blog: BlogPost) => {
    e.preventDefault();
    e.stopPropagation();
    setEditingBlog(blog);
    setIsModalOpen(true);
  };

  const handleDelete = async (e: React.MouseEvent, id: string) => {
    e.preventDefault();
    e.stopPropagation();
    if (!window.confirm('আপনি কি এই ব্লগ পোস্টটি মুছে ফেলতে চান? (Are you sure you want to delete this blog?)')) return;

    try {
      const res = await fetch(`/api/admin/blogs/${id}`, {
        method: 'DELETE',
        headers: { Authorization: `Bearer ${token}` }
      });

      if (res.ok) {
        showToast('ব্লগটি সফলভাবে মুছে ফেলা হয়েছে! (Blog deleted successfully)');
        fetchBlogs();
      } else {
        alert('Failed to delete blog.');
      }
    } catch (err) {
      alert('Error deleting blog.');
    }
  };

  const handleSaveBlog = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingBlog?.title || !editingBlog?.content) {
      alert('Please fill in Title and Content');
      return;
    }

    const isEdit = !!editingBlog.id;
    const url = isEdit ? `/api/admin/blogs/${editingBlog.id}` : '/api/admin/blogs';
    const method = isEdit ? 'PUT' : 'POST';

    try {
      const res = await fetch(url, {
        method,
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify(editingBlog)
      });

      if (res.ok) {
        showToast(isEdit ? 'ব্লগ আপডেট সম্পন্ন হয়েছে! (Blog updated!)' : 'নতুন ব্লগ সফলভাবে প্রকাশিত হয়েছে! (New blog published!)');
        setIsModalOpen(false);
        setEditingBlog(null);
        fetchBlogs();
      } else {
        alert('Failed to save blog post.');
      }
    } catch (err) {
      alert('Error saving blog.');
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-10">
      {toastMessage && (
        <div className="fixed top-20 right-4 z-50 bg-emerald-950 text-white px-4 py-3 rounded-2xl shadow-2xl border border-emerald-500 font-bold text-xs flex items-center gap-2 animate-bounce">
          <Sparkles size={16} className="text-lime-400" />
          {toastMessage}
        </div>
      )}

      <div className="flex flex-col md:flex-row items-center justify-between gap-4">
        <div className="text-center md:text-left max-w-2xl">
          <span className="text-xs font-bold text-emerald-600 dark:text-emerald-400 uppercase tracking-wider flex items-center gap-1.5 justify-center md:justify-start">
            Organic Living & Health Journal
            {isAdmin && (
              <span className="bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300 px-2 py-0.5 rounded text-[10px] font-black flex items-center gap-1">
                <ShieldCheck size={12} /> Admin Manager
              </span>
            )}
          </span>
          <h1 className="text-3xl sm:text-4xl font-extrabold text-slate-900 dark:text-white mt-1">
            Health Tips, Organic Farming & Nutrition
          </h1>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-2">
            Discover why chemical-free food, raw Sundarban honey, and unpolished rice transform your immunity.
          </p>
        </div>

        {isAdmin && (
          <button
            onClick={handleOpenAdd}
            className="px-5 py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-xs rounded-2xl shadow-lg shadow-emerald-600/30 transition-all flex items-center gap-2 shrink-0"
          >
            <Plus size={18} />
            নতুন ব্লগ লিখুন (Add New Blog)
          </button>
        )}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {blogs.map(blog => (
          <div
            key={blog.id}
            className="group rounded-3xl overflow-hidden bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-800 shadow-sm hover:shadow-xl transition-all flex flex-col relative"
          >
            <Link to={`/blog/${blog.slug}`} className="flex-1 flex flex-col">
              <div className="aspect-video overflow-hidden relative">
                <img
                  src={blog.image}
                  alt={blog.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />

                {/* Admin Quick Action Floating Buttons */}
                {isAdmin && (
                  <div className="absolute top-3 right-3 flex items-center gap-2 bg-slate-900/80 backdrop-blur p-1.5 rounded-xl border border-white/20 z-10">
                    <button
                      onClick={e => handleOpenEdit(e, blog)}
                      title="Edit Blog"
                      className="p-1.5 bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold rounded-lg transition-transform hover:scale-110"
                    >
                      <Edit2 size={14} />
                    </button>
                    <button
                      onClick={e => handleDelete(e, blog.id)}
                      title="Delete Blog"
                      className="p-1.5 bg-red-600 hover:bg-red-700 text-white font-bold rounded-lg transition-transform hover:scale-110"
                    >
                      <Trash2 size={14} />
                    </button>
                  </div>
                )}
              </div>

              <div className="p-6 flex-1 flex flex-col justify-between space-y-4">
                <div>
                  <div className="flex items-center gap-3 text-[10px] font-bold text-emerald-600 uppercase mb-2">
                    <span className="bg-emerald-50 dark:bg-emerald-950 px-2 py-0.5 rounded-full">{blog.category}</span>
                    <span className="text-slate-400 flex items-center gap-1"><Clock size={12} /> {blog.readTime}</span>
                  </div>

                  <h2 className="text-base font-bold text-slate-900 dark:text-white group-hover:text-emerald-600 transition-colors line-clamp-2">
                    {blog.title}
                  </h2>

                  <p className="text-xs text-slate-500 dark:text-slate-400 line-clamp-3 mt-2">
                    {blog.excerpt}
                  </p>
                </div>

                <div className="pt-4 border-t border-slate-100 dark:border-slate-700/60 flex items-center justify-between text-xs">
                  <span className="text-slate-400 flex items-center gap-1"><User size={12} /> {blog.author}</span>
                  <span className="font-bold text-emerald-600 dark:text-emerald-400 flex items-center gap-1">
                    Read More <ArrowRight size={14} />
                  </span>
                </div>
              </div>
            </Link>

            {isAdmin && (
              <div className="px-6 pb-4 pt-0 flex items-center justify-end gap-2 border-t border-slate-100 dark:border-slate-800 text-xs">
                <button
                  onClick={e => handleOpenEdit(e, blog)}
                  className="px-3 py-1 bg-amber-100 hover:bg-amber-200 text-amber-900 font-bold rounded-lg flex items-center gap-1 transition-colors text-[11px]"
                >
                  <Edit2 size={12} /> Edit
                </button>
                <button
                  onClick={e => handleDelete(e, blog.id)}
                  className="px-3 py-1 bg-red-100 hover:bg-red-200 text-red-900 font-bold rounded-lg flex items-center gap-1 transition-colors text-[11px]"
                >
                  <Trash2 size={12} /> Delete
                </button>
              </div>
            )}
          </div>
        ))}
      </div>

      {/* Admin Add / Edit Blog Modal */}
      {isModalOpen && editingBlog && (
        <div className="fixed inset-0 z-50 bg-slate-900/70 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl max-w-2xl w-full p-6 sm:p-8 space-y-6 shadow-2xl my-8">
            <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-4">
              <h2 className="text-lg font-black text-slate-900 dark:text-white flex items-center gap-2">
                <Edit2 className="text-emerald-600" size={20} />
                {editingBlog.id ? 'ব্লগ এডিট করুন (Edit Blog)' : 'নতুন ব্লগ তৈরি করুন (Create Blog)'}
              </h2>
              <button
                onClick={() => setIsModalOpen(false)}
                className="p-2 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-full text-slate-400"
              >
                <X size={20} />
              </button>
            </div>

            <form onSubmit={handleSaveBlog} className="space-y-4 text-xs font-semibold">
              <div>
                <label className="block text-slate-700 dark:text-slate-300 font-bold mb-1">
                  ব্লগ শিরোনাম (Blog Title) *
                </label>
                <input
                  type="text"
                  required
                  value={editingBlog.title || ''}
                  onChange={e => setEditingBlog({ ...editingBlog, title: e.target.value })}
                  placeholder="e.g. Sundarban Honey Benefits for Immunity"
                  className="w-full px-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white outline-none focus:border-emerald-500 font-bold"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-slate-700 dark:text-slate-300 font-bold mb-1">
                    ক্যাটাগরি (Category)
                  </label>
                  <input
                    type="text"
                    value={editingBlog.category || 'Organic Living'}
                    onChange={e => setEditingBlog({ ...editingBlog, category: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white outline-none"
                  />
                </div>

                <div>
                  <label className="block text-slate-700 dark:text-slate-300 font-bold mb-1">
                    লেখক (Author)
                  </label>
                  <input
                    type="text"
                    value={editingBlog.author || 'Admin Kashem'}
                    onChange={e => setEditingBlog({ ...editingBlog, author: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white outline-none"
                  />
                </div>

                <div>
                  <label className="block text-slate-700 dark:text-slate-300 font-bold mb-1">
                    পড়ার সময় (Read Time)
                  </label>
                  <input
                    type="text"
                    value={editingBlog.readTime || '3 min read'}
                    onChange={e => setEditingBlog({ ...editingBlog, readTime: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-700 dark:text-slate-300 font-bold mb-1">
                  ছবি URL (Cover Image URL)
                </label>
                <input
                  type="text"
                  value={editingBlog.image || ''}
                  onChange={e => setEditingBlog({ ...editingBlog, image: e.target.value })}
                  placeholder="https://images.unsplash.com/..."
                  className="w-full px-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white outline-none font-mono text-[11px]"
                />
              </div>

              <div>
                <label className="block text-slate-700 dark:text-slate-300 font-bold mb-1">
                  সংক্ষিপ্ত অংশ (Excerpt)
                </label>
                <textarea
                  rows={2}
                  value={editingBlog.excerpt || ''}
                  onChange={e => setEditingBlog({ ...editingBlog, excerpt: e.target.value })}
                  placeholder="Short summary displayed on list page..."
                  className="w-full px-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white outline-none"
                />
              </div>

              <div>
                <label className="block text-slate-700 dark:text-slate-300 font-bold mb-1">
                  মূল বিস্তারিত কনটেন্ট (Full Content) *
                </label>
                <textarea
                  rows={7}
                  required
                  value={editingBlog.content || ''}
                  onChange={e => setEditingBlog({ ...editingBlog, content: e.target.value })}
                  placeholder="Write complete article details here..."
                  className="w-full px-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white outline-none font-sans"
                />
              </div>

              <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-200 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-5 py-2.5 bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-bold rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-6 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold rounded-xl shadow-lg shadow-emerald-600/20"
                >
                  {editingBlog.id ? 'Update Post' : 'Publish Blog'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
