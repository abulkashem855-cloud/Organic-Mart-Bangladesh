import React from 'react';
import { useSearchParams, Link } from 'react-router-dom';
import { CheckCircle2, Truck, ArrowRight, ShoppingBag } from 'lucide-react';

export const OrderSuccessPage: React.FC = () => {
  const [searchParams] = useSearchParams();
  const orderId = searchParams.get('orderId') || 'OMB-2026-8941';

  return (
    <div className="max-w-2xl mx-auto px-4 py-16 text-center space-y-6">
      <div className="w-20 h-20 bg-emerald-100 dark:bg-emerald-950 text-emerald-600 dark:text-emerald-400 rounded-full flex items-center justify-center mx-auto shadow-xl shadow-emerald-500/10">
        <CheckCircle2 size={48} className="animate-bounce" />
      </div>

      <div>
        <span className="text-xs font-bold text-emerald-600 uppercase tracking-widest">
          Order Successfully Placed
        </span>
        <h1 className="text-3xl font-black text-slate-900 dark:text-white mt-1">
          Thank You For Choosing Organic Living!
        </h1>
        <p className="text-xs text-slate-500 dark:text-slate-400 mt-2 max-w-md mx-auto">
          Your order has been received and sent to our partner organic farm. Our team is packing your chemical-free products with care.
        </p>
      </div>

      <div className="p-6 bg-white dark:bg-slate-800 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm max-w-md mx-auto space-y-3 text-left">
        <div className="flex justify-between items-center text-xs pb-3 border-b border-slate-100 dark:border-slate-700">
          <span className="text-slate-500">Order ID:</span>
          <span className="font-extrabold font-mono text-emerald-600 dark:text-emerald-400 text-sm">{orderId}</span>
        </div>
        <div className="flex justify-between items-center text-xs pb-3 border-b border-slate-100 dark:border-slate-700">
          <span className="text-slate-500">Estimated Delivery:</span>
          <span className="font-bold text-slate-800 dark:text-slate-200">Express 2-Hour (Dhaka)</span>
        </div>
        <div className="flex items-center gap-2 text-xs text-slate-500 pt-1">
          <Truck size={16} className="text-emerald-600" />
          <span>Tracking details sent via SMS & WhatsApp</span>
        </div>
      </div>

      <div className="flex flex-col sm:flex-row items-center justify-center gap-3 pt-4">
        <Link
          to={`/track?query=${orderId}`}
          className="w-full sm:w-auto px-8 py-3.5 bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-xs rounded-2xl transition-colors shadow-lg shadow-emerald-600/20 flex items-center justify-center gap-2"
        >
          <Truck size={16} /> Track Order Progress
        </Link>

        <Link
          to="/shop"
          className="w-full sm:w-auto px-8 py-3.5 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-800 dark:text-slate-200 font-extrabold text-xs rounded-2xl transition-colors flex items-center justify-center gap-2"
        >
          <ShoppingBag size={16} /> Continue Shopping
        </Link>
      </div>
    </div>
  );
};
