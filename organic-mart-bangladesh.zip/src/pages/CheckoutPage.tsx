import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { ShieldCheck, Truck, CreditCard, CheckCircle2, ArrowRight } from 'lucide-react';
import { useCart } from '../context/CartContext';
import { useAuth } from '../context/AuthContext';
import { BkashPaymentModal } from '../components/checkout/BkashPaymentModal';
import { NagadPaymentModal } from '../components/checkout/NagadPaymentModal';
import { RocketPaymentModal } from '../components/checkout/RocketPaymentModal';
import { PaymentMethod, StoreSettings } from '../types';

export const CheckoutPage: React.FC = () => {
  const { cart, subtotal, shippingZone, setShippingZone, appliedCoupon, clearCart } = useCart();
  const { user } = useAuth();
  const navigate = useNavigate();

  // Form State
  const [fullName, setFullName] = useState(user?.name || '');
  const [email, setEmail] = useState(user?.email || '');
  const [phone, setPhone] = useState(user?.phone || '');
  const [division, setDivision] = useState(shippingZone === 'outside' ? 'Chittagong' : 'Dhaka');
  const [district, setDistrict] = useState(shippingZone === 'outside' ? 'Chittagong' : 'Dhaka');
  const [thana, setThana] = useState('Gulshan');
  const [address, setAddress] = useState('');
  const [notes, setNotes] = useState('');
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('cod');

  // Store Settings (Dynamic Delivery Charges)
  const [storeSettings, setStoreSettings] = useState<StoreSettings>({
    insideDhakaFee: 70,
    outsideDhakaFee: 120,
    freeShippingMin: 1500
  });

  // Modal States
  const [isBkashOpen, setIsBkashOpen] = useState(false);
  const [isNagadOpen, setIsNagadOpen] = useState(false);
  const [isRocketOpen, setIsRocketOpen] = useState(false);
  const [transactionId, setTransactionId] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    fetch('/api/settings')
      .then(res => res.json())
      .then(data => {
        if (data && typeof data.insideDhakaFee === 'number') {
          setStoreSettings(data);
        }
      })
      .catch(() => {});
  }, []);

  // Sync division change with shipping zone
  const handleDivisionChange = (newDivision: string) => {
    setDivision(newDivision);
    if (newDivision.toLowerCase() === 'dhaka') {
      setShippingZone('dhaka');
    } else {
      setShippingZone('outside');
    }
  };

  const handleZoneSelect = (zone: 'dhaka' | 'outside') => {
    setShippingZone(zone);
    if (zone === 'dhaka') {
      setDivision('Dhaka');
      setDistrict('Dhaka');
    } else {
      if (division.toLowerCase() === 'dhaka') {
        setDivision('Chittagong');
        setDistrict('Chittagong');
      }
    }
  };

  const discountVal = appliedCoupon ? appliedCoupon.discountAmount : 0;
  
  const isInsideDhaka = division.toLowerCase() === 'dhaka' || shippingZone === 'dhaka';
  const insideFee = storeSettings.insideDhakaFee;
  const outsideFee = storeSettings.outsideDhakaFee;
  const freeMin = storeSettings.freeShippingMin || 1500;

  let shippingCharge = isInsideDhaka ? insideFee : outsideFee;
  if (isInsideDhaka && freeMin > 0 && subtotal >= freeMin) {
    shippingCharge = 0;
  }

  const grandTotal = Math.max(0, subtotal - discountVal + shippingCharge);

  const handlePlaceOrder = async (confirmedTrxId?: string) => {
    if (!fullName || !phone || !address) {
      alert('Please fill in your Full Name, Phone Number, and Delivery Address.');
      return;
    }

    setIsSubmitting(true);

    const orderPayload = {
      userId: user?.id,
      customerName: fullName,
      customerEmail: email || 'customer@organicmart.bd',
      customerPhone: phone,
      shippingAddress: {
        id: 'addr-' + Date.now(),
        fullName,
        phone,
        division,
        district,
        thana,
        address
      },
      items: cart.map(item => ({
        productId: item.product.id,
        name: item.product.name,
        price: item.product.discountPrice || item.product.price,
        quantity: item.quantity,
        image: item.product.images[0],
        unit: item.product.unit
      })),
      subtotal,
      discount: discountVal,
      couponCode: appliedCoupon?.code,
      shippingCharge,
      tax: 0,
      grandTotal,
      paymentMethod,
      transactionId: confirmedTrxId || transactionId || undefined
    };

    try {
      const res = await fetch('/api/orders', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(orderPayload)
      });

      const data = await res.json();
      if (res.ok) {
        clearCart();
        navigate(`/order-success?orderId=${data.id}`);
      } else {
        alert(data.error || 'Failed to place order.');
      }
    } catch (err) {
      alert('Connection error. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleSubmitForm = (e: React.FormEvent) => {
    e.preventDefault();
    if (paymentMethod === 'bkash') {
      setIsBkashOpen(true);
    } else if (paymentMethod === 'nagad') {
      setIsNagadOpen(true);
    } else if (paymentMethod === 'rocket') {
      setIsRocketOpen(true);
    } else {
      handlePlaceOrder();
    }
  };

  const divisions = ['Dhaka', 'Chittagong', 'Rajshahi', 'Khulna', 'Sylhet', 'Barisal', 'Rangpur', 'Mymensingh'];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8">
      <div className="flex items-center gap-3">
        <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white">
          Secure Checkout
        </h1>
        <span className="flex items-center gap-1 text-xs font-bold text-emerald-600 bg-emerald-50 dark:bg-emerald-950/80 px-3 py-1 rounded-full">
          <ShieldCheck size={14} /> 256-Bit SSL Encrypted
        </span>
      </div>

      <form onSubmit={handleSubmitForm} className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Left Column: Shipping & Payment Details */}
        <div className="lg:col-span-2 space-y-8">
          {/* Shipping Information Card */}
          <div className="bg-white dark:bg-slate-800 p-6 sm:p-8 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
            <h2 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2 border-b border-slate-100 dark:border-slate-800 pb-3">
              <Truck size={18} className="text-emerald-600" /> Shipping & Contact Details
            </h2>

            {/* Delivery Area Selection Buttons */}
            <div className="p-4 rounded-2xl bg-emerald-50/60 dark:bg-slate-900/80 border border-emerald-200 dark:border-slate-800 space-y-2">
              <div className="flex items-center justify-between">
                <label className="text-xs font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
                  <Truck size={15} className="text-emerald-600" /> Select Delivery Zone *
                </label>
                <span className="text-[10px] font-mono font-extrabold text-emerald-700 dark:text-emerald-400">
                  Applied Charge: ৳{shippingCharge}
                </span>
              </div>
              <div className="grid grid-cols-2 gap-3 text-xs font-bold">
                <button
                  type="button"
                  onClick={() => handleZoneSelect('dhaka')}
                  className={`py-2.5 px-3 rounded-xl border text-center transition-all flex flex-col items-center justify-center gap-0.5 ${
                    isInsideDhaka
                      ? 'bg-emerald-600 text-white border-emerald-600 shadow-md shadow-emerald-600/20'
                      : 'bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700 hover:border-emerald-500'
                  }`}
                >
                  <span>Inside Dhaka (৳{insideFee})</span>
                  <span className="text-[10px] opacity-80 font-normal">2-4 Hours Express</span>
                </button>

                <button
                  type="button"
                  onClick={() => handleZoneSelect('outside')}
                  className={`py-2.5 px-3 rounded-xl border text-center transition-all flex flex-col items-center justify-center gap-0.5 ${
                    !isInsideDhaka
                      ? 'bg-emerald-600 text-white border-emerald-600 shadow-md shadow-emerald-600/20'
                      : 'bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700 hover:border-emerald-500'
                  }`}
                >
                  <span>Outside Dhaka (৳{outsideFee})</span>
                  <span className="text-[10px] opacity-80 font-normal">24-48 Hours Courier</span>
                </button>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Full Name *
                </label>
                <input
                  type="text"
                  value={fullName}
                  onChange={e => setFullName(e.target.value)}
                  required
                  placeholder="e.g. Tanvir Ahmed"
                  className="w-full px-4 py-2.5 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-slate-900 dark:text-white outline-none focus:border-emerald-500"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Mobile Number (bKash/Nagad/Call) *
                </label>
                <input
                  type="tel"
                  value={phone}
                  onChange={e => setPhone(e.target.value)}
                  required
                  placeholder="01712345678"
                  className="w-full px-4 py-2.5 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-slate-900 dark:text-white outline-none focus:border-emerald-500 font-mono"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Email Address (Optional)
                </label>
                <input
                  type="email"
                  value={email}
                  onChange={e => setEmail(e.target.value)}
                  placeholder="name@example.com"
                  className="w-full px-4 py-2.5 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-slate-900 dark:text-white outline-none focus:border-emerald-500"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Division *
                </label>
                <select
                  value={division}
                  onChange={e => handleDivisionChange(e.target.value)}
                  className="w-full px-4 py-2.5 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-slate-900 dark:text-white outline-none"
                >
                  {divisions.map(d => (
                    <option key={d} value={d}>{d}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                  District / City *
                </label>
                <input
                  type="text"
                  value={district}
                  onChange={e => setDistrict(e.target.value)}
                  required
                  className="w-full px-4 py-2.5 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-slate-900 dark:text-white outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Thana / Area *
                </label>
                <input
                  type="text"
                  value={thana}
                  onChange={e => setThana(e.target.value)}
                  required
                  placeholder="e.g. Gulshan / Dhanmondi"
                  className="w-full px-4 py-2.5 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-slate-900 dark:text-white outline-none"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                Full Delivery Address *
              </label>
              <textarea
                rows={2}
                value={address}
                onChange={e => setAddress(e.target.value)}
                required
                placeholder="House #, Road #, Apartment / Flat #"
                className="w-full px-4 py-2.5 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-slate-900 dark:text-white outline-none"
              />
            </div>
          </div>

          {/* Payment Method Selector Card */}
          <div className="bg-white dark:bg-slate-800 p-6 sm:p-8 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
            <h2 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2 border-b border-slate-100 dark:border-slate-800 pb-3">
              <CreditCard size={18} className="text-emerald-600" /> Select Payment Method
            </h2>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {/* Cash On Delivery */}
              <label
                className={`p-4 rounded-2xl border-2 cursor-pointer flex items-center justify-between transition-all ${
                  paymentMethod === 'cod'
                    ? 'border-emerald-600 bg-emerald-50/50 dark:bg-emerald-950/40'
                    : 'border-slate-200 dark:border-slate-700'
                }`}
              >
                <div className="flex items-center gap-3">
                  <input
                    type="radio"
                    name="pm"
                    value="cod"
                    checked={paymentMethod === 'cod'}
                    onChange={() => setPaymentMethod('cod')}
                    className="accent-emerald-600"
                  />
                  <div>
                    <p className="text-xs font-bold text-slate-900 dark:text-white">Cash On Delivery (COD)</p>
                    <p className="text-[10px] text-slate-500">Pay cash upon home delivery</p>
                  </div>
                </div>
                <span className="px-2 py-0.5 bg-emerald-600 text-white text-[10px] font-bold rounded">COD</span>
              </label>

              {/* bKash */}
              <label
                className={`p-4 rounded-2xl border-2 cursor-pointer flex items-center justify-between transition-all ${
                  paymentMethod === 'bkash'
                    ? 'border-pink-600 bg-pink-50/50 dark:bg-pink-950/40'
                    : 'border-slate-200 dark:border-slate-700'
                }`}
              >
                <div className="flex items-center gap-3">
                  <input
                    type="radio"
                    name="pm"
                    value="bkash"
                    checked={paymentMethod === 'bkash'}
                    onChange={() => setPaymentMethod('bkash')}
                    className="accent-pink-600"
                  />
                  <div>
                    <p className="text-xs font-bold text-slate-900 dark:text-white">bKash Payment</p>
                    <p className="text-[10px] text-pink-600 dark:text-pink-400 font-mono font-bold">Acc: 01738019928</p>
                  </div>
                </div>
                <span className="px-2 py-0.5 bg-pink-600 text-white text-[10px] font-bold rounded">bKash</span>
              </label>

              {/* Nagad */}
              <label
                className={`p-4 rounded-2xl border-2 cursor-pointer flex items-center justify-between transition-all ${
                  paymentMethod === 'nagad'
                    ? 'border-orange-600 bg-orange-50/50 dark:bg-orange-950/40'
                    : 'border-slate-200 dark:border-slate-700'
                }`}
              >
                <div className="flex items-center gap-3">
                  <input
                    type="radio"
                    name="pm"
                    value="nagad"
                    checked={paymentMethod === 'nagad'}
                    onChange={() => setPaymentMethod('nagad')}
                    className="accent-orange-600"
                  />
                  <div>
                    <p className="text-xs font-bold text-slate-900 dark:text-white">Nagad Payment</p>
                    <p className="text-[10px] text-orange-600 dark:text-orange-400 font-mono font-bold">Acc: 01738019928</p>
                  </div>
                </div>
                <span className="px-2 py-0.5 bg-orange-600 text-white text-[10px] font-bold rounded">Nagad</span>
              </label>

              {/* Rocket */}
              <label
                className={`p-4 rounded-2xl border-2 cursor-pointer flex items-center justify-between transition-all ${
                  paymentMethod === 'rocket'
                    ? 'border-purple-600 bg-purple-50/50 dark:bg-purple-950/40'
                    : 'border-slate-200 dark:border-slate-700'
                }`}
              >
                <div className="flex items-center gap-3">
                  <input
                    type="radio"
                    name="pm"
                    value="rocket"
                    checked={paymentMethod === 'rocket'}
                    onChange={() => setPaymentMethod('rocket')}
                    className="accent-purple-600"
                  />
                  <div>
                    <p className="text-xs font-bold text-slate-900 dark:text-white">DBBL Rocket Payment</p>
                    <p className="text-[10px] text-purple-600 dark:text-purple-400 font-mono font-bold">Acc: 01738019928</p>
                  </div>
                </div>
                <span className="px-2 py-0.5 bg-purple-600 text-white text-[10px] font-bold rounded">Rocket</span>
              </label>

              {/* SSLCommerz */}
              <label
                className={`p-4 rounded-2xl border-2 cursor-pointer flex items-center justify-between transition-all ${
                  paymentMethod === 'sslcommerz'
                    ? 'border-blue-600 bg-blue-50/50 dark:bg-blue-950/40'
                    : 'border-slate-200 dark:border-slate-700'
                }`}
              >
                <div className="flex items-center gap-3">
                  <input
                    type="radio"
                    name="pm"
                    value="sslcommerz"
                    checked={paymentMethod === 'sslcommerz'}
                    onChange={() => setPaymentMethod('sslcommerz')}
                    className="accent-blue-600"
                  />
                  <div>
                    <p className="text-xs font-bold text-slate-900 dark:text-white">Debit/Credit Card (SSLCommerz)</p>
                    <p className="text-[10px] text-slate-500">Visa, Mastercard, DBBL</p>
                  </div>
                </div>
                <span className="px-2 py-0.5 bg-blue-600 text-white text-[10px] font-bold rounded">Cards</span>
              </label>
            </div>
          </div>
        </div>

        {/* Right Column: Order Summary & Place Order CTA */}
        <div className="space-y-6">
          <div className="bg-white dark:bg-slate-800 p-6 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-4 sticky top-24">
            <h2 className="text-base font-bold text-slate-900 dark:text-white border-b border-slate-100 dark:border-slate-800 pb-3">
              Order Items ({cart.length})
            </h2>

            <div className="space-y-3 max-h-60 overflow-y-auto pr-1 divide-y divide-slate-100 dark:divide-slate-800">
              {cart.map(({ product, quantity }) => (
                <div key={product.id} className="pt-2 flex items-center gap-3">
                  <img src={product.images[0]} alt="" className="w-12 h-12 rounded-xl object-cover border border-slate-100 dark:border-slate-800" />
                  <div className="flex-1 min-w-0">
                    <p className="text-xs font-bold text-slate-900 dark:text-white truncate">{product.name}</p>
                    <p className="text-[10px] text-slate-500">Qty: {quantity} x ৳{product.discountPrice || product.price}</p>
                  </div>
                  <span className="text-xs font-bold text-slate-900 dark:text-white">
                    ৳{((product.discountPrice || product.price) * quantity).toLocaleString()}
                  </span>
                </div>
              ))}
            </div>

            <div className="space-y-2 text-xs text-slate-600 dark:text-slate-300 pt-3 border-t border-slate-100 dark:border-slate-800">
              <div className="flex justify-between"><span>Subtotal:</span><span>৳{subtotal.toLocaleString()}</span></div>
              {discountVal > 0 && <div className="flex justify-between text-emerald-600 font-bold"><span>Discount:</span><span>-৳{discountVal.toLocaleString()}</span></div>}
              <div className="flex justify-between"><span>Shipping ({division}):</span><span>৳{shippingCharge}</span></div>
              <div className="flex justify-between text-base font-black text-slate-900 dark:text-white pt-3 border-t border-slate-200 dark:border-slate-700">
                <span>Total Amount:</span>
                <span className="text-emerald-600 dark:text-emerald-400">৳{grandTotal.toLocaleString()}</span>
              </div>
            </div>

            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full py-4 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-extrabold rounded-2xl transition-all shadow-xl shadow-emerald-600/25 flex items-center justify-center gap-2"
            >
              <span>{isSubmitting ? 'Processing Order...' : `Confirm Order (৳${grandTotal.toLocaleString()})`}</span>
              <ArrowRight size={16} />
            </button>
          </div>
        </div>
      </form>

      {/* Payment Modals */}
      <BkashPaymentModal
        amount={grandTotal}
        isOpen={isBkashOpen}
        onClose={() => setIsBkashOpen(false)}
        onSuccess={trx => {
          setIsBkashOpen(false);
          setTransactionId(trx);
          handlePlaceOrder(trx);
        }}
      />

      <NagadPaymentModal
        amount={grandTotal}
        isOpen={isNagadOpen}
        onClose={() => setIsNagadOpen(false)}
        onSuccess={trx => {
          setIsNagadOpen(false);
          setTransactionId(trx);
          handlePlaceOrder(trx);
        }}
      />

      <RocketPaymentModal
        amount={grandTotal}
        isOpen={isRocketOpen}
        onClose={() => setIsRocketOpen(false)}
        onSuccess={trx => {
          setIsRocketOpen(false);
          setTransactionId(trx);
          handlePlaceOrder(trx);
        }}
      />
    </div>
  );
};
