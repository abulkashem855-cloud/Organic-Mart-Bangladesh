import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, Sparkles, Flame, Clock, Award, ShieldCheck } from 'lucide-react';
import { HeroSlider } from '../components/home/HeroSlider';
import { CategoryGrid } from '../components/home/CategoryGrid';
import { ProductCard } from '../components/home/ProductCard';
import { WhyChooseUs } from '../components/home/WhyChooseUs';
import { Testimonials } from '../components/home/Testimonials';
import { InstagramGallery } from '../components/home/InstagramGallery';
import { FaqSection } from '../components/home/FaqSection';
import { Product, Category, BlogPost } from '../types';

export const HomePage: React.FC = () => {
  const [categories, setCategories] = useState<Category[]>([]);
  const [bestSellers, setBestSellers] = useState<Product[]>([]);
  const [todayDeals, setTodayDeals] = useState<Product[]>([]);
  const [featuredProducts, setFeaturedProducts] = useState<Product[]>([]);
  const [blogs, setBlogs] = useState<BlogPost[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    Promise.all([
      fetch('/api/categories').then(res => res.json()),
      fetch('/api/products?bestSeller=true').then(res => res.json()),
      fetch('/api/products?todayDeal=true').then(res => res.json()),
      fetch('/api/products?featured=true').then(res => res.json()),
      fetch('/api/blogs').then(res => res.json())
    ])
      .then(([catData, bestData, dealsData, featData, blogData]) => {
        setCategories(catData || []);
        setBestSellers(bestData.products || []);
        setTodayDeals(dealsData.products || []);
        setFeaturedProducts(featData.products || []);
        setBlogs(blogData || []);
      })
      .catch(err => console.error(err))
      .finally(() => setIsLoading(false));
  }, []);

  return (
    <div className="space-y-12 pb-16">
      {/* Hero Banner Slider */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-2">
        <HeroSlider />
      </div>

      {/* Featured Categories */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <CategoryGrid categories={categories} />
      </div>

      {/* Today's Special Deals Banner & Grid */}
      {todayDeals.length > 0 && (
        <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 bg-gradient-to-br from-amber-50 to-orange-50 dark:from-slate-800/80 dark:to-slate-900 rounded-3xl border border-amber-200/60 dark:border-slate-800 p-6 sm:p-8">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between mb-8 gap-4">
            <div>
              <div className="inline-flex items-center gap-1.5 bg-amber-500 text-slate-900 font-extrabold text-xs px-3 py-1 rounded-full mb-2">
                <Flame size={14} className="fill-slate-900" /> Flash Sale
              </div>
              <h2 className="text-2xl sm:text-3xl font-black text-slate-900 dark:text-white">
                Today's Organic Organic Deals
              </h2>
              <p className="text-xs text-slate-600 dark:text-slate-400 mt-1">
                Fresh daily discounts on pure Sundarban honey, Kalijira rice & Ghani oil.
              </p>
            </div>

            <Link
              to="/offers"
              className="px-5 py-2.5 bg-amber-500 hover:bg-amber-600 text-slate-950 font-extrabold text-xs rounded-xl flex items-center gap-2 transition-colors shadow-md shadow-amber-500/20"
            >
              <span>View All Offers</span>
              <ArrowRight size={14} />
            </Link>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {todayDeals.map(p => (
              <ProductCard key={p.id} product={p} />
            ))}
          </div>
        </section>
      )}

      {/* Best Sellers Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-end justify-between mb-8">
          <div>
            <span className="text-xs font-bold text-emerald-600 dark:text-emerald-400 uppercase tracking-wider">
              Most Popular Items
            </span>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white mt-1">
              Top Rated Best Sellers
            </h2>
          </div>
          <Link
            to="/shop"
            className="text-xs font-bold text-emerald-600 dark:text-emerald-400 hover:underline flex items-center gap-1"
          >
            Explore Shop →
          </Link>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
          {bestSellers.map(p => (
            <ProductCard key={p.id} product={p} />
          ))}
        </div>
      </section>

      {/* Promotional Callout Banner */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="relative rounded-3xl overflow-hidden bg-gradient-to-r from-emerald-900 via-emerald-800 to-teal-900 text-white p-8 sm:p-12 shadow-2xl flex flex-col md:flex-row items-center justify-between gap-8 border border-emerald-700/50">
          <div className="space-y-3 max-w-xl">
            <span className="bg-lime-400 text-slate-900 text-xs font-extrabold px-3 py-1 rounded-full uppercase">
              Free Express Delivery
            </span>
            <h3 className="text-2xl sm:text-4xl font-black leading-tight">
              Get Free Shipping in Dhaka on Orders Over ৳1,500!
            </h3>
            <p className="text-xs sm:text-sm text-emerald-100 leading-relaxed">
              Experience authentic taste and uncompromised health. Use coupon code <strong className="text-lime-300 font-mono bg-emerald-950 px-2 py-0.5 rounded border border-lime-400">ORGANIC20</strong> for an extra 20% discount.
            </p>
          </div>

          <Link
            to="/shop"
            className="px-8 py-4 bg-lime-400 hover:bg-lime-300 text-slate-950 font-black text-xs sm:text-sm rounded-2xl transition-transform hover:scale-105 shadow-xl flex items-center gap-2 flex-shrink-0"
          >
            <span>Order Organic Now</span>
            <ArrowRight size={16} />
          </Link>
        </div>
      </section>

      {/* Why Choose Us */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <WhyChooseUs />
      </div>

      {/* Customer Testimonials */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <Testimonials />
      </div>

      {/* Organic Health Blog Highlights */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-end justify-between mb-8">
          <div>
            <span className="text-xs font-bold text-emerald-600 dark:text-emerald-400 uppercase tracking-wider">
              Health & Wellness
            </span>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white mt-1">
              Latest Organic Articles
            </h2>
          </div>
          <Link
            to="/blog"
            className="text-xs font-bold text-emerald-600 dark:text-emerald-400 hover:underline"
          >
            Read All Articles →
          </Link>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {blogs.map(blog => (
            <Link
              key={blog.id}
              to={`/blog/${blog.slug}`}
              className="group rounded-3xl overflow-hidden bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-800 shadow-sm hover:shadow-xl transition-all flex flex-col"
            >
              <div className="aspect-video overflow-hidden">
                <img
                  src={blog.image}
                  alt={blog.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
              </div>
              <div className="p-5 flex-1 flex flex-col justify-between">
                <div>
                  <div className="flex items-center gap-2 text-[10px] font-bold text-emerald-600 uppercase mb-2">
                    <span>{blog.category}</span>
                    <span>•</span>
                    <span>{blog.readTime}</span>
                  </div>
                  <h3 className="text-sm font-bold text-slate-900 dark:text-white group-hover:text-emerald-600 transition-colors line-clamp-2 mb-2">
                    {blog.title}
                  </h3>
                  <p className="text-xs text-slate-500 dark:text-slate-400 line-clamp-3">
                    {blog.excerpt}
                  </p>
                </div>

                <span className="text-xs font-bold text-emerald-600 dark:text-emerald-400 mt-4 flex items-center gap-1">
                  Read Article <ArrowRight size={14} />
                </span>
              </div>
            </Link>
          ))}
        </div>
      </section>

      {/* Instagram Gallery */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <InstagramGallery />
      </div>

      {/* FAQ Section */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <FaqSection />
      </div>
    </div>
  );
};
