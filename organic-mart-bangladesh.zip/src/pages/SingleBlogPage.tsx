import React, { useEffect, useState } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { Calendar, User, Clock, ArrowLeft, Share2, Edit2, Trash2, X, Sparkles, ShieldCheck } from 'lucide-react';
import { BlogPost } from '../types';
import { useAuth } from '../context/AuthContext';

export const SingleBlogPage: React.FC = () => {
  const { slug } = useParams<{ slug: string }>();
  const navigate = useNavigate();
  const { isAdmin, token } = useAuth();
  const [blog, setBlog] = useState<BlogPost | null>(null);
  const [editingBlog, setEditingBlog] = useState<Partial<BlogPost> | null>(null);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3000);
  };

  const fetchSingleBlog = () => {
    fetch(`/api/blogs/${slug}`)
      .then(res => res.json())
      .then(data => {
        if (data && !data.error) {
          setBlog(data);
        } else {
          setBlog(null);
        }
      })
      .catch(err => console.error(err));
  };

  useEffect(() => {
    fetchSingleBlog();
  }, [slug]);

  const handleOpenEdit = () => {
    if (!blog) return;
    setEditingBlog(blog);
    setIsEditModalOpen(true);
  };

  const handleDelete = async () => {
    if (!blog) return;
    if (!window.confirm('আপনি কি এই ব্লগটি স্থায়ীভাবে ডিলিট করতে চান? (Are you sure you want to delete this blog post?)')) return;

    try {
      const res = await fetch(`/api/admin/blogs/${blog.id}`, {
        method: 'DELETE',
        headers: { Authorization: `Bearer ${token}` }
      });

      if (res.ok) {
        alert('ব্লগ সফলভাবে মুছে ফেলা হয়েছে! (Blog deleted successfully)');
        navigate('/blog');
      } else {
        alert('Failed to delete blog.');
      }
    } catch (err) {
      alert('Error deleting blog.');
    }
  };

  const handleSaveBlog = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!blog || !editingBlog?.title || !editingBlog?.content) return;

    try {
      const res = await fetch(`/api/admin/blogs/${blog.id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify(editingBlog)
      });

      if (res.ok) {
        const updated = await res.json();
        setBlog(updated);
        setIsEditModalOpen(false);
        showToast('ব্লগ আপডেট সম্পন্ন হয়েছে! (Blog updated successfully)');
      } else {
        alert('Failed to update blog.');
      }
    } catch (err) {
      alert('Error saving blog.');
    }
  };

  if (!blog) {
    return (
      <div className="max-w-3xl mx-auto px-4 py-16 text-center space-y-4">
        <p className="text-sm font-bold text-slate-500">Loading blog article...</p>
        <Link to="/blog" className="text-xs font-bold text-emerald-600 hover:underline">
          Return to Blog List
        </Link>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8">
      {toastMessage && (
        <div className="fixed top-20 right-4 z-50 bg-emerald-950 text-white px-4 py-3 rounded-2xl shadow-2xl border border-emerald-500 font-bold text-xs flex items-center gap-2 animate-bounce">
          <Sparkles size={16} className="text-lime-400" />
          {toastMessage}
        </div>
      )}

      <div className="flex items-center justify-between">
        <Link
          to="/blog"
          className="inline-flex items-center gap-1.5 text-xs font-bold text-emerald-600 dark:text-emerald-400 hover:underline"
        >
          <ArrowLeft size={16} /> Back to Blog List
        </Link>

        {isAdmin && (
          <div className="flex items-center gap-2">
            <span className="text-[10px] bg-amber-100 text-amber-900 font-black px-2 py-1 rounded-lg flex items-center gap-1">
              <ShieldCheck size={12} /> Admin Controls
            </span>
            <button
              onClick={handleOpenEdit}
              className="px-3 py-1.5 bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold rounded-xl text-xs flex items-center gap-1.5 shadow transition-transform hover:scale-105"
            >
              <Edit2 size={14} /> এডিট (Edit)
            </button>
            <button
              onClick={handleDelete}
              className="px-3 py-1.5 bg-red-600 hover:bg-red-700 text-white font-bold rounded-xl text-xs flex items-center gap-1.5 shadow transition-transform hover:scale-105"
            >
              <Trash2 size={14} /> ডিলিট (Delete)
            </button>
          </div>
        )}
      </div>

      <div className="space-y-4">
        <div className="flex items-center gap-3 text-xs font-bold text-emerald-600 uppercase">
          <span className="bg-emerald-50 dark:bg-emerald-950 px-3 py-1 rounded-full">{blog.category}</span>
          <span className="text-slate-400 flex items-center gap-1"><Clock size={12} /> {blog.readTime}</span>
          <span className="text-slate-400 flex items-center gap-1"><Calendar size={12} /> {blog.date}</span>
        </div>

        <h1 className="text-2xl sm:text-4xl font-extrabold text-slate-900 dark:text-white leading-tight">
          {blog.title}
        </h1>

        <div className="flex items-center justify-between pb-6 border-b border-slate-200 dark:border-slate-800 text-xs text-slate-500">
          <span className="flex items-center gap-1.5 font-bold text-slate-800 dark:text-slate-200">
            <User size={14} className="text-emerald-600" /> By {blog.author}
          </span>
          <button
            onClick={() => {
              navigator.clipboard.writeText(window.location.href);
              showToast('Article link copied to clipboard!');
            }}
            className="flex items-center gap-1 text-emerald-600 font-bold hover:underline"
          >
            <Share2 size={14} /> Share Article
          </button>
        </div>
      </div>

      <div className="aspect-video rounded-3xl overflow-hidden shadow-xl border border-slate-200 dark:border-slate-800">
        <img src={blog.image} alt={blog.title} className="w-full h-full object-cover" />
      </div>

      <div className="prose dark:prose-invert max-w-none text-slate-700 dark:text-slate-300 text-sm leading-relaxed space-y-4">
        <p className="text-base font-semibold text-slate-900 dark:text-slate-100 italic bg-emerald-50 dark:bg-slate-800 p-4 rounded-2xl border-l-4 border-emerald-500">
          {blog.excerpt}
        </p>

        <div className="whitespace-pre-line">
          {blog.content}
        </div>
      </div>

      <div className="p-8 bg-emerald-950 text-white rounded-3xl border border-emerald-800 space-y-3">
        <h3 className="text-lg font-bold">Experience Pure Organic Taste Today</h3>
        <p className="text-xs text-emerald-200">
          Order 100% natural Sundarban honey, unpolished red rice & Ghani mustard oil delivered express to your home.
        </p>
        <Link
          to="/shop"
          className="inline-block px-6 py-2.5 bg-lime-400 hover:bg-lime-300 text-slate-950 font-extrabold text-xs rounded-xl shadow"
        >
          Explore Organic Shop
        </Link>
      </div>

      {/* Edit Blog Modal */}
      {isEditModalOpen && editingBlog && (
        <div className="fixed inset-0 z-50 bg-slate-900/70 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl max-w-2xl w-full p-6 sm:p-8 space-y-6 shadow-2xl my-8">
            <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-4">
              <h2 className="text-lg font-black text-slate-900 dark:text-white flex items-center gap-2">
                <Edit2 className="text-emerald-600" size={20} />
                ব্লগ পোস্ট এডিট করুন (Edit Blog Post)
              </h2>
              <button
                onClick={() => setIsEditModalOpen(false)}
                className="p-2 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-full text-slate-400"
              >
                <X size={20} />
              </button>
            </div>

            <form onSubmit={handleSaveBlog} className="space-y-4 text-xs font-semibold">
              <div>
                <label className="block text-slate-700 dark:text-slate-300 font-bold mb-1">
                  ব্লগ শিরোনাম (Blog Title) *
                </label>
                <input
                  type="text"
                  required
                  value={editingBlog.title || ''}
                  onChange={e => setEditingBlog({ ...editingBlog, title: e.target.value })}
                  className="w-full px-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white outline-none focus:border-emerald-500 font-bold"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-slate-700 dark:text-slate-300 font-bold mb-1">
                    ক্যাটাগরি (Category)
                  </label>
                  <input
                    type="text"
                    value={editingBlog.category || 'Organic Living'}
                    onChange={e => setEditingBlog({ ...editingBlog, category: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white outline-none"
                  />
                </div>

                <div>
                  <label className="block text-slate-700 dark:text-slate-300 font-bold mb-1">
                    লেখক (Author)
                  </label>
                  <input
                    type="text"
                    value={editingBlog.author || 'Admin Kashem'}
                    onChange={e => setEditingBlog({ ...editingBlog, author: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white outline-none"
                  />
                </div>

                <div>
                  <label className="block text-slate-700 dark:text-slate-300 font-bold mb-1">
                    পড়ার সময় (Read Time)
                  </label>
                  <input
                    type="text"
                    value={editingBlog.readTime || '3 min read'}
                    onChange={e => setEditingBlog({ ...editingBlog, readTime: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-700 dark:text-slate-300 font-bold mb-1">
                  ছবি URL (Cover Image URL)
                </label>
                <input
                  type="text"
                  value={editingBlog.image || ''}
                  onChange={e => setEditingBlog({ ...editingBlog, image: e.target.value })}
                  className="w-full px-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white outline-none font-mono text-[11px]"
                />
              </div>

              <div>
                <label className="block text-slate-700 dark:text-slate-300 font-bold mb-1">
                  সংক্ষিপ্ত অংশ (Excerpt)
                </label>
                <textarea
                  rows={2}
                  value={editingBlog.excerpt || ''}
                  onChange={e => setEditingBlog({ ...editingBlog, excerpt: e.target.value })}
                  className="w-full px-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white outline-none"
                />
              </div>

              <div>
                <label className="block text-slate-700 dark:text-slate-300 font-bold mb-1">
                  মূল বিস্তারিত কনটেন্ট (Full Content) *
                </label>
                <textarea
                  rows={7}
                  required
                  value={editingBlog.content || ''}
                  onChange={e => setEditingBlog({ ...editingBlog, content: e.target.value })}
                  className="w-full px-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white outline-none font-sans"
                />
              </div>

              <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-200 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsEditModalOpen(false)}
                  className="px-5 py-2.5 bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-bold rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-6 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold rounded-xl shadow-lg shadow-emerald-600/20"
                >
                  Save Changes
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
