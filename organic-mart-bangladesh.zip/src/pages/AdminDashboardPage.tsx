import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  TrendingUp,
  ShoppingBag,
  Package,
  Users,
  Plus,
  Edit2,
  Trash2,
  CheckCircle2,
  Clock,
  AlertTriangle,
  Lock,
  Tag,
  Mail,
  RefreshCw,
  Search,
  ChevronDown,
  Eye,
  X,
  XCircle,
  Check,
  Filter,
  Sparkles,
  Phone,
  MapPin,
  DollarSign,
  ArrowRight,
  ShieldCheck,
  Calendar,
  LogOut,
  Truck,
  Settings,
  Printer,
  LayoutGrid,
  Leaf,
  Apple,
  Droplet,
  Sprout,
  Flame,
  Coffee,
  Sun,
  Heart,
  Egg,
  Wheat,
  Fish,
  Cookie,
  Box,
  Store,
  Utensils,
  Gift,
  Carrot,
  Beef,
  Milk
} from 'lucide-react';

import { FileText } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { Product, Order, Category, Coupon, OrderStatus, ContactMessage, StoreSettings, BlogPost } from '../types';
import { A5InvoiceModal } from '../components/common/A5InvoiceModal';

export const renderCategoryIcon = (iconName?: string, size: number = 16, className: string = 'text-emerald-600') => {
  switch (iconName) {
    case 'Leaf': return <Leaf size={size} className={className} />;
    case 'Apple': return <Apple size={size} className={className} />;
    case 'Droplet': return <Droplet size={size} className={className} />;
    case 'Sprout': return <Sprout size={size} className={className} />;
    case 'Flame': return <Flame size={size} className={className} />;
    case 'Coffee': return <Coffee size={size} className={className} />;
    case 'Sun': return <Sun size={size} className={className} />;
    case 'Heart': return <Heart size={size} className={className} />;
    case 'Egg': return <Egg size={size} className={className} />;
    case 'Wheat': return <Wheat size={size} className={className} />;
    case 'Fish': return <Fish size={size} className={className} />;
    case 'Cookie': return <Cookie size={size} className={className} />;
    case 'Sparkles': return <Sparkles size={size} className={className} />;
    case 'ShoppingBag': return <ShoppingBag size={size} className={className} />;
    case 'Box': return <Box size={size} className={className} />;
    case 'Store': return <Store size={size} className={className} />;
    case 'Utensils': return <Utensils size={size} className={className} />;
    case 'Gift': return <Gift size={size} className={className} />;
    case 'Carrot': return <Carrot size={size} className={className} />;
    case 'Beef': return <Beef size={size} className={className} />;
    case 'Milk': return <Milk size={size} className={className} />;
    case 'Package': default: return <Package size={size} className={className} />;
  }
};

export const AdminDashboardPage: React.FC = () => {
  const { user, token, login, logout } = useAuth();
  const navigate = useNavigate();

  // Admin Login Form State
  const [adminPhone, setAdminPhone] = useState('KASHEM');
  const [adminPassword, setAdminPassword] = useState('123456');
  const [loginError, setLoginError] = useState('');
  const [isLoggingIn, setIsLoggingIn] = useState(false);

  // Active Tab
  const [activeTab, setActiveTab] = useState<'overview' | 'orders' | 'products' | 'categories' | 'coupons' | 'settings' | 'messages' | 'blogs'>('overview');

  // Core Data States
  const [analytics, setAnalytics] = useState<any>(null);
  const [orders, setOrders] = useState<Order[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [coupons, setCoupons] = useState<Coupon[]>([]);
  const [messages, setMessages] = useState<ContactMessage[]>([]);
  const [blogs, setBlogs] = useState<BlogPost[]>([]);
  const [isLoading, setIsLoading] = useState(false);

  // Category Management States
  const [editingCategory, setEditingCategory] = useState<Partial<Category> | null>(null);
  const [isCategoryModalOpen, setIsCategoryModalOpen] = useState(false);
  const [categorySearch, setCategorySearch] = useState('');

  // Blog Management States
  const [editingBlog, setEditingBlog] = useState<Partial<BlogPost> | null>(null);
  const [isBlogModalOpen, setIsBlogModalOpen] = useState(false);
  const [blogSearch, setBlogSearch] = useState('');

  // Store Settings (Delivery Charges)
  const [storeSettings, setStoreSettings] = useState<StoreSettings>({
    insideDhakaFee: 70,
    outsideDhakaFee: 120,
    freeShippingMin: 1500
  });
  const [insideFeeInput, setInsideFeeInput] = useState<number>(70);
  const [outsideFeeInput, setOutsideFeeInput] = useState<number>(120);
  const [freeShippingMinInput, setFreeShippingMinInput] = useState<number>(1500);
  const [isSavingSettings, setIsSavingSettings] = useState(false);

  // Filters
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [orderSearch, setOrderSearch] = useState<string>('');
  const [productSearch, setProductSearch] = useState<string>('');
  const [categoryFilter, setCategoryFilter] = useState<string>('all');

  // Modals
  const [editingProduct, setEditingProduct] = useState<Partial<Product> | null>(null);
  const [isProductModalOpen, setIsProductModalOpen] = useState(false);
  const [selectedOrderDetails, setSelectedOrderDetails] = useState<Order | null>(null);
  const [invoiceOrder, setInvoiceOrder] = useState<Order | null>(null);

  // New Coupon Form
  const [newCouponCode, setNewCouponCode] = useState('');
  const [newCouponVal, setNewCouponVal] = useState<number>(10);
  const [newCouponType, setNewCouponType] = useState<'percent' | 'fixed'>('percent');
  const [newCouponMin, setNewCouponMin] = useState<number>(500);

  // Alert/Toast feedback
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3000);
  };

  const isAdmin = user?.role === 'admin' || user?.name === 'KASHEM';

  const fetchAdminData = () => {
    setIsLoading(true);
    const headers = token ? { Authorization: `Bearer ${token}` } : {};

    Promise.all([
      fetch('/api/admin/analytics', { headers }).then(r => r.ok ? r.json() : null),
      fetch('/api/orders', { headers }).then(r => r.ok ? r.json() : []),
      fetch('/api/products?limit=200').then(r => r.ok ? r.json() : { products: [] }),
      fetch('/api/categories').then(r => r.ok ? r.json() : []),
      fetch('/api/coupons', { headers }).then(r => r.ok ? r.json() : []),
      fetch('/api/admin/messages', { headers }).then(r => r.ok ? r.json() : []),
      fetch('/api/settings').then(r => r.ok ? r.json() : null),
      fetch('/api/blogs').then(r => r.ok ? r.json() : [])
    ])
      .then(([analyticsData, ordersData, productsData, catData, couponData, msgData, settingsData, blogsData]) => {
        const orderList: Order[] = Array.isArray(ordersData) ? ordersData : [];
        const productList: Product[] = Array.isArray(productsData?.products) 
          ? productsData.products 
          : Array.isArray(productsData) ? productsData : [];

        if (analyticsData && !analyticsData.error) {
          setAnalytics(analyticsData);
        } else {
          const valOrders = orderList.filter(o => o.status?.toLowerCase() !== 'cancelled');
          const cancOrders = orderList.filter(o => o.status?.toLowerCase() === 'cancelled');
          const custSet = new Set<string>();
          orderList.forEach(o => {
            if (o.customerEmail && o.customerEmail.trim()) custSet.add(o.customerEmail.toLowerCase().trim());
            else if (o.customerPhone && o.customerPhone.trim()) custSet.add(o.customerPhone.trim());
            else if (o.userId) custSet.add(o.userId);
          });

          setAnalytics({
            todaySales: 15400,
            monthlySales: 345000,
            totalOrders: orderList.length,
            validOrdersCount: valOrders.length,
            cancelledOrdersCount: cancOrders.length,
            cancelledRevenue: cancOrders.reduce((s, o) => s + (o.grandTotal || 0), 0),
            totalRevenue: valOrders.reduce((s, o) => s + (o.grandTotal || 0), 0),
            pendingOrders: orderList.filter(o => o.status === 'Pending').length,
            totalVisitors: 14250,
            activeProducts: productList.length,
            totalCustomers: custSet.size,
            recentOrders: orderList.slice(0, 5)
          });
        }

        setOrders(orderList);
        setProducts(productList);
        setCategories(Array.isArray(catData) ? catData : []);
        setCoupons(Array.isArray(couponData) ? couponData : []);
        setMessages(Array.isArray(msgData) ? msgData : []);
        setBlogs(Array.isArray(blogsData) ? blogsData : []);

        if (settingsData && typeof settingsData.insideDhakaFee === 'number') {
          setStoreSettings(settingsData);
          setInsideFeeInput(settingsData.insideDhakaFee);
          setOutsideFeeInput(settingsData.outsideDhakaFee);
          setFreeShippingMinInput(settingsData.freeShippingMin ?? 1500);
        }
      })
      .catch(err => {
        console.error('Error fetching admin data:', err);
      })
      .finally(() => setIsLoading(false));
  };

  const handleSaveBlog = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingBlog?.title || !editingBlog?.content) {
      alert('Title and Content are required.');
      return;
    }

    const isEdit = !!editingBlog.id;
    const url = isEdit ? `/api/admin/blogs/${editingBlog.id}` : '/api/admin/blogs';
    const method = isEdit ? 'PUT' : 'POST';

    try {
      const res = await fetch(url, {
        method,
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify(editingBlog)
      });

      if (res.ok) {
        showToast(isEdit ? 'Blog post updated successfully!' : 'New blog article published!');
        setIsBlogModalOpen(false);
        setEditingBlog(null);
        fetchAdminData();
      } else {
        alert('Failed to save blog post.');
      }
    } catch (err) {
      alert('Error saving blog post.');
    }
  };

  const handleDeleteBlog = async (id: string) => {
    if (!window.confirm('Are you sure you want to delete this blog post?')) return;

    try {
      const res = await fetch(`/api/admin/blogs/${id}`, {
        method: 'DELETE',
        headers: { Authorization: `Bearer ${token}` }
      });

      if (res.ok) {
        showToast('Blog post deleted.');
        fetchAdminData();
      } else {
        alert('Failed to delete blog post.');
      }
    } catch (err) {
      alert('Error deleting blog post.');
    }
  };

  const handleSaveCategory = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingCategory?.name) {
      alert('Category Name (English) is required.');
      return;
    }

    const isEdit = !!(editingCategory as any)._originalId;
    const originalId = (editingCategory as any)._originalId || editingCategory.id;
    const url = isEdit ? `/api/categories/${originalId}` : '/api/categories';
    const method = isEdit ? 'PUT' : 'POST';

    try {
      const res = await fetch(url, {
        method,
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify({
          ...editingCategory,
          id: editingCategory.id || editingCategory.name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, ''),
          bnName: editingCategory.bnName || editingCategory.name,
          icon: editingCategory.icon || 'Leaf',
          image: editingCategory.image || 'https://images.unsplash.com/photo-1542838132-92c53300491e?auto=format&fit=crop&w=800&q=80',
          description: editingCategory.description || ''
        })
      });

      if (res.ok) {
        showToast(isEdit ? 'ক্যাটাগরি সফলভাবে আপডেট হয়েছে!' : 'নতুন ক্যাটাগরি তৈরি হয়েছে!');
        setIsCategoryModalOpen(false);
        setEditingCategory(null);
        fetchAdminData();
      } else {
        const errData = await res.json().catch(() => ({}));
        alert(errData.error || 'Failed to save category.');
      }
    } catch (err) {
      alert('Error saving category.');
    }
  };

  const handleDeleteCategory = async (id: string, name: string) => {
    if (!window.confirm(`আপনি কি সত্যিই "${name}" ক্যাটাগরি ডিলেট করতে চান?`)) return;

    try {
      const res = await fetch(`/api/categories/${id}`, {
        method: 'DELETE',
        headers: { Authorization: `Bearer ${token}` }
      });

      if (res.ok) {
        showToast('ক্যাটাগরি ডিলেট করা হয়েছে!');
        fetchAdminData();
      } else {
        alert('Failed to delete category.');
      }
    } catch (err) {
      alert('Error deleting category.');
    }
  };

  const handleSaveSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSavingSettings(true);
    try {
      const res = await fetch('/api/admin/settings', {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify({
          insideDhakaFee: Number(insideFeeInput),
          outsideDhakaFee: Number(outsideFeeInput),
          freeShippingMin: Number(freeShippingMinInput)
        })
      });

      if (res.ok) {
        const updated = await res.json();
        setStoreSettings(updated);
        showToast('Delivery charges updated successfully!');
      } else {
        alert('Failed to update settings.');
      }
    } catch (err) {
      alert('Error connecting to server.');
    } finally {
      setIsSavingSettings(false);
    }
  };

  useEffect(() => {
    if (isAdmin) {
      fetchAdminData();
    }
  }, [isAdmin, token]);

  const handleAdminLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError('');
    setIsLoggingIn(true);
    const ok = await login(adminPhone, adminPassword);
    setIsLoggingIn(false);
    if (!ok) {
      setLoginError('Invalid Admin Credentials. Please check ID and Password.');
    } else {
      showToast('Welcome back Admin KASHEM!');
    }
  };

  const handleUpdateOrderStatus = async (orderId: string, status: OrderStatus) => {
    try {
      const res = await fetch(`/api/orders/${orderId}/status`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify({ status })
      });

      if (res.ok) {
        showToast(`Order ${orderId} status updated to ${status}`);
        fetchAdminData();
      } else {
        alert('Failed to update status.');
      }
    } catch (err) {
      alert('Network error while updating status.');
    }
  };

  const handleSaveProduct = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingProduct?.name || !editingProduct?.price || !editingProduct?.categoryName) {
      alert('Please enter Product Name, Category, and Price.');
      return;
    }

    const cleanBenefits = editingProduct.benefits
      ? editingProduct.benefits.map(b => b.trim()).filter(Boolean)
      : [];

    const cleanNutrition: Record<string, string> = {};
    if (editingProduct.nutrition) {
      Object.entries(editingProduct.nutrition).forEach(([k, v]) => {
        if (k && k.trim()) {
          cleanNutrition[k.trim()] = v ? String(v).trim() : '';
        }
      });
    }

    const payload = {
      ...editingProduct,
      sku: editingProduct.sku || `OMB-${Math.floor(1000 + Math.random() * 9000)}`,
      categoryId: categories.find(c => c.name === editingProduct.categoryName)?.id || 'vegetables',
      benefits: cleanBenefits,
      nutrition: cleanNutrition,
      images: editingProduct.images && editingProduct.images.length > 0 && editingProduct.images[0].trim() !== ''
        ? editingProduct.images
        : ['https://images.unsplash.com/photo-1587049352846-4a222e784d38?w=800&auto=format&fit=crop&q=80'],
      rating: editingProduct.rating || 5.0,
      reviewCount: editingProduct.reviewCount || 12
    };

    const isEdit = !!editingProduct.id;
    const url = isEdit ? `/api/products/${editingProduct.id}` : '/api/products';
    const method = isEdit ? 'PUT' : 'POST';

    try {
      const res = await fetch(url, {
        method,
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify(payload)
      });

      if (res.ok) {
        showToast(isEdit ? 'Product updated successfully!' : 'New organic product added!');
        setIsProductModalOpen(false);
        setEditingProduct(null);
        fetchAdminData();
      } else {
        alert('Failed to save product.');
      }
    } catch (err) {
      alert('Error saving product.');
    }
  };

  const handleDeleteProduct = async (id: string) => {
    if (!window.confirm('Are you sure you want to delete this product?')) return;

    try {
      const res = await fetch(`/api/products/${id}`, {
        method: 'DELETE',
        headers: { Authorization: `Bearer ${token}` }
      });

      if (res.ok) {
        showToast('Product deleted.');
        fetchAdminData();
      } else {
        alert('Failed to delete product.');
      }
    } catch (err) {
      alert('Error deleting product.');
    }
  };

  const handleCreateCoupon = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCouponCode) return;

    try {
      const res = await fetch('/api/coupons', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify({
          code: newCouponCode.toUpperCase().trim(),
          discountType: newCouponType,
          discountValue: Number(newCouponVal),
          minSpend: Number(newCouponMin),
          expiryDate: '2026-12-31'
        })
      });

      if (res.ok) {
        showToast(`Promo Coupon ${newCouponCode.toUpperCase()} created!`);
        setNewCouponCode('');
        fetchAdminData();
      } else {
        alert('Failed to create coupon.');
      }
    } catch (err) {
      alert('Failed to create coupon.');
    }
  };

  const handleDeleteCoupon = async (codeOrId: string) => {
    if (!window.confirm('Are you sure you want to delete this promo coupon?')) return;

    try {
      const res = await fetch(`/api/coupons/${codeOrId}`, {
        method: 'DELETE',
        headers: { Authorization: `Bearer ${token}` }
      });

      if (res.ok) {
        showToast('Coupon deleted.');
        fetchAdminData();
      }
    } catch (err) {
      alert('Error deleting coupon.');
    }
  };

  const handleDeleteMessage = async (id: string) => {
    if (!window.confirm('Delete this contact inquiry?')) return;

    try {
      const res = await fetch(`/api/admin/messages/${id}`, {
        method: 'DELETE',
        headers: { Authorization: `Bearer ${token}` }
      });

      if (res.ok) {
        showToast('Message deleted.');
        fetchAdminData();
      }
    } catch (err) {
      alert('Error deleting message.');
    }
  };

  // If NOT logged in as admin/KASHEM, render Login Card
  if (!isAdmin) {
    return (
      <div className="max-w-md mx-auto px-4 py-16 space-y-6">
        <div className="text-center">
          <div className="w-16 h-16 bg-emerald-100 dark:bg-emerald-950 text-emerald-600 rounded-2xl flex items-center justify-center mx-auto mb-3 shadow-inner">
            <Lock size={32} />
          </div>
          <h1 className="text-2xl font-black text-slate-900 dark:text-white">Admin Management Portal</h1>
          <p className="text-xs text-slate-500 mt-1">Authorized Store Control Center for Organic Mart BD</p>
        </div>

        <div className="bg-white dark:bg-slate-800 p-8 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-xl space-y-4">
          {loginError && (
            <div className="p-3 bg-red-50 text-red-600 font-bold text-xs rounded-xl text-center border border-red-200">
              {loginError}
            </div>
          )}

          <div className="p-3 bg-amber-50 dark:bg-amber-950/40 text-amber-800 dark:text-amber-300 rounded-xl text-xs space-y-1 border border-amber-200 dark:border-amber-900">
            <p className="font-bold flex items-center gap-1.5"><ShieldCheck size={14} /> Quick Admin Credentials:</p>
            <p className="font-mono text-[11px]">User ID: <strong className="text-emerald-700 dark:text-emerald-400">KASHEM</strong></p>
            <p className="font-mono text-[11px]">Password: <strong className="text-emerald-700 dark:text-emerald-400">123456</strong></p>
          </div>

          <form onSubmit={handleAdminLogin} className="space-y-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                Admin User ID / Mobile Phone
              </label>
              <input
                type="text"
                value={adminPhone}
                onChange={e => setAdminPhone(e.target.value)}
                required
                className="w-full px-4 py-2.5 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-slate-900 dark:text-white font-mono font-bold outline-none focus:border-emerald-500"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                Admin Security Password
              </label>
              <input
                type="password"
                value={adminPassword}
                onChange={e => setAdminPassword(e.target.value)}
                required
                className="w-full px-4 py-2.5 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-slate-900 dark:text-white font-mono font-bold outline-none focus:border-emerald-500"
              />
            </div>

            <button
              type="submit"
              disabled={isLoggingIn}
              className="w-full py-3.5 bg-emerald-600 hover:bg-emerald-700 text-white font-black text-xs rounded-xl transition-all shadow-lg shadow-emerald-600/20 flex items-center justify-center gap-2"
            >
              <Lock size={16} />
              {isLoggingIn ? 'Authenticating...' : 'Access Admin Dashboard'}
            </button>
          </form>
        </div>
      </div>
    );
  }

  // Filter logic
  const filteredOrders = orders.filter(o => {
    const matchesStatus = statusFilter === 'all' || o.status.toLowerCase() === statusFilter.toLowerCase();
    const q = orderSearch.toLowerCase().trim();
    const matchesSearch = !q || 
      o.id.toLowerCase().includes(q) || 
      o.customerName.toLowerCase().includes(q) || 
      o.customerPhone.includes(q);
    return matchesStatus && matchesSearch;
  });

  const filteredProducts = products.filter(p => {
    const matchesCat = categoryFilter === 'all' || p.categoryName === categoryFilter || p.categoryId === categoryFilter;
    const q = productSearch.toLowerCase().trim();
    const matchesSearch = !q || p.name.toLowerCase().includes(q) || (p.bnName && p.bnName.includes(q));
    return matchesCat && matchesSearch;
  });

  const pendingCount = orders.filter(o => o.status === 'Pending').length;

  const validOrders = orders.filter(o => o.status?.toLowerCase() !== 'cancelled');
  const cancelledOrders = orders.filter(o => o.status?.toLowerCase() === 'cancelled');
  const cancelledCount = analytics?.cancelledOrdersCount ?? cancelledOrders.length;
  const cancelledRevenueAmount = analytics?.cancelledRevenue ?? cancelledOrders.reduce((s, o) => s + (o.grandTotal || 0), 0);
  const totalValidRevenue = analytics?.totalRevenue ?? validOrders.reduce((s, o) => s + (o.grandTotal || 0), 0);

  // Live Unique Customers Calculation
  const liveCustomerSet = new Set<string>();
  orders.forEach(o => {
    if (o.customerEmail && o.customerEmail.trim()) {
      liveCustomerSet.add(o.customerEmail.toLowerCase().trim());
    } else if (o.customerPhone && o.customerPhone.trim()) {
      liveCustomerSet.add(o.customerPhone.trim());
    } else if (o.userId) {
      liveCustomerSet.add(o.userId);
    }
  });

  const liveTotalCustomers = analytics?.totalCustomers !== undefined
    ? Math.max(analytics.totalCustomers, liveCustomerSet.size)
    : liveCustomerSet.size;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Toast Popup */}
      {toastMessage && (
        <div className="fixed top-20 right-4 z-50 bg-emerald-900 text-white px-4 py-3 rounded-2xl shadow-2xl border border-emerald-500 font-bold text-xs flex items-center gap-2 animate-bounce">
          <Sparkles size={16} className="text-lime-400" />
          {toastMessage}
        </div>
      )}

      {/* Admin Top Header Banner */}
      <div className="bg-gradient-to-r from-emerald-950 via-slate-900 to-emerald-900 rounded-3xl p-6 sm:p-8 text-white shadow-2xl flex flex-col md:flex-row items-start md:items-center justify-between gap-6 border border-emerald-800">
        <div>
          <div className="flex items-center gap-2">
            <span className="bg-lime-400 text-slate-950 text-[10px] font-black px-2.5 py-0.5 rounded uppercase tracking-wider">
              System Admin Active
            </span>
            <span className="bg-emerald-900 text-emerald-300 text-[10px] font-bold px-2 py-0.5 rounded border border-emerald-700 flex items-center gap-1">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping"></span> Live Database
            </span>
          </div>

          <h1 className="text-2xl sm:text-3xl font-extrabold mt-2 flex items-center gap-2">
            Organic Mart BD Control Center
          </h1>

          <p className="text-xs text-emerald-200 mt-1">
            Logged in as <strong className="text-white font-black">{user.name}</strong> • Store Management, Inventory, Orders & Marketing
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={fetchAdminData}
            disabled={isLoading}
            className="px-4 py-2.5 bg-emerald-800 hover:bg-emerald-700 text-emerald-100 font-bold text-xs rounded-xl flex items-center gap-2 transition-colors border border-emerald-600 shadow"
          >
            <RefreshCw size={14} className={isLoading ? 'animate-spin' : ''} />
            Refresh Data
          </button>

          <button
            onClick={logout}
            className="px-4 py-2.5 bg-red-900/60 hover:bg-red-800 text-red-200 font-bold text-xs rounded-xl flex items-center gap-2 transition-colors border border-red-700"
          >
            <LogOut size={14} /> Exit
          </button>
        </div>
      </div>

      {/* Tabs Toolbar */}
      <div className="flex flex-wrap border-b border-slate-200 dark:border-slate-800 gap-2 sm:gap-6 text-xs font-bold">
        {[
          { id: 'overview', label: 'Overview Analytics', icon: TrendingUp, badge: null },
          { id: 'orders', label: `Orders (${orders.length})`, icon: ShoppingBag, badge: pendingCount > 0 ? `${pendingCount} Pending` : null },
          { id: 'products', label: `Inventory (${products.length})`, icon: Package, badge: null },
          { id: 'categories', label: `Categories (${categories.length})`, icon: LayoutGrid, badge: 'Edit/Update' },
          { id: 'coupons', label: `Coupons (${coupons.length})`, icon: Tag, badge: null },
          { id: 'settings', label: 'Delivery Charges & Rates', icon: Truck, badge: 'Edit' },
          { id: 'messages', label: `Inquiries (${messages.length})`, icon: Mail, badge: null },
          { id: 'blogs', label: `Blogs (${blogs.length})`, icon: FileText, badge: null }
        ].map(tab => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`pb-3 pt-1 px-3 flex items-center gap-2 transition-all border-b-2 font-bold text-xs ${
                isActive
                  ? 'border-emerald-600 text-emerald-600 dark:text-emerald-400 scale-105'
                  : 'border-transparent text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
              }`}
            >
              <Icon size={16} />
              <span>{tab.label}</span>
              {tab.badge && (
                <span className="px-2 py-0.5 bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300 text-[10px] rounded-full font-black">
                  {tab.badge}
                </span>
              )}
            </button>
          );
        })}
      </div>

      {/* OVERVIEW TAB */}
      {activeTab === 'overview' && (
        <div className="space-y-8">
          {/* Key Metrics Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-5">
            {/* Card 1: Total Sales Revenue */}
            <div className="p-6 rounded-3xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-800 shadow-sm space-y-2 relative overflow-hidden">
              <div className="absolute top-4 right-4 p-2 bg-emerald-50 dark:bg-emerald-950 text-emerald-600 rounded-xl">
                <DollarSign size={20} />
              </div>
              <span className="text-xs text-slate-400 font-bold uppercase tracking-wider">Total Sales Revenue</span>
              <p className="text-2xl font-black text-emerald-600 dark:text-emerald-400">
                ৳{totalValidRevenue.toLocaleString()}
              </p>
              <p className="text-[11px] text-slate-500 font-medium">
                {cancelledCount > 0 ? `(বাতিলকৃত ৳${cancelledRevenueAmount.toLocaleString()} বাদ দেওয়া হয়েছে)` : 'Active non-cancelled revenue'}
              </p>
            </div>

            {/* Card 2: Total Orders */}
            <div className="p-6 rounded-3xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-800 shadow-sm space-y-2 relative overflow-hidden">
              <div className="absolute top-4 right-4 p-2 bg-blue-50 dark:bg-blue-950 text-blue-600 rounded-xl">
                <ShoppingBag size={20} />
              </div>
              <span className="text-xs text-slate-400 font-bold uppercase tracking-wider">Total Orders</span>
              <p className="text-2xl font-black text-slate-900 dark:text-white">
                {orders.length}
              </p>
              <p className="text-[11px] text-amber-500 font-bold">{pendingCount} Pending Processing</p>
            </div>

            {/* Card 3: Cancelled Orders */}
            <div className="p-6 rounded-3xl bg-white dark:bg-slate-800 border border-red-200 dark:border-red-950 shadow-sm space-y-2 relative overflow-hidden">
              <div className="absolute top-4 right-4 p-2 bg-red-50 dark:bg-red-950 text-red-600 dark:text-red-400 rounded-xl">
                <XCircle size={20} />
              </div>
              <span className="text-xs text-red-500 dark:text-red-400 font-bold uppercase tracking-wider">Cancelled Orders</span>
              <p className="text-2xl font-black text-red-600 dark:text-red-400">
                {cancelledCount} <span className="text-xs font-bold text-slate-500">টি বাতিল</span>
              </p>
              <p className="text-[11px] text-red-600 dark:text-red-400 font-bold flex items-center gap-1">
                <span>-৳{cancelledRevenueAmount.toLocaleString()}</span>
                <span className="text-[10px] text-slate-400 font-normal font-sans">(রেভিনিউ থেকে কাটা)</span>
              </p>
            </div>

            {/* Card 4: Active Inventory */}
            <div className="p-6 rounded-3xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-800 shadow-sm space-y-2 relative overflow-hidden">
              <div className="absolute top-4 right-4 p-2 bg-purple-50 dark:bg-purple-950 text-purple-600 rounded-xl">
                <Package size={20} />
              </div>
              <span className="text-xs text-slate-400 font-bold uppercase tracking-wider">Active Inventory</span>
              <p className="text-2xl font-black text-slate-900 dark:text-white">
                {products.length} Items
              </p>
              <p className="text-[11px] text-emerald-600 font-bold">100% Organic Certified</p>
            </div>

            {/* Card 5: Total Customers */}
            <div className="p-6 rounded-3xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-800 shadow-sm space-y-2 relative overflow-hidden">
              <div className="absolute top-4 right-4 p-2 bg-amber-50 dark:bg-amber-950 text-amber-600 rounded-xl">
                <Users size={20} />
              </div>
              <span className="text-xs text-slate-400 font-bold uppercase tracking-wider">Total Customers</span>
              <p className="text-2xl font-black text-slate-900 dark:text-white">
                {liveTotalCustomers} <span className="text-xs font-bold text-slate-500">জন কাস্টমার</span>
              </p>
              <p className="text-[11px] text-emerald-600 dark:text-emerald-400 font-bold flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
                <span>অর্ডার দেওয়া লাইভ কাস্টমার সংখ্যা</span>
              </p>
            </div>
          </div>

          {/* Quick Actions Bar */}
          <div className="p-6 rounded-3xl bg-emerald-50 dark:bg-slate-800/80 border border-emerald-200 dark:border-slate-700 flex flex-wrap items-center justify-between gap-4">
            <div>
              <h3 className="text-sm font-black text-slate-900 dark:text-white">Management Quick Actions</h3>
              <p className="text-xs text-slate-500">Fast tasks for store admin</p>
            </div>
            <div className="flex flex-wrap gap-3">
              <button
                onClick={() => {
                  setEditingProduct({
                    name: '',
                    bnName: '',
                    categoryName: 'Organic Vegetables',
                    price: 250,
                    stock: 50,
                    unit: '1 kg',
                    brand: 'Sundarban Pure',
                    description: '100% organic and fresh Bangladeshi farm product.',
                    images: ['https://images.unsplash.com/photo-1540420773420-3366772f4999?w=800&auto=format&fit=crop&q=80']
                  });
                  setIsProductModalOpen(true);
                }}
                className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-xs rounded-xl flex items-center gap-2 shadow"
              >
                <Plus size={16} /> Add Product
              </button>

              <button
                onClick={() => setActiveTab('orders')}
                className="px-4 py-2 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-200 font-extrabold text-xs rounded-xl flex items-center gap-2"
              >
                <ShoppingBag size={16} /> Manage Orders
              </button>

              <button
                onClick={() => setActiveTab('coupons')}
                className="px-4 py-2 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-200 font-extrabold text-xs rounded-xl flex items-center gap-2"
              >
                <Tag size={16} /> Create Promo Code
              </button>
            </div>
          </div>

          {/* Recent Customer Orders */}
          <div className="bg-white dark:bg-slate-800 p-6 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-base font-bold text-slate-900 dark:text-white">Recent Customer Orders</h3>
              <button
                onClick={() => setActiveTab('orders')}
                className="text-xs font-bold text-emerald-600 hover:underline flex items-center gap-1"
              >
                View All ({orders.length}) <ArrowRight size={14} />
              </button>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs border-collapse">
                <thead>
                  <tr className="border-b border-slate-200 dark:border-slate-700 text-slate-400 font-bold uppercase">
                    <th className="p-3">Order ID</th>
                    <th className="p-3">Customer</th>
                    <th className="p-3">Payment</th>
                    <th className="p-3">Amount</th>
                    <th className="p-3">Status</th>
                    <th className="p-3 text-right">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                  {orders.slice(0, 6).map(o => (
                    <tr key={o.id} className="hover:bg-slate-50 dark:hover:bg-slate-900/50 transition-colors">
                      <td className="p-3 font-mono font-bold text-emerald-600">{o.id}</td>
                      <td className="p-3 font-semibold">
                        {o.customerName}
                        <br />
                        <span className="text-[10px] text-slate-400 font-mono">{o.customerPhone}</span>
                      </td>
                      <td className="p-3 uppercase font-mono font-bold">{o.paymentMethod}</td>
                      <td className="p-3 font-black text-slate-900 dark:text-white">৳{o.grandTotal}</td>
                      <td className="p-3">
                        <select
                          value={o.status}
                          onChange={e => handleUpdateOrderStatus(o.id, e.target.value as OrderStatus)}
                          className="px-2.5 py-1 text-[11px] font-extrabold rounded-lg border border-emerald-500 bg-emerald-50 dark:bg-slate-900 text-emerald-800 dark:text-emerald-300 outline-none cursor-pointer"
                        >
                          <option value="Pending">Pending</option>
                          <option value="Confirmed">Confirmed</option>
                          <option value="Packed">Packed</option>
                          <option value="Shipped">Shipped</option>
                          <option value="Delivered">Delivered</option>
                          <option value="Cancelled">Cancelled</option>
                        </select>
                      </td>
                      <td className="p-3 text-right">
                        <button
                          onClick={() => setSelectedOrderDetails(o)}
                          className="px-3 py-1 bg-slate-100 dark:bg-slate-700 text-slate-700 dark:text-slate-200 font-bold rounded-lg hover:bg-emerald-600 hover:text-white transition-colors"
                        >
                          Details
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ORDERS MANAGEMENT TAB */}
      {activeTab === 'orders' && (
        <div className="space-y-6">
          <div className="bg-white dark:bg-slate-800 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="relative flex-1 w-full max-w-md">
              <input
                type="text"
                placeholder="Search Order ID, Customer Name, Phone..."
                value={orderSearch}
                onChange={e => setOrderSearch(e.target.value)}
                className="w-full pl-9 pr-3 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-slate-900 dark:text-white outline-none focus:border-emerald-500"
              />
              <Search size={14} className="absolute left-3 top-2.5 text-slate-400" />
            </div>

            <div className="flex items-center gap-2 text-xs w-full sm:w-auto">
              <Filter size={14} className="text-slate-400" />
              <span className="font-bold text-slate-700 dark:text-slate-300">Status:</span>
              <select
                value={statusFilter}
                onChange={e => setStatusFilter(e.target.value)}
                className="px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-slate-900 dark:text-white font-bold outline-none cursor-pointer"
              >
                <option value="all">All Orders ({orders.length})</option>
                <option value="pending">Pending</option>
                <option value="confirmed">Confirmed</option>
                <option value="packed">Packed</option>
                <option value="shipped">Shipped</option>
                <option value="delivered">Delivered</option>
                <option value="cancelled">Cancelled</option>
              </select>
            </div>
          </div>

          <div className="space-y-4">
            {filteredOrders.length === 0 ? (
              <div className="p-12 text-center bg-white dark:bg-slate-800 rounded-3xl border border-slate-200 dark:border-slate-800 text-slate-400">
                <ShoppingBag size={48} className="mx-auto mb-2 opacity-40" />
                <p className="font-bold text-sm">No orders matching filter criteria.</p>
              </div>
            ) : (
              filteredOrders.map(order => (
                <div
                  key={order.id}
                  className="p-6 rounded-3xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4 hover:border-emerald-300 transition-colors"
                >
                  <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-4 border-b border-slate-100 dark:border-slate-700">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-sm font-mono font-black text-emerald-600">{order.id}</span>
                        <span className="text-[10px] bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300 px-2 py-0.5 rounded font-bold">
                          {new Date(order.createdAt).toLocaleDateString()}
                        </span>
                      </div>
                      <p className="text-xs font-bold text-slate-900 dark:text-white mt-1">
                        {order.customerName} • <a href={`tel:${order.customerPhone}`} className="text-emerald-600 font-mono underline">{order.customerPhone}</a>
                      </p>
                      <p className="text-[11px] text-slate-500 mt-0.5 flex items-center gap-1">
                        <MapPin size={12} /> {order.shippingAddress?.address}, {order.shippingAddress?.thana}, {order.shippingAddress?.district}
                      </p>
                    </div>

                    <div className="flex flex-wrap items-center gap-3">
                      <div className="text-right text-xs">
                        <span className="text-slate-400 block text-[10px] uppercase font-bold">Payment Method</span>
                        <span className="font-extrabold uppercase font-mono">{order.paymentMethod}</span>
                        <span className="ml-1 text-[10px] text-emerald-600 font-bold">({order.paymentStatus})</span>
                      </div>

                      <select
                        value={order.status}
                        onChange={e => handleUpdateOrderStatus(order.id, e.target.value as OrderStatus)}
                        className="px-3 py-2 bg-emerald-50 dark:bg-slate-900 border-2 border-emerald-500 text-emerald-900 dark:text-emerald-300 font-extrabold text-xs rounded-xl outline-none cursor-pointer shadow-sm"
                      >
                        <option value="Pending">Pending</option>
                        <option value="Confirmed">Confirmed</option>
                        <option value="Packed">Packed</option>
                        <option value="Shipped">Shipped</option>
                        <option value="Delivered">Delivered</option>
                        <option value="Cancelled">Cancelled</option>
                      </select>

                      <button
                        onClick={() => setSelectedOrderDetails(order)}
                        className="p-2 bg-slate-100 dark:bg-slate-700 text-slate-700 dark:text-slate-200 rounded-xl hover:text-emerald-600"
                        title="View Full Details"
                      >
                        <Eye size={16} />
                      </button>
                    </div>
                  </div>

                  {/* Items List */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
                    {order.items.map((item, idx) => (
                      <div key={idx} className="flex items-center gap-3 p-2 rounded-xl bg-slate-50 dark:bg-slate-900/60 border border-slate-100 dark:border-slate-800 text-xs">
                        <img src={item.image} alt="" className="w-10 h-10 rounded-lg object-cover" />
                        <div className="flex-1 overflow-hidden">
                          <p className="font-bold text-slate-900 dark:text-white truncate">{item.name}</p>
                          <p className="text-[10px] text-slate-400">Qty: {item.quantity} x ৳{item.price}</p>
                        </div>
                        <span className="font-bold">৳{item.price * item.quantity}</span>
                      </div>
                    ))}
                  </div>

                  <div className="pt-3 border-t border-slate-100 dark:border-slate-700 flex justify-between items-center text-xs">
                    <span className="text-slate-400 text-[11px]">Subtotal ৳{order.subtotal} + Shipping ৳{order.shippingCharge}</span>
                    <span className="font-black text-base text-emerald-600">Grand Total: ৳{order.grandTotal}</span>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      )}

      {/* PRODUCTS & INVENTORY TAB */}
      {activeTab === 'products' && (
        <div className="space-y-6">
          <div className="bg-white dark:bg-slate-800 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-3 w-full sm:w-auto flex-1 max-w-lg">
              <div className="relative flex-1">
                <input
                  type="text"
                  placeholder="Search products..."
                  value={productSearch}
                  onChange={e => setProductSearch(e.target.value)}
                  className="w-full pl-9 pr-3 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-slate-900 dark:text-white outline-none focus:border-emerald-500"
                />
                <Search size={14} className="absolute left-3 top-2.5 text-slate-400" />
              </div>

              <select
                value={categoryFilter}
                onChange={e => setCategoryFilter(e.target.value)}
                className="px-3 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-slate-900 dark:text-white font-bold outline-none cursor-pointer"
              >
                <option value="all">All Categories</option>
                {categories.map(c => (
                  <option key={c.id} value={c.name}>{c.name}</option>
                ))}
              </select>
            </div>

            <button
              onClick={() => {
                setEditingProduct({
                  name: '',
                  bnName: '',
                  categoryName: 'Organic Vegetables',
                  price: 300,
                  stock: 50,
                  unit: '1 kg',
                  brand: 'Sundarban Pure',
                  description: '100% natural pure organic product.',
                  benefits: [
                    '১০০% প্রাকৃতিক ও বিশুদ্ধ অর্গানিক খাদ্য',
                    'কোন প্রকার কৃত্রিম কেমিক্যাল বা প্রিজারভেটিভ নেই',
                    'রোগ প্রতিরোধ ক্ষমতা বৃদ্ধি করে ও শক্তি যোগায়'
                  ],
                  nutrition: {
                    'Calories': '120 kcal',
                    'Protein': '1.5 g',
                    'Fat': '0.2 g',
                    'Carbohydrates': '26 g'
                  },
                  images: ['https://images.unsplash.com/photo-1540420773420-3366772f4999?w=800&auto=format&fit=crop&q=80']
                });
                setIsProductModalOpen(true);
              }}
              className="px-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-xs rounded-xl flex items-center gap-2 shadow-md shadow-emerald-600/20 w-full sm:w-auto justify-center"
            >
              <Plus size={16} /> Add New Organic Product
            </button>
          </div>

          <div className="bg-white dark:bg-slate-800 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs border-collapse">
                <thead>
                  <tr className="border-b border-slate-200 dark:border-slate-700 text-slate-400 font-bold uppercase bg-slate-50 dark:bg-slate-900">
                    <th className="p-3">Product</th>
                    <th className="p-3">Category</th>
                    <th className="p-3">Price (BDT)</th>
                    <th className="p-3">Stock Status</th>
                    <th className="p-3">Badges</th>
                    <th className="p-3 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                  {filteredProducts.map(p => (
                    <tr key={p.id} className="hover:bg-slate-50 dark:hover:bg-slate-900/50">
                      <td className="p-3 flex items-center gap-3">
                        <img src={p.images[0]} alt="" className="w-12 h-12 rounded-xl object-cover border border-slate-200 dark:border-slate-700" />
                        <div>
                          <p className="font-bold text-slate-900 dark:text-white">{p.name}</p>
                          <p className="text-[10px] text-emerald-600 font-semibold">{p.bnName}</p>
                          <span className="text-[9px] text-slate-400 font-mono">SKU: {p.sku || p.id}</span>
                        </div>
                      </td>
                      <td className="p-3 text-slate-600 dark:text-slate-300 font-bold">{p.categoryName}</td>
                      <td className="p-3">
                        <span className="font-black text-emerald-600">৳{p.discountPrice || p.price}</span>
                        {p.discountPrice && (
                          <span className="text-[10px] text-slate-400 line-through block">৳{p.price}</span>
                        )}
                      </td>
                      <td className="p-3 font-bold">
                        <span className={`px-2 py-0.5 rounded text-[10px] ${p.stock > 10 ? 'bg-emerald-100 text-emerald-800' : 'bg-red-100 text-red-800'}`}>
                          {p.stock} {p.unit}
                        </span>
                      </td>
                      <td className="p-3">
                        <div className="flex flex-wrap gap-1">
                          {p.featured && <span className="bg-amber-100 text-amber-800 text-[9px] font-bold px-1.5 py-0.5 rounded">Featured</span>}
                          {p.bestSeller && <span className="bg-blue-100 text-blue-800 text-[9px] font-bold px-1.5 py-0.5 rounded">Best Seller</span>}
                          {p.todayDeal && <span className="bg-red-100 text-red-800 text-[9px] font-bold px-1.5 py-0.5 rounded">Today's Deal</span>}
                          {p.benefits && p.benefits.length > 0 && (
                            <span className="bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300 text-[9px] font-bold px-1.5 py-0.5 rounded">
                              Health Benefits ({p.benefits.length})
                            </span>
                          )}
                          {p.nutrition && Object.keys(p.nutrition).length > 0 && (
                            <span className="bg-purple-100 dark:bg-purple-950 text-purple-800 dark:text-purple-300 text-[9px] font-bold px-1.5 py-0.5 rounded">
                              Nutrition ({Object.keys(p.nutrition).length})
                            </span>
                          )}
                        </div>
                      </td>
                      <td className="p-3 text-right space-x-2">
                        <button
                          onClick={() => {
                            setEditingProduct(p);
                            setIsProductModalOpen(true);
                          }}
                          className="p-2 bg-slate-100 dark:bg-slate-700 text-slate-700 dark:text-slate-200 rounded-lg hover:text-emerald-600"
                          title="Edit"
                        >
                          <Edit2 size={14} />
                        </button>
                        <button
                          onClick={() => handleDeleteProduct(p.id)}
                          className="p-2 bg-red-50 text-red-600 rounded-lg hover:bg-red-600 hover:text-white transition-colors"
                          title="Delete"
                        >
                          <Trash2 size={14} />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* CATEGORIES TAB */}
      {activeTab === 'categories' && (
        <div className="space-y-6">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div>
              <h3 className="text-lg font-black text-slate-900 dark:text-white flex items-center gap-2">
                <LayoutGrid className="text-emerald-600" size={20} />
                ক্যাটাগরি ম্যানেজমেন্ট (Category Management)
              </h3>
              <p className="text-xs text-slate-500">
                Add, edit, update, or remove store product categories with icons and Bengali translations.
              </p>
            </div>

            <button
              onClick={() => {
                setEditingCategory({
                  name: '',
                  bnName: '',
                  icon: 'Leaf',
                  image: 'https://images.unsplash.com/photo-1542838132-92c53300491e?w=800&auto=format&fit=crop&q=80',
                  description: ''
                });
                setIsCategoryModalOpen(true);
              }}
              className="px-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-xs rounded-xl flex items-center gap-2 shadow-lg shadow-emerald-600/20 transition-transform active:scale-95"
            >
              <Plus size={16} /> নতুন ক্যাটাগরি যোগ করুন (Add Category)
            </button>
          </div>

          <div className="bg-white dark:bg-slate-800 rounded-3xl border border-slate-200 dark:border-slate-800 p-4 space-y-4 shadow-sm">
            <div className="relative max-w-xs">
              <Search className="absolute left-3 top-2.5 text-slate-400" size={16} />
              <input
                type="text"
                placeholder="Search category by name..."
                value={categorySearch}
                onChange={e => setCategorySearch(e.target.value)}
                className="w-full pl-9 pr-4 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-slate-900 dark:text-white outline-none focus:border-emerald-500 font-bold"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
              {categories
                .filter(cat => !categorySearch || cat.name.toLowerCase().includes(categorySearch.toLowerCase()) || (cat.bnName && cat.bnName.includes(categorySearch)))
                .map(cat => (
                  <div key={cat.id} className="p-4 bg-slate-50 dark:bg-slate-900/60 rounded-2xl border border-slate-200 dark:border-slate-800 flex flex-col justify-between space-y-3 relative group hover:shadow-md transition-all">
                    <div className="space-y-2">
                      <div className="relative h-28 rounded-xl overflow-hidden bg-slate-200 dark:bg-slate-800">
                        <img src={cat.image} alt={cat.name} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" />
                        <span className="absolute top-2 left-2 px-2 py-0.5 bg-slate-950/70 text-white text-[10px] font-mono font-bold rounded-md backdrop-blur-sm">
                          ID: {cat.id}
                        </span>
                        <span className="absolute bottom-2 right-2 px-2 py-0.5 bg-emerald-600 text-white text-[10px] font-bold rounded-full shadow">
                          {cat.itemCount || 0} Products
                        </span>
                      </div>

                      <div>
                        <div className="flex items-center justify-between">
                          <h4 className="font-extrabold text-sm text-slate-900 dark:text-white">{cat.name}</h4>
                          <span className="text-xs bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300 font-bold px-2 py-0.5 rounded-md">
                            {cat.bnName}
                          </span>
                        </div>
                        <p className="text-[11px] text-slate-500 dark:text-slate-400 line-clamp-2 mt-1">
                          {cat.description || 'No description provided.'}
                        </p>
                      </div>
                    </div>

                    <div className="pt-2 border-t border-slate-200 dark:border-slate-800 flex items-center justify-between gap-2">
                      <span className="text-[10px] text-slate-500 font-mono font-bold flex items-center gap-1.5 bg-slate-100 dark:bg-slate-800 px-2 py-1 rounded-lg">
                        {renderCategoryIcon(cat.icon, 14, "text-emerald-600")} Icon: {cat.icon || 'Leaf'}
                      </span>

                      <div className="flex items-center gap-1.5">
                        <button
                          onClick={() => {
                            setEditingCategory({
                              ...cat,
                              _originalId: cat.id
                            } as any);
                            setIsCategoryModalOpen(true);
                          }}
                          className="px-3 py-1.5 bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold text-xs rounded-xl flex items-center gap-1 shadow-sm transition-transform active:scale-95"
                          title="Edit Category"
                        >
                          <Edit2 size={12} /> এডিট (Edit)
                        </button>

                        <button
                          onClick={() => handleDeleteCategory(cat.id, cat.name)}
                          className="px-2.5 py-1.5 bg-red-600/10 hover:bg-red-600 text-red-600 hover:text-white font-bold text-xs rounded-xl flex items-center gap-1 transition-colors"
                          title="Delete Category"
                        >
                          <Trash2 size={12} />
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
            </div>
          </div>
        </div>
      )}

      {/* COUPONS TAB */}
      {activeTab === 'coupons' && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="p-6 bg-white dark:bg-slate-800 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
            <h3 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <Tag className="text-emerald-600" size={18} /> Create Promo Coupon
            </h3>

            <form onSubmit={handleCreateCoupon} className="space-y-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">Coupon Code *</label>
                <input
                  type="text"
                  placeholder="e.g. EID2026"
                  value={newCouponCode}
                  onChange={e => setNewCouponCode(e.target.value)}
                  required
                  className="w-full px-3 py-2 text-xs uppercase font-mono font-bold rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-slate-900 dark:text-white outline-none focus:border-emerald-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">Discount Type</label>
                  <select
                    value={newCouponType}
                    onChange={e => setNewCouponType(e.target.value as any)}
                    className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-slate-900 dark:text-white font-bold outline-none"
                  >
                    <option value="percent">Percentage (%)</option>
                    <option value="fixed">Fixed BDT (৳)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">Discount Value</label>
                  <input
                    type="number"
                    value={newCouponVal}
                    onChange={e => setNewCouponVal(Number(e.target.value))}
                    required
                    className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-slate-900 dark:text-white outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">Minimum Order Spend (BDT)</label>
                <input
                  type="number"
                  value={newCouponMin}
                  onChange={e => setNewCouponMin(Number(e.target.value))}
                  required
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-slate-900 dark:text-white outline-none"
                />
              </div>

              <button
                type="submit"
                className="w-full py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-xs rounded-xl transition-colors shadow-lg shadow-emerald-600/20"
              >
                Add Promo Coupon
              </button>
            </form>
          </div>

          <div className="md:col-span-2 space-y-4">
            <h3 className="text-base font-bold text-slate-900 dark:text-white">Active Promo Coupons</h3>
            <div className="space-y-3">
              {coupons.map(c => (
                <div key={c.code} className="p-4 bg-white dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-800 flex items-center justify-between">
                  <div>
                    <span className="font-mono font-black text-base text-emerald-600 uppercase tracking-wide">{c.code}</span>
                    <p className="text-xs text-slate-500 mt-0.5">
                      {c.discountType === 'percent' ? `${c.discountValue}% OFF` : `৳${c.discountValue} OFF`} • Min Order ৳{c.minSpend}
                    </p>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="px-3 py-1 bg-emerald-100 text-emerald-800 text-[10px] font-bold rounded-full">Active</span>
                    <button
                      onClick={() => handleDeleteCoupon(c.code)}
                      className="p-1.5 bg-red-50 text-red-600 rounded-lg hover:bg-red-600 hover:text-white transition-colors"
                      title="Delete"
                    >
                      <Trash2 size={14} />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* DELIVERY CHARGES & STORE SETTINGS TAB */}
      {activeTab === 'settings' && (
        <div className="max-w-3xl space-y-6">
          <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-4">
            <div>
              <h3 className="text-lg font-extrabold text-slate-900 dark:text-white flex items-center gap-2">
                <Truck className="text-emerald-600" size={22} /> Delivery Charge Settings
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                Configure shipping fees for Inside Dhaka, Outside Dhaka, and Free Delivery rules.
              </p>
            </div>
            <span className="px-3 py-1 bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300 font-bold text-xs rounded-full">
              Live Checkout Updated
            </span>
          </div>

          <form onSubmit={handleSaveSettings} className="bg-white dark:bg-slate-800 p-6 sm:p-8 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-6">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              {/* Inside Dhaka Fee */}
              <div className="p-4 rounded-2xl bg-emerald-50/60 dark:bg-slate-900/80 border border-emerald-200 dark:border-slate-700 space-y-2">
                <div className="flex items-center justify-between">
                  <label className="block text-xs font-bold text-slate-900 dark:text-white">
                    Delivery Charge (Inside Dhaka)
                  </label>
                  <span className="text-[10px] font-extrabold text-emerald-700 dark:text-emerald-400 bg-emerald-100 dark:bg-emerald-950 px-2 py-0.5 rounded">
                    Dhaka Metro
                  </span>
                </div>
                <div className="relative">
                  <span className="absolute left-3 top-2.5 font-bold text-xs text-slate-400">৳</span>
                  <input
                    type="number"
                    min="0"
                    value={insideFeeInput}
                    onChange={e => setInsideFeeInput(Number(e.target.value))}
                    required
                    className="w-full pl-8 pr-4 py-2.5 text-sm font-extrabold font-mono rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white outline-none focus:border-emerald-500"
                  />
                </div>
                <p className="text-[11px] text-slate-500">
                  Applied to all Dhaka division shipping addresses.
                </p>
              </div>

              {/* Outside Dhaka Fee */}
              <div className="p-4 rounded-2xl bg-blue-50/60 dark:bg-slate-900/80 border border-blue-200 dark:border-slate-700 space-y-2">
                <div className="flex items-center justify-between">
                  <label className="block text-xs font-bold text-slate-900 dark:text-white">
                    Delivery Charge (Outside Dhaka)
                  </label>
                  <span className="text-[10px] font-extrabold text-blue-700 dark:text-blue-400 bg-blue-100 dark:bg-blue-950 px-2 py-0.5 rounded">
                    All Bangladesh
                  </span>
                </div>
                <div className="relative">
                  <span className="absolute left-3 top-2.5 font-bold text-xs text-slate-400">৳</span>
                  <input
                    type="number"
                    min="0"
                    value={outsideFeeInput}
                    onChange={e => setOutsideFeeInput(Number(e.target.value))}
                    required
                    className="w-full pl-8 pr-4 py-2.5 text-sm font-extrabold font-mono rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white outline-none focus:border-blue-500"
                  />
                </div>
                <p className="text-[11px] text-slate-500">
                  Applied to Chittagong, Rajshahi, Khulna, Sylhet, Pabna, etc.
                </p>
              </div>
            </div>

            {/* Free Shipping Minimum Threshold */}
            <div className="p-4 rounded-2xl bg-amber-50/60 dark:bg-slate-900/80 border border-amber-200 dark:border-slate-700 space-y-2">
              <label className="block text-xs font-bold text-slate-900 dark:text-white">
                Free Delivery Threshold (Inside Dhaka Subtotal Minimum)
              </label>
              <div className="relative max-w-sm">
                <span className="absolute left-3 top-2.5 font-bold text-xs text-slate-400">৳</span>
                <input
                  type="number"
                  min="0"
                  value={freeShippingMinInput}
                  onChange={e => setFreeShippingMinInput(Number(e.target.value))}
                  required
                  className="w-full pl-8 pr-4 py-2.5 text-sm font-extrabold font-mono rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white outline-none focus:border-amber-500"
                />
              </div>
              <p className="text-[11px] text-slate-500">
                Orders with subtotal above this amount get ৳0 delivery charge in Dhaka. Set 0 to disable.
              </p>
            </div>

            <div className="flex flex-wrap items-center justify-between gap-3 pt-2 border-t border-slate-100 dark:border-slate-800">
              <p className="text-xs text-slate-500 font-medium">
                Current Active Rates: <strong className="text-emerald-600 dark:text-emerald-400 font-mono">Inside Dhaka: ৳{storeSettings.insideDhakaFee}</strong> | <strong className="text-blue-600 dark:text-blue-400 font-mono">Outside Dhaka: ৳{storeSettings.outsideDhakaFee}</strong>
              </p>

              <button
                type="submit"
                disabled={isSavingSettings}
                className="px-6 py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-black text-xs rounded-xl shadow-lg shadow-emerald-600/20 transition-all flex items-center gap-2"
              >
                <CheckCircle2 size={16} />
                {isSavingSettings ? 'Saving Rates...' : 'Save Delivery Charges'}
              </button>
            </div>
          </form>
        </div>
      )}

      {/* MESSAGES TAB */}
      {activeTab === 'messages' && (
        <div className="space-y-4">
          <h3 className="text-base font-bold text-slate-900 dark:text-white">Customer Inquiries & Messages</h3>

          {messages.length === 0 ? (
            <div className="p-12 text-center bg-white dark:bg-slate-800 rounded-3xl border border-slate-200 dark:border-slate-800 text-slate-400">
              <Mail size={48} className="mx-auto mb-2 opacity-40" />
              <p className="font-bold text-sm">No contact messages received yet.</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {messages.map(m => (
                <div key={m.id} className="p-6 bg-white dark:bg-slate-800 rounded-3xl border border-slate-200 dark:border-slate-800 space-y-3 relative shadow-sm">
                  <div className="flex items-start justify-between">
                    <div>
                      <h4 className="font-bold text-sm text-slate-900 dark:text-white">{m.name}</h4>
                      <p className="text-xs text-slate-500 font-mono">{m.phone} • {m.email}</p>
                      <span className="text-[10px] text-slate-400 block mt-0.5">{new Date(m.date).toLocaleString()}</span>
                    </div>

                    <button
                      onClick={() => handleDeleteMessage(m.id)}
                      className="p-1.5 text-slate-400 hover:text-red-500 rounded-lg"
                      title="Delete Message"
                    >
                      <Trash2 size={16} />
                    </button>
                  </div>

                  <div className="p-3 bg-slate-50 dark:bg-slate-900 rounded-xl border border-slate-100 dark:border-slate-800 text-xs">
                    <p className="font-bold text-emerald-600 mb-1">Subject: {m.subject}</p>
                    <p className="text-slate-700 dark:text-slate-300 leading-relaxed">{m.message}</p>
                  </div>

                  <div className="flex gap-2">
                    <a
                      href={`tel:${m.phone}`}
                      className="px-3 py-1.5 bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300 text-xs font-bold rounded-xl flex items-center gap-1.5"
                    >
                      <Phone size={12} /> Call Customer
                    </a>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* BLOGS TAB */}
      {activeTab === 'blogs' && (
        <div className="space-y-6">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div>
              <h3 className="text-lg font-black text-slate-900 dark:text-white">ব্লগ পোস্ট ম্যানেজমেন্ট (Blog Articles)</h3>
              <p className="text-xs text-slate-500">Create, edit, and delete organic living health tips and articles.</p>
            </div>

            <button
              onClick={() => {
                setEditingBlog({
                  title: '',
                  category: 'Organic Living',
                  author: 'Admin Kashem',
                  readTime: '3 min read',
                  image: 'https://images.unsplash.com/photo-1542838132-92c53300491e?auto=format&fit=crop&w=800&q=80',
                  excerpt: '',
                  content: ''
                });
                setIsBlogModalOpen(true);
              }}
              className="px-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-xs rounded-xl flex items-center gap-2 shadow-lg shadow-emerald-600/20"
            >
              <Plus size={16} /> Add New Blog
            </button>
          </div>

          <div className="bg-white dark:bg-slate-800 rounded-3xl border border-slate-200 dark:border-slate-800 p-4 space-y-4 shadow-sm">
            <div className="relative max-w-xs">
              <Search className="absolute left-3 top-2.5 text-slate-400" size={16} />
              <input
                type="text"
                placeholder="Search blogs..."
                value={blogSearch}
                onChange={e => setBlogSearch(e.target.value)}
                className="w-full pl-9 pr-4 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-slate-900 dark:text-white outline-none"
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {blogs
                .filter(b => !blogSearch || b.title.toLowerCase().includes(blogSearch.toLowerCase()) || b.category.toLowerCase().includes(blogSearch.toLowerCase()))
                .map(blog => (
                  <div key={blog.id} className="border border-slate-200 dark:border-slate-700/60 rounded-2xl overflow-hidden bg-slate-50 dark:bg-slate-900/50 flex flex-col justify-between p-4 space-y-3">
                    <div className="flex gap-3">
                      <img src={blog.image} alt="" className="w-16 h-16 rounded-xl object-cover shrink-0" />
                      <div className="flex-1 min-w-0">
                        <span className="text-[10px] font-bold text-emerald-600 uppercase bg-emerald-100 dark:bg-emerald-950 px-2 py-0.5 rounded-md">
                          {blog.category}
                        </span>
                        <h4 className="font-bold text-xs text-slate-900 dark:text-white line-clamp-2 mt-1">{blog.title}</h4>
                        <p className="text-[10px] text-slate-400 mt-0.5">{blog.author} • {blog.date}</p>
                      </div>
                    </div>

                    <div className="pt-2 border-t border-slate-200 dark:border-slate-800 flex items-center justify-between text-xs">
                      <a href={`/blog/${blog.slug}`} target="_blank" rel="noreferrer" className="text-emerald-600 font-bold hover:underline text-[11px] flex items-center gap-1">
                        <Eye size={12} /> View Article
                      </a>

                      <div className="flex items-center gap-1.5">
                        <button
                          onClick={() => {
                            setEditingBlog(blog);
                            setIsBlogModalOpen(true);
                          }}
                          className="px-2.5 py-1 bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold rounded-lg text-[11px] flex items-center gap-1"
                        >
                          <Edit2 size={12} /> Edit
                        </button>
                        <button
                          onClick={() => handleDeleteBlog(blog.id)}
                          className="px-2.5 py-1 bg-red-600 hover:bg-red-700 text-white font-bold rounded-lg text-[11px] flex items-center gap-1"
                        >
                          <Trash2 size={12} /> Delete
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
            </div>
          </div>
        </div>
      )}

      {/* ORDER DETAILS MODAL */}
      {selectedOrderDetails && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 rounded-3xl max-w-2xl w-full p-6 space-y-4 shadow-2xl border border-slate-200 dark:border-slate-800 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
              <div>
                <span className="text-xs font-mono font-black text-emerald-600">{selectedOrderDetails.id}</span>
                <h3 className="text-base font-black text-slate-900 dark:text-white">Order Details</h3>
              </div>
              <button
                onClick={() => setSelectedOrderDetails(null)}
                className="p-2 text-slate-400 hover:text-slate-600 rounded-xl"
              >
                <X size={18} />
              </button>
            </div>

            <div className="grid grid-cols-2 gap-4 text-xs">
              <div className="p-3 bg-slate-50 dark:bg-slate-800 rounded-xl">
                <p className="font-bold text-slate-500 mb-1">Customer Information</p>
                <p className="font-bold text-slate-900 dark:text-white">{selectedOrderDetails.customerName}</p>
                <p className="font-mono text-emerald-600 font-bold">{selectedOrderDetails.customerPhone}</p>
                <p>{selectedOrderDetails.customerEmail}</p>
              </div>

              <div className="p-3 bg-slate-50 dark:bg-slate-800 rounded-xl">
                <p className="font-bold text-slate-500 mb-1">Shipping Address</p>
                <p>{selectedOrderDetails.shippingAddress?.address}</p>
                <p>{selectedOrderDetails.shippingAddress?.thana}, {selectedOrderDetails.shippingAddress?.district}</p>
              </div>
            </div>

            {/* Items */}
            <div className="space-y-2">
              <p className="text-xs font-bold text-slate-700 dark:text-slate-300">Ordered Products</p>
              {selectedOrderDetails.items.map((item, i) => (
                <div key={i} className="flex items-center gap-3 p-2 border border-slate-100 dark:border-slate-800 rounded-xl text-xs">
                  <img src={item.image} alt="" className="w-10 h-10 rounded-lg object-cover" />
                  <div className="flex-1">
                    <p className="font-bold text-slate-900 dark:text-white">{item.name}</p>
                    <p className="text-slate-400 text-[10px]">Qty: {item.quantity} x ৳{item.price}</p>
                  </div>
                  <span className="font-bold">৳{item.price * item.quantity}</span>
                </div>
              ))}
            </div>

            {/* Price + Delivery Charge Breakdown */}
            <div className="pt-3 border-t border-slate-100 dark:border-slate-800 space-y-1 text-xs">
              <div className="flex justify-between text-slate-600 dark:text-slate-400">
                <span>পণ্য মূল্য মোট (Products Price):</span>
                <span className="font-mono font-bold">৳{selectedOrderDetails.subtotal || selectedOrderDetails.items.reduce((sum, item) => sum + (item.price * item.quantity), 0)}</span>
              </div>

              <div className="flex justify-between text-slate-600 dark:text-slate-400">
                <span>ডেলিভারি চার্জ (Delivery Charge):</span>
                <span className="font-mono font-bold text-emerald-600">+ ৳{selectedOrderDetails.shippingCharge ?? 70}</span>
              </div>

              {selectedOrderDetails.discount > 0 && (
                <div className="flex justify-between text-emerald-600">
                  <span>ডিসকাউন্ট (Discount):</span>
                  <span className="font-mono font-bold">- ৳{selectedOrderDetails.discount}</span>
                </div>
              )}

              <div className="flex justify-between items-center pt-2 border-t border-slate-200 dark:border-slate-700 font-black text-sm text-emerald-600">
                <span>সর্বমোট প্রদেয় (Grand Total):</span>
                <span className="text-base font-mono">৳{selectedOrderDetails.grandTotal}</span>
              </div>
            </div>

            <div className="pt-2 flex items-center justify-end gap-2">
              <button
                onClick={() => setInvoiceOrder(selectedOrderDetails)}
                className="w-full py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold rounded-xl shadow-lg shadow-emerald-600/20 flex items-center justify-center gap-2 text-xs"
              >
                <Printer size={16} /> ইনভয়েস প্রিন্ট করুন A5 (Print A5 Invoice)
              </button>
            </div>
          </div>
        </div>
      )}

      {/* A5 INVOICE MODAL */}
      {invoiceOrder && (
        <A5InvoiceModal order={invoiceOrder} onClose={() => setInvoiceOrder(null)} />
      )}

      {/* PRODUCT ADD / EDIT MODAL */}
      {isProductModalOpen && editingProduct && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white dark:bg-slate-900 rounded-3xl max-w-2xl w-full p-6 space-y-4 shadow-2xl border border-slate-200 dark:border-slate-800 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
              <h3 className="text-base font-bold text-slate-900 dark:text-white">
                {editingProduct.id ? 'Edit Organic Product' : 'Add New Organic Product'}
              </h3>
              <button
                onClick={() => setIsProductModalOpen(false)}
                className="p-2 text-slate-400 hover:text-slate-600 rounded-xl"
              >
                <X size={18} />
              </button>
            </div>

            <form onSubmit={handleSaveProduct} className="space-y-3 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold mb-1">Product Title *</label>
                  <input
                    type="text"
                    value={editingProduct.name || ''}
                    onChange={e => setEditingProduct({ ...editingProduct, name: e.target.value })}
                    required
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white outline-none"
                  />
                </div>

                <div>
                  <label className="block font-bold mb-1">Bengali Title</label>
                  <input
                    type="text"
                    value={editingProduct.bnName || ''}
                    onChange={e => setEditingProduct({ ...editingProduct, bnName: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block font-bold mb-1">Category *</label>
                  <select
                    value={editingProduct.categoryName || 'Organic Vegetables'}
                    onChange={e => setEditingProduct({ ...editingProduct, categoryName: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white outline-none"
                  >
                    {categories.map(c => (
                      <option key={c.id} value={c.name}>{c.name}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block font-bold mb-1">Regular Price (BDT) *</label>
                  <input
                    type="number"
                    value={editingProduct.price || 0}
                    onChange={e => setEditingProduct({ ...editingProduct, price: Number(e.target.value) })}
                    required
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white outline-none"
                  />
                </div>

                <div>
                  <label className="block font-bold mb-1">Discount Price (BDT)</label>
                  <input
                    type="number"
                    value={editingProduct.discountPrice || ''}
                    onChange={e => setEditingProduct({ ...editingProduct, discountPrice: Number(e.target.value) })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block font-bold mb-1">Stock Quantity</label>
                  <input
                    type="number"
                    value={editingProduct.stock || 50}
                    onChange={e => setEditingProduct({ ...editingProduct, stock: Number(e.target.value) })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white outline-none"
                  />
                </div>

                <div>
                  <label className="block font-bold mb-1">Unit / Weight</label>
                  <input
                    type="text"
                    value={editingProduct.unit || '1 kg'}
                    onChange={e => setEditingProduct({ ...editingProduct, unit: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white outline-none"
                  />
                </div>

                <div>
                  <label className="block font-bold mb-1">Brand</label>
                  <input
                    type="text"
                    value={editingProduct.brand || 'Sundarban Pure'}
                    onChange={e => setEditingProduct({ ...editingProduct, brand: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block font-bold mb-1">Image URL</label>
                <input
                  type="text"
                  value={editingProduct.images ? editingProduct.images[0] : ''}
                  onChange={e => setEditingProduct({ ...editingProduct, images: [e.target.value] })}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white outline-none"
                />
              </div>

              <div>
                <label className="block font-bold mb-1">Description</label>
                <textarea
                  rows={3}
                  value={editingProduct.description || ''}
                  onChange={e => setEditingProduct({ ...editingProduct, description: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white outline-none"
                />
              </div>

              {/* HEALTH BENEFITS EDITING SECTION */}
              <div className="p-3.5 bg-emerald-50/60 dark:bg-emerald-950/30 rounded-2xl border border-emerald-200/80 dark:border-emerald-800/50 space-y-2">
                <div className="flex items-center justify-between">
                  <label className="block font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
                    <Heart size={15} className="text-emerald-600 dark:text-emerald-400" />
                    স্বাস্থ্য উপকারিতা (Health Benefits - প্রতি লাইনে ১টি পয়েন্ট)
                  </label>
                  <span className="text-[10px] text-emerald-700 dark:text-emerald-400 font-semibold bg-emerald-100 dark:bg-emerald-900/60 px-2 py-0.5 rounded-full">
                    {editingProduct.benefits ? editingProduct.benefits.filter(Boolean).length : 0} Points Added
                  </span>
                </div>
                <textarea
                  rows={3}
                  placeholder="১০০% প্রাকৃতিক ও বিশুদ্ধ অর্গানিক খাদ্য&#10;কোন প্রকার কৃত্রিম কেমিক্যাল বা প্রিজারভেটিভ নেই&#10;রোগ প্রতিরোধ ক্ষমতা বৃদ্ধি করে ও শক্তি যোগায়"
                  value={editingProduct.benefits ? editingProduct.benefits.join('\n') : ''}
                  onChange={e => {
                    const lines = e.target.value.split('\n');
                    setEditingProduct({ ...editingProduct, benefits: lines });
                  }}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white outline-none focus:border-emerald-500 font-medium leading-relaxed"
                />
                <p className="text-[10px] text-slate-500 dark:text-slate-400">
                  * প্রতিটি পয়েন্ট নতুন লাইনে টাইপ করুন। ক্রেতারা প্রোডাক্ট ডিটেইলসে টিকচিহ্নসহ দেখতে পাবেন।
                </p>
                {editingProduct.benefits && editingProduct.benefits.filter(Boolean).length > 0 && (
                  <div className="pt-1 flex flex-wrap gap-1.5">
                    {editingProduct.benefits.filter(Boolean).map((b, idx) => (
                      <span key={idx} className="bg-emerald-100 dark:bg-emerald-900/80 text-emerald-800 dark:text-emerald-200 text-[10px] font-bold px-2 py-0.5 rounded-md flex items-center gap-1">
                        <Check size={12} className="text-emerald-600" /> {b}
                      </span>
                    ))}
                  </div>
                )}
              </div>

              {/* NUTRITION INFO EDITING SECTION */}
              <div className="p-3.5 bg-slate-50 dark:bg-slate-800/60 rounded-2xl border border-slate-200 dark:border-slate-700 space-y-3">
                <div className="flex items-center justify-between">
                  <label className="block font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
                    <Sparkles size={15} className="text-emerald-600 dark:text-emerald-400" />
                    পুষ্টি উপাদান তথ্যাবলী (Nutrition Info / Nutrition Facts)
                  </label>
                  <button
                    type="button"
                    onClick={() => {
                      const currentNut = editingProduct.nutrition || {};
                      setEditingProduct({
                        ...editingProduct,
                        nutrition: { ...currentNut, '': '' }
                      });
                    }}
                    className="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-[11px] rounded-lg transition-colors flex items-center gap-1 shadow-sm"
                  >
                    <Plus size={12} /> নতুন তথ্য যোগ করুন (Add Row)
                  </button>
                </div>

                {(!editingProduct.nutrition || Object.keys(editingProduct.nutrition).length === 0) ? (
                  <p className="text-[11px] text-slate-400 italic">No nutrition information added yet. Click 'Add Row' or use preset below.</p>
                ) : (
                  <div className="space-y-2 max-h-48 overflow-y-auto pr-1">
                    {(Object.entries(editingProduct.nutrition) as [string, string][]).map(([nutKey, nutVal], idx) => (
                      <div key={idx} className="flex items-center gap-2">
                        <input
                          type="text"
                          placeholder="উপাদান (e.g. Calories / Protein)"
                          value={nutKey}
                          onChange={e => {
                            const newKey = e.target.value;
                            const entries = Object.entries(editingProduct.nutrition || {}) as [string, string][];
                            entries[idx] = [newKey, nutVal];
                            const newNutObj: Record<string, string> = {};
                            entries.forEach(([k, v]) => { newNutObj[k] = String(v); });
                            setEditingProduct({ ...editingProduct, nutrition: newNutObj });
                          }}
                          className="w-1/2 px-2.5 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white text-xs outline-none focus:border-emerald-500 font-bold"
                        />
                        <input
                          type="text"
                          placeholder="পরিমাণ (e.g. 120 kcal / 2.5 g)"
                          value={nutVal}
                          onChange={e => {
                            const newVal = e.target.value;
                            const entries = Object.entries(editingProduct.nutrition || {}) as [string, string][];
                            entries[idx] = [nutKey, newVal];
                            const newNutObj: Record<string, string> = {};
                            entries.forEach(([k, v]) => { newNutObj[k] = String(v); });
                            setEditingProduct({ ...editingProduct, nutrition: newNutObj });
                          }}
                          className="w-1/2 px-2.5 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white text-xs outline-none focus:border-emerald-500"
                        />
                        <button
                          type="button"
                          onClick={() => {
                            const entries = Object.entries(editingProduct.nutrition || {}) as [string, string][];
                            entries.splice(idx, 1);
                            const newNutObj: Record<string, string> = {};
                            entries.forEach(([k, v]) => { if (k) newNutObj[k] = String(v); });
                            setEditingProduct({ ...editingProduct, nutrition: newNutObj });
                          }}
                          className="p-1.5 text-red-500 hover:bg-red-50 dark:hover:bg-red-950/50 rounded-lg transition-colors shrink-0"
                          title="Delete Row"
                        >
                          <Trash2 size={14} />
                        </button>
                      </div>
                    ))}
                  </div>
                )}

                <div className="pt-2 flex items-center justify-between border-t border-slate-200 dark:border-slate-700 text-[11px]">
                  <span className="text-slate-400">Quick fill demo specs:</span>
                  <button
                    type="button"
                    onClick={() => {
                      setEditingProduct({
                        ...editingProduct,
                        nutrition: {
                          'Calories': '120 kcal',
                          'Protein': '1.5 g',
                          'Fat': '0.2 g',
                          'Carbohydrates': '26 g',
                          'Dietary Fiber': '2.1 g'
                        }
                      });
                    }}
                    className="font-bold text-emerald-600 hover:underline"
                  >
                    + Fill Sample Nutrition Specs
                  </button>
                </div>
              </div>

              <div className="flex flex-wrap gap-4 pt-2">
                <label className="flex items-center gap-2 font-bold cursor-pointer">
                  <input
                    type="checkbox"
                    checked={!!editingProduct.featured}
                    onChange={e => setEditingProduct({ ...editingProduct, featured: e.target.checked })}
                  />
                  Featured Item
                </label>

                <label className="flex items-center gap-2 font-bold cursor-pointer">
                  <input
                    type="checkbox"
                    checked={!!editingProduct.bestSeller}
                    onChange={e => setEditingProduct({ ...editingProduct, bestSeller: e.target.checked })}
                  />
                  Best Seller
                </label>

                <label className="flex items-center gap-2 font-bold cursor-pointer">
                  <input
                    type="checkbox"
                    checked={!!editingProduct.todayDeal}
                    onChange={e => setEditingProduct({ ...editingProduct, todayDeal: e.target.checked })}
                  />
                  Today's Deal
                </label>
              </div>

              <div className="flex justify-end gap-2 pt-4">
                <button
                  type="button"
                  onClick={() => setIsProductModalOpen(false)}
                  className="px-4 py-2 bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-bold rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-6 py-2 bg-emerald-600 text-white font-extrabold rounded-xl shadow"
                >
                  Save Product
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* BLOG ADD / EDIT MODAL */}
      {isBlogModalOpen && editingBlog && (
        <div className="fixed inset-0 z-50 bg-slate-900/70 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl max-w-2xl w-full p-6 sm:p-8 space-y-6 shadow-2xl my-8 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-4">
              <h2 className="text-lg font-black text-slate-900 dark:text-white flex items-center gap-2">
                <Edit2 className="text-emerald-600" size={20} />
                {editingBlog.id ? 'ব্লগ এডিট করুন (Edit Blog)' : 'নতুন ব্লগ তৈরি করুন (Create Blog)'}
              </h2>
              <button
                onClick={() => setIsBlogModalOpen(false)}
                className="p-2 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-full text-slate-400"
              >
                <X size={20} />
              </button>
            </div>

            <form onSubmit={handleSaveBlog} className="space-y-4 text-xs font-semibold">
              <div>
                <label className="block text-slate-700 dark:text-slate-300 font-bold mb-1">
                  ব্লগ শিরোনাম (Blog Title) *
                </label>
                <input
                  type="text"
                  required
                  value={editingBlog.title || ''}
                  onChange={e => setEditingBlog({ ...editingBlog, title: e.target.value })}
                  placeholder="e.g. Benefits of Pure Sundarban Honey"
                  className="w-full px-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white outline-none focus:border-emerald-500 font-bold"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-slate-700 dark:text-slate-300 font-bold mb-1">
                    ক্যাটাগরি (Category)
                  </label>
                  <input
                    type="text"
                    value={editingBlog.category || 'Organic Living'}
                    onChange={e => setEditingBlog({ ...editingBlog, category: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white outline-none"
                  />
                </div>

                <div>
                  <label className="block text-slate-700 dark:text-slate-300 font-bold mb-1">
                    লেখক (Author)
                  </label>
                  <input
                    type="text"
                    value={editingBlog.author || 'Admin Kashem'}
                    onChange={e => setEditingBlog({ ...editingBlog, author: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white outline-none"
                  />
                </div>

                <div>
                  <label className="block text-slate-700 dark:text-slate-300 font-bold mb-1">
                    পড়ার সময় (Read Time)
                  </label>
                  <input
                    type="text"
                    value={editingBlog.readTime || '3 min read'}
                    onChange={e => setEditingBlog({ ...editingBlog, readTime: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-700 dark:text-slate-300 font-bold mb-1">
                  ছবি URL (Cover Image URL)
                </label>
                <input
                  type="text"
                  value={editingBlog.image || ''}
                  onChange={e => setEditingBlog({ ...editingBlog, image: e.target.value })}
                  placeholder="https://images.unsplash.com/..."
                  className="w-full px-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white outline-none font-mono text-[11px]"
                />
              </div>

              <div>
                <label className="block text-slate-700 dark:text-slate-300 font-bold mb-1">
                  সংক্ষিপ্ত অংশ (Excerpt)
                </label>
                <textarea
                  rows={2}
                  value={editingBlog.excerpt || ''}
                  onChange={e => setEditingBlog({ ...editingBlog, excerpt: e.target.value })}
                  placeholder="Short summary displayed on list page..."
                  className="w-full px-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white outline-none"
                />
              </div>

              <div>
                <label className="block text-slate-700 dark:text-slate-300 font-bold mb-1">
                  মূল বিস্তারিত কনটেন্ট (Full Content) *
                </label>
                <textarea
                  rows={7}
                  required
                  value={editingBlog.content || ''}
                  onChange={e => setEditingBlog({ ...editingBlog, content: e.target.value })}
                  placeholder="Write complete article details here..."
                  className="w-full px-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white outline-none font-sans"
                />
              </div>

              <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-200 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsBlogModalOpen(false)}
                  className="px-5 py-2.5 bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-bold rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-6 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold rounded-xl shadow-lg shadow-emerald-600/20"
                >
                  {editingBlog.id ? 'Save Changes' : 'Publish Blog'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* CATEGORY EDIT / ADD MODAL */}
      {isCategoryModalOpen && editingCategory && (
        <div className="fixed inset-0 z-50 bg-slate-900/70 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl max-w-lg w-full p-6 sm:p-8 space-y-6 shadow-2xl my-8">
            <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-4">
              <h2 className="text-lg font-black text-slate-900 dark:text-white flex items-center gap-2">
                <Edit2 className="text-emerald-600" size={20} />
                {editingCategory.id ? 'ক্যাটাগরি সম্পাদনা করুন (Edit Category)' : 'নতুন ক্যাটাগরি তৈরি করুন (Add Category)'}
              </h2>
              <button
                onClick={() => setIsCategoryModalOpen(false)}
                className="p-2 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-full text-slate-400"
              >
                <X size={20} />
              </button>
            </div>

            <form onSubmit={handleSaveCategory} className="space-y-4 text-xs font-semibold">
              <div>
                <label className="block text-slate-700 dark:text-slate-300 font-bold mb-1">
                  ক্যাটাগরির নাম (English Name) *
                </label>
                <input
                  type="text"
                  required
                  value={editingCategory.name || ''}
                  onChange={e => setEditingCategory({ ...editingCategory, name: e.target.value })}
                  placeholder="e.g. Organic Honey & Ghee"
                  className="w-full px-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white outline-none focus:border-emerald-500 font-bold"
                />
              </div>

              <div>
                <label className="block text-slate-700 dark:text-slate-300 font-bold mb-1">
                  বাংলা নাম (Bangla Name)
                </label>
                <input
                  type="text"
                  value={editingCategory.bnName || ''}
                  onChange={e => setEditingCategory({ ...editingCategory, bnName: e.target.value })}
                  placeholder="e.g. খাঁটি মধু ও ঘি"
                  className="w-full px-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white outline-none focus:border-emerald-500 font-bold"
                />
              </div>

              <div>
                <label className="block text-slate-700 dark:text-slate-300 font-bold mb-1">
                  ক্যাটাগরি আইডি / স্ল্যাগ (Category ID / Slug)
                </label>
                <input
                  type="text"
                  value={editingCategory.id || ''}
                  onChange={e => setEditingCategory({ ...editingCategory, id: e.target.value })}
                  placeholder="e.g. honey-ghee"
                  className="w-full px-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white outline-none focus:border-emerald-500 font-mono text-xs font-bold"
                />
                <p className="text-[10px] text-slate-400 mt-1">Unique identifier used in database, URLs, and filtering (editable).</p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-700 dark:text-slate-300 font-bold mb-1">
                    আইকন টাইপ (Icon Name)
                  </label>
                  <div className="flex items-center gap-2">
                    <div className="p-2.5 bg-emerald-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl flex items-center justify-center flex-shrink-0">
                      {renderCategoryIcon(editingCategory.icon || 'Leaf', 20, "text-emerald-600")}
                    </div>
                    <select
                      value={editingCategory.icon || 'Leaf'}
                      onChange={e => setEditingCategory({ ...editingCategory, icon: e.target.value })}
                      className="w-full px-3 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white outline-none font-bold text-xs"
                    >
                      <option value="Leaf">Leaf (পাতা / অর্গানিক)</option>
                      <option value="Apple">Apple (ফলমূল / Fruits)</option>
                      <option value="Droplet">Droplet (তেল ও মধু / Oil & Honey)</option>
                      <option value="Sprout">Sprout (শাক-সবজি / Fresh Veggies)</option>
                      <option value="Flame">Flame (মশলা ও হট আইটেম / Spices)</option>
                      <option value="Coffee">Coffee (চা ও পানীয় / Tea & Coffee)</option>
                      <option value="Sun">Sun (মৌসুমী ফল / Seasonal Items)</option>
                      <option value="Heart">Heart (স্বাস্থ্যকর খাদ্য / Health Care)</option>
                      <option value="Package">Package (স্ন্যাকস / Snacks & Grocery)</option>
                      <option value="Egg">Egg (ডিম ও দুগ্ধ / Milk & Eggs)</option>
                      <option value="Wheat">Wheat (চাল, ডাল ও দানা / Rice & Grains)</option>
                      <option value="Fish">Fish (মাছ ও মাংস / Fish & Meat)</option>
                      <option value="Cookie">Cookie (বেকারি ও বিস্কুট / Bakery)</option>
                      <option value="Sparkles">Sparkles (বিশেষ আইটেম / Special Offers)</option>
                      <option value="ShoppingBag">ShoppingBag (গ্রোসারী বাজার / General Grocery)</option>
                      <option value="Box">Box (কম্বো ও পার্সেল / Combo Box)</option>
                      <option value="Store">Store (শপ আইটেম / Store Collection)</option>
                      <option value="Utensils">Utensils (রান্নার সামগ্রী / Kitchen Items)</option>
                      <option value="Gift">Gift (উপহার প্যাক / Gift Items)</option>
                      <option value="Carrot">Carrot (সবজি ও গাজর / Organic Carrot)</option>
                      <option value="Beef">Beef (গোশত ও মিট / Fresh Meat)</option>
                      <option value="Milk">Milk (দুধ ও ডেইরি / Dairy Milk)</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-slate-700 dark:text-slate-300 font-bold mb-1">
                    ছবি ইউআরএল (Image URL)
                  </label>
                  <input
                    type="text"
                    value={editingCategory.image || ''}
                    onChange={e => setEditingCategory({ ...editingCategory, image: e.target.value })}
                    placeholder="https://images.unsplash.com/..."
                    className="w-full px-3 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white outline-none font-mono text-[11px]"
                  />
                </div>
              </div>

              {editingCategory.image && (
                <div className="flex items-center gap-3 p-2 bg-slate-100 dark:bg-slate-800 rounded-2xl">
                  <img src={editingCategory.image} alt="Preview" className="w-16 h-12 rounded-xl object-cover" />
                  <span className="text-[11px] text-slate-500 font-bold">Image Preview</span>
                </div>
              )}

              <div>
                <label className="block text-slate-700 dark:text-slate-300 font-bold mb-1">
                  সংক্ষিপ্ত বিবরণ (Description)
                </label>
                <textarea
                  rows={3}
                  value={editingCategory.description || ''}
                  onChange={e => setEditingCategory({ ...editingCategory, description: e.target.value })}
                  placeholder="E.g. 100% natural, chemical-free organic honey and artisanal ghee."
                  className="w-full px-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white outline-none"
                />
              </div>

              <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-200 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsCategoryModalOpen(false)}
                  className="px-5 py-2.5 bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-bold rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-6 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold rounded-xl shadow-lg shadow-emerald-600/20 transition-transform active:scale-95"
                >
                  {editingCategory.id ? 'ক্যাটাগরি আপডেট করুন (Save Changes)' : 'নতুন ক্যাটাগরি সেভ করুন (Create Category)'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
