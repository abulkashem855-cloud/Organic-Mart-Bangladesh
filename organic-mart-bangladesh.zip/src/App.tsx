import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';

import { ThemeProvider } from './context/ThemeContext';
import { AuthProvider } from './context/AuthContext';
import { CartProvider } from './context/CartContext';

import { Header } from './components/common/Header';
import { Footer } from './components/common/Footer';
import { FloatingAction } from './components/common/FloatingAction';
import { CartDrawer } from './components/cart/CartDrawer';
import { ProductDetailModal } from './components/product/ProductDetailModal';
import { ProductCompareModal } from './components/product/ProductCompareModal';

import { HomePage } from './pages/HomePage';
import { ShopPage } from './pages/ShopPage';
import { OffersPage } from './pages/OffersPage';
import { TrackOrderPage } from './pages/TrackOrderPage';
import { CartPage } from './pages/CartPage';
import { CheckoutPage } from './pages/CheckoutPage';
import { OrderSuccessPage } from './pages/OrderSuccessPage';
import { BlogPage } from './pages/BlogPage';
import { SingleBlogPage } from './pages/SingleBlogPage';
import { AboutPage } from './pages/AboutPage';
import { ContactPage } from './pages/ContactPage';
import { PolicyPage } from './pages/PolicyPage';
import { UserAccountPage } from './pages/UserAccountPage';
import { LoginPage } from './pages/LoginPage';
import { RegisterPage } from './pages/RegisterPage';
import { AdminDashboardPage } from './pages/AdminDashboardPage';
import { NotFoundPage } from './pages/NotFoundPage';

export function App() {
  return (
    <ThemeProvider>
      <AuthProvider>
        <CartProvider>
          <Router>
            <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 flex flex-col font-sans transition-colors duration-300">
              {/* Header */}
              <Header />

              {/* Main Content Body */}
              <main className="flex-1">
                <Routes>
                  <Route path="/" element={<HomePage />} />
                  <Route path="/shop" element={<ShopPage />} />
                  <Route path="/offers" element={<OffersPage />} />
                  <Route path="/track" element={<TrackOrderPage />} />
                  <Route path="/cart" element={<CartPage />} />
                  <Route path="/checkout" element={<CheckoutPage />} />
                  <Route path="/order-success" element={<OrderSuccessPage />} />
                  <Route path="/blog" element={<BlogPage />} />
                  <Route path="/blog/:slug" element={<SingleBlogPage />} />
                  <Route path="/about" element={<AboutPage />} />
                  <Route path="/contact" element={<ContactPage />} />
                  <Route path="/policy" element={<PolicyPage />} />
                  <Route path="/privacy-policy" element={<PolicyPage defaultTab="privacy" />} />
                  <Route path="/terms-conditions" element={<PolicyPage defaultTab="terms" />} />
                  <Route path="/refund-policy" element={<PolicyPage defaultTab="refund" />} />
                  <Route path="/shipping-policy" element={<PolicyPage defaultTab="shipping" />} />
                  <Route path="/faq" element={<PolicyPage defaultTab="faq" />} />
                  <Route path="/account" element={<UserAccountPage />} />
                  <Route path="/login" element={<LoginPage />} />
                  <Route path="/register" element={<RegisterPage />} />
                  <Route path="/admin" element={<AdminDashboardPage />} />
                  <Route path="*" element={<NotFoundPage />} />
                </Routes>
              </main>

              {/* Shared Modals & Drawers */}
              <CartDrawer />
              <ProductDetailModal />
              <ProductCompareModal />
              <FloatingAction />

              {/* Footer */}
              <Footer />
            </div>
          </Router>
        </CartProvider>
      </AuthProvider>
    </ThemeProvider>
  );
}

export default App;
