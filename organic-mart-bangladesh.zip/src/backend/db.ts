import fs from 'fs';
import path from 'path';
import bcrypt from 'bcryptjs';
import { Product, Category, User, Order, Coupon, BlogPost, ContactMessage, Review, StoreSettings } from '../types';

const DATA_DIR = path.join(process.cwd(), 'data');
const DB_FILE = path.join(DATA_DIR, 'db.json');

export interface DatabaseSchema {
  users: User[];
  passwords: Record<string, string>; // userId -> bcrypt hash
  categories: Category[];
  products: Product[];
  orders: Order[];
  coupons: Coupon[];
  blogs: BlogPost[];
  messages: ContactMessage[];
  newsletters: string[];
  settings?: StoreSettings;
}

// Initial seed categories
const initialCategories: Category[] = [
  {
    id: 'vegetables',
    name: 'Organic Vegetables',
    bnName: 'জৈব শাক-সবজি',
    icon: 'Carrot',
    image: 'https://images.unsplash.com/photo-1540420773420-3366772f4999?w=600&auto=format&fit=crop&q=80',
    description: 'Fresh pesticide-free organic vegetables directly harvested from rural Bangladeshi partner farms.',
    itemCount: 24
  },
  {
    id: 'fruits',
    name: 'Organic Fruits',
    bnName: 'অর্গানিক ফলমূল',
    icon: 'Apple',
    image: 'https://images.unsplash.com/photo-1610832958506-aa56368176cf?w=600&auto=format&fit=crop&q=80',
    description: 'Chemical-free fresh organic fruits from Rajshahi, Dinajpur, and Sylhet orchards.',
    itemCount: 18
  },
  {
    id: 'rice',
    name: 'Organic Rice',
    bnName: 'দেশি ও সুগন্ধি চাল',
    icon: 'Wheat',
    image: 'https://images.unsplash.com/photo-1586201375761-83865001e31c?w=600&auto=format&fit=crop&q=80',
    description: 'Unpolished traditional red rice, aromatic Kalijira, Chinigura, and Nazirshail.',
    itemCount: 12
  },
  {
    id: 'honey',
    name: 'Organic Honey',
    bnName: 'সুন্দরবনের খাঁটি মধু',
    icon: 'Droplets',
    image: 'https://images.unsplash.com/photo-1587049352846-4a222e784d38?w=600&auto=format&fit=crop&q=80',
    description: '100% pure raw Sundarban wildflower and mustard honey collected by Moumachi honey hunters.',
    itemCount: 8
  },
  {
    id: 'tea',
    name: 'Organic Tea',
    bnName: 'শ্রীমঙ্গলের চা',
    icon: 'Coffee',
    image: 'https://images.unsplash.com/photo-1576092768241-dec231879fc3?w=600&auto=format&fit=crop&q=80',
    description: 'Handpicked organic black tea, green tea with tulsi, and herbal teas from Sreemangal tea estates.',
    itemCount: 10
  },
  {
    id: 'oil',
    name: 'Organic Oil',
    bnName: 'ঘানি ভাঙা খাঁটি তেল',
    icon: 'Container',
    image: 'https://images.unsplash.com/photo-1474979266404-7eaacbcd87c5?w=600&auto=format&fit=crop&q=80',
    description: 'Cold-pressed Ghani mustard oil, virgin coconut oil, and organic sesame oil.',
    itemCount: 9
  },
  {
    id: 'spices',
    name: 'Organic Spices',
    bnName: 'অর্গানিক মশলা',
    icon: 'Flame',
    image: 'https://images.unsplash.com/photo-1596040033229-a9821ebd058d?w=600&auto=format&fit=crop&q=80',
    description: 'Stone-ground turmeric, red chili, cumin, coriander, and homemade garama masala powders.',
    itemCount: 15
  },
  {
    id: 'milk-eggs',
    name: 'Organic Milk & Eggs',
    bnName: 'খামারের দুধ ও ডিম',
    icon: 'Egg',
    image: 'https://images.unsplash.com/photo-1550583724-b2692b85b150?w=600&auto=format&fit=crop&q=80',
    description: 'Pure grass-fed cow milk and free-range native chicken eggs (Deshi Dimer Hali).',
    itemCount: 6
  },
  {
    id: 'dry-fruits',
    name: 'Dry Fruits & Nuts',
    bnName: 'ড্রাই ফ্রুটস ও বাদাম',
    icon: 'Nut',
    image: 'https://images.unsplash.com/photo-1599599810769-bcde5a160d32?w=600&auto=format&fit=crop&q=80',
    description: 'Premium Iranian dates, organic almonds, cashew nuts, walnuts, and dried berries.',
    itemCount: 14
  },
  {
    id: 'snacks',
    name: 'Organic Snacks',
    bnName: 'অর্গানিক স্ন্যাকস',
    icon: 'Cookie',
    image: 'https://images.unsplash.com/photo-1558961363-fa8fdf82db35?w=600&auto=format&fit=crop&q=80',
    description: 'Traditional handmade rice crackers, puffed rice (Muri), date jaggery cookies, and handmade Chanachur.',
    itemCount: 11
  },
  {
    id: 'health',
    name: 'Health & Wellness',
    bnName: 'স্বাস্থ্যসুরক্ষা সামগ্রী',
    icon: 'Heart',
    image: 'https://images.unsplash.com/photo-1512069772995-ec65ed45afd6?w=600&auto=format&fit=crop&q=80',
    description: 'Black seed oil (Kalojira Tael), Chia seeds, Spirulina, Moringa leaf powder, and Triphala.',
    itemCount: 16
  }
];

// Initial seed products
const initialProducts: Product[] = [
  {
    id: 'prod-001',
    name: 'Pure Sundarban Wild Honey (সুন্দরবনের প্রাকৃতিক মধু)',
    sku: 'OMB-HNY-001',
    categoryId: 'honey',
    categoryName: 'Organic Honey',
    brand: 'Sundarban Natural',
    price: 950,
    discountPrice: 850,
    discountPercent: 10,
    rating: 4.9,
    reviewCount: 128,
    stock: 45,
    unit: '500g',
    images: [
      'https://images.unsplash.com/photo-1587049352846-4a222e784d38?w=800&auto=format&fit=crop&q=80',
      'https://images.unsplash.com/photo-1558642452-9d2a7deb7f62?w=800&auto=format&fit=crop&q=80'
    ],
    featured: true,
    bestSeller: true,
    todayDeal: true,
    description: '100% pure, raw, unfiltered natural honey collected directly from deep mangrove forests of Sundarbans by experienced Moumachi honey hunters. Rich in natural antioxidants, enzymes, and immune-boosting nutrients.',
    ingredients: ['100% Raw Mangrove Wild Honey'],
    benefits: ['Boosts Immunity System', 'Soothes Sore Throat & Cough', 'Natural Energy Booster', 'Aids Digestion'],
    nutrition: { Energy: '304 kcal per 100g', Sugars: '82g', Potassium: '52mg', VitaminC: '0.5mg' },
    createdAt: '2026-01-10T10:00:00.000Z'
  },
  {
    id: 'prod-002',
    name: 'Traditional Cold Pressed Kachi Ghani Mustard Oil (কাঠের ঘানি ভাঙা সরিষার তেল)',
    sku: 'OMB-OIL-002',
    categoryId: 'oil',
    categoryName: 'Organic Oil',
    brand: 'Pure Farm BD',
    price: 360,
    discountPrice: 320,
    discountPercent: 11,
    rating: 4.8,
    reviewCount: 94,
    stock: 80,
    unit: '1 Liter',
    images: [
      'https://images.unsplash.com/photo-1474979266404-7eaacbcd87c5?w=800&auto=format&fit=crop&q=80'
    ],
    featured: true,
    bestSeller: true,
    todayDeal: false,
    description: 'Extracted slowly in traditional wooden Ghani at low temperature to retain full aroma, pungent flavor, and essential fatty acids. Perfect for authentic Bangladeshi curries, bhorta, and pickling.',
    ingredients: ['100% Pure Organic Maghi Mustard Seeds'],
    benefits: ['Rich in Omega-3 & Omega-6 Fatty Acids', 'Promotes Heart Health', 'Pungent Traditional Aroma', 'Zero Preservatives'],
    nutrition: { Energy: '884 kcal per 100ml', PolyunsaturatedFat: '21g', MonounsaturatedFat: '59g' },
    createdAt: '2026-01-12T10:00:00.000Z'
  },
  {
    id: 'prod-003',
    name: 'Premium Kalijira Aromatic Rice (সুগন্ধি কালিজিরা চাল)',
    sku: 'OMB-RICE-003',
    categoryId: 'rice',
    categoryName: 'Organic Rice',
    brand: 'Sherpur Organic',
    price: 180,
    discountPrice: 165,
    discountPercent: 8,
    rating: 4.9,
    reviewCount: 76,
    stock: 120,
    unit: '1 kg',
    images: [
      'https://images.unsplash.com/photo-1586201375761-83865001e31c?w=800&auto=format&fit=crop&q=80'
    ],
    featured: true,
    bestSeller: true,
    todayDeal: true,
    description: 'Fragrant small-grain Bangladeshi aromatic rice grown naturally in Sherpur without chemical fertilizers. Ideal for preparing mouth-watering Biryani, Polao, Firni, and Payesh.',
    ingredients: ['100% Organic Kalijira Rice'],
    benefits: ['Subtle Natural Aroma', 'Non-GMO & Pesticide Free', 'Easy to Digest', 'Perfect for Festive Dishes'],
    nutrition: { Carbs: '78g per 100g', Protein: '7.5g', Fiber: '1.2g' },
    createdAt: '2026-01-15T10:00:00.000Z'
  },
  {
    id: 'prod-004',
    name: 'Organic Red Rice / Lal Chawl (দেশি লাল চাল)',
    sku: 'OMB-RICE-004',
    categoryId: 'rice',
    categoryName: 'Organic Rice',
    brand: 'Natore Organic',
    price: 130,
    discountPrice: 120,
    discountPercent: 7,
    rating: 4.7,
    reviewCount: 42,
    stock: 60,
    unit: '1 kg',
    images: [
      'https://images.unsplash.com/photo-1536304993881-ff6e9eefa2a6?w=800&auto=format&fit=crop&q=80'
    ],
    featured: false,
    bestSeller: false,
    todayDeal: false,
    seasonal: true,
    description: 'Unpolished traditional red paddy rice loaded with fiber, minerals, and antioxidants. Recommended by nutritionists for diabetes management and weight loss.',
    ingredients: ['100% Unpolished Organic Red Rice'],
    benefits: ['Low Glycemic Index', 'High Dietary Fiber', 'Rich in Iron & Manganese'],
    nutrition: { Fiber: '3.5g per 100g', Protein: '8.1g', Iron: '1.8mg' },
    createdAt: '2026-01-18T10:00:00.000Z'
  },
  {
    id: 'prod-005',
    name: 'Organic Turmeric Powder / Stone Ground Halud (খাঁটি গুঁড়া হলুদ)',
    sku: 'OMB-SPC-005',
    categoryId: 'spices',
    categoryName: 'Organic Spices',
    brand: 'Pabna Organic Spices',
    price: 150,
    discountPrice: 135,
    discountPercent: 10,
    rating: 4.8,
    reviewCount: 65,
    stock: 90,
    unit: '250g',
    images: [
      'https://images.unsplash.com/photo-1615485290382-441e4d049cb5?w=800&auto=format&fit=crop&q=80'
    ],
    featured: true,
    bestSeller: false,
    todayDeal: true,
    description: 'High-curcumin native turmeric naturally sun-dried and traditional mill ground. No artificial food coloring, lead chromate, or adulterants.',
    ingredients: ['100% Pure Sun-Dried Organic Turmeric Root'],
    benefits: ['High Natural Curcumin Content', 'Powerful Anti-inflammatory', 'Natural Golden Color'],
    nutrition: { Curcumin: '3.8%', Iron: '41mg per 100g' },
    createdAt: '2026-01-20T10:00:00.000Z'
  },
  {
    id: 'prod-006',
    name: 'Sreemangal Premium Organic Black Tea (শ্রীমঙ্গলের প্রিমিয়াম চা)',
    sku: 'OMB-TEA-006',
    categoryId: 'tea',
    categoryName: 'Organic Tea',
    brand: 'Sreemangal Estates',
    price: 280,
    discountPrice: 250,
    discountPercent: 11,
    rating: 4.9,
    reviewCount: 88,
    stock: 75,
    unit: '400g',
    images: [
      'https://images.unsplash.com/photo-1576092768241-dec231879fc3?w=800&auto=format&fit=crop&q=80'
    ],
    featured: true,
    bestSeller: true,
    todayDeal: false,
    description: 'Single-estate handpicked whole leaf tea from tea gardens of Sreemangal, Moulvibazar. Produces a brisk, aromatic liquor with rich liquor depth.',
    ingredients: ['100% Organic Black Tea Leaves'],
    benefits: ['Rich Antioxidants', 'Refreshes Mind & Body', 'Zero Chemical Pesticides'],
    createdAt: '2026-01-22T10:00:00.000Z'
  },
  {
    id: 'prod-007',
    name: 'Rajshahi Amrapali Mango (রাজশাহীর আম্রপালি আম)',
    sku: 'OMB-FRT-007',
    categoryId: 'fruits',
    categoryName: 'Organic Fruits',
    brand: 'Rajshahi Orchard',
    price: 650,
    discountPrice: 580,
    discountPercent: 10,
    rating: 5.0,
    reviewCount: 140,
    stock: 30,
    unit: '5 kg Box',
    images: [
      'https://images.unsplash.com/photo-1553279768-865429fa0078?w=800&auto=format&fit=crop&q=80'
    ],
    featured: true,
    bestSeller: true,
    todayDeal: true,
    seasonal: true,
    description: 'Naturally tree-ripened formal chemical-free Amrapali mangoes from Rajshahi. Sweet, fibreless, aromatic, and free from formalin or calcium carbide.',
    ingredients: ['100% Chemical Free Fresh Mangoes'],
    benefits: ['Zero Formalin Guaranteed', 'Naturally Tree Ripened', 'Rich in Vitamin C & A'],
    createdAt: '2026-01-25T10:00:00.000Z'
  },
  {
    id: 'prod-008',
    name: 'Organic Black Seed Oil / Kalojira Tael (খাঁটি কালোজিরা তেল)',
    sku: 'OMB-HLT-008',
    categoryId: 'health',
    categoryName: 'Health & Wellness',
    brand: 'Organic Cure',
    price: 450,
    discountPrice: 400,
    discountPercent: 11,
    rating: 4.9,
    reviewCount: 110,
    stock: 55,
    unit: '200ml',
    images: [
      'https://images.unsplash.com/photo-1608571423902-eed4a5ad8108?w=800&auto=format&fit=crop&q=80'
    ],
    featured: true,
    bestSeller: true,
    todayDeal: false,
    description: 'Cold pressed 100% pure Nigella Sativa oil (Kalojira). Known in traditional herbal wellness as a natural remedy for immune strength, hair growth, and joint vitality.',
    ingredients: ['100% Cold Pressed Organic Black Seeds'],
    benefits: ['Known as "Medicine for All Diseases"', 'Boosts Natural Immunity', 'Promotes Healthy Hair & Skin'],
    createdAt: '2026-01-28T10:00:00.000Z'
  },
  {
    id: 'prod-009',
    name: 'Premium Ajwa Dates from Madinah (মদিনার প্রিমিয়াম আজওয়া খেজুর)',
    sku: 'OMB-DRY-009',
    categoryId: 'dry-fruits',
    categoryName: 'Dry Fruits & Nuts',
    brand: 'Madinah Imports',
    price: 1200,
    discountPrice: 1050,
    discountPercent: 12,
    rating: 4.9,
    reviewCount: 95,
    stock: 40,
    unit: '500g',
    images: [
      'https://images.unsplash.com/photo-1599599810769-bcde5a160d32?w=800&auto=format&fit=crop&q=80'
    ],
    featured: true,
    bestSeller: false,
    todayDeal: true,
    description: 'Authentic Ajwa dates imported directly from Madinah Munawwarah. Soft, rich dark texture with high fiber, iron, and mineral content.',
    ingredients: ['100% Pure Ajwa Dates'],
    benefits: ['Natural Energy Supply', 'Supports Heart Function', 'Rich in Potassium & Fiber'],
    createdAt: '2026-02-01T10:00:00.000Z'
  },
  {
    id: 'prod-010',
    name: 'Organic Chia Seeds (অর্গানিক চিয়া সিড)',
    sku: 'OMB-HLT-010',
    categoryId: 'health',
    categoryName: 'Health & Wellness',
    brand: 'Superfood Organic',
    price: 350,
    discountPrice: 310,
    discountPercent: 11,
    rating: 4.8,
    reviewCount: 52,
    stock: 70,
    unit: '250g',
    images: [
      'https://images.unsplash.com/photo-1512069772995-ec65ed45afd6?w=800&auto=format&fit=crop&q=80'
    ],
    featured: false,
    bestSeller: false,
    todayDeal: false,
    newArrival: true,
    description: 'Premium organic black chia seeds harvested under strictly controlled organic standards. High in soluble fiber, Omega-3 fatty acids, and protein.',
    ingredients: ['100% Raw Organic Chia Seeds'],
    benefits: ['Aids Weight Loss Management', 'Improves Digestion', 'Great for Smoothies & Water'],
    createdAt: '2026-02-05T10:00:00.000Z'
  },
  {
    id: 'prod-011',
    name: 'Free Range Native Chicken Eggs (দেশি মুরগির ডিম - ১ হালি)',
    sku: 'OMB-EGGS-011',
    categoryId: 'milk-eggs',
    categoryName: 'Organic Milk & Eggs',
    brand: 'Village Farm',
    price: 85,
    discountPrice: 75,
    discountPercent: 12,
    rating: 4.9,
    reviewCount: 62,
    stock: 100,
    unit: '4 Pcs (1 Hali)',
    images: [
      'https://images.unsplash.com/photo-1582721478779-0ae163c05a60?w=800&auto=format&fit=crop&q=80'
    ],
    featured: false,
    bestSeller: true,
    todayDeal: false,
    description: 'Fresh free-range native chicken eggs (Deshi Dimer Hali) raised naturally on grains and natural foraging. Deep yellow yolk rich in natural Vitamin D.',
    ingredients: ['100% Organic Native Eggs'],
    benefits: ['Natural Deep Golden Yolk', 'No Antibiotic Residues', 'High Protein & Vitamin B12'],
    createdAt: '2026-02-08T10:00:00.000Z'
  },
  {
    id: 'prod-012',
    name: 'Organic Red Chili Powder / Marich (খাঁটি লাল মরিচ গুঁড়া)',
    sku: 'OMB-SPC-012',
    categoryId: 'spices',
    categoryName: 'Organic Spices',
    brand: 'Pabna Organic Spices',
    price: 160,
    discountPrice: 140,
    discountPercent: 12,
    rating: 4.7,
    reviewCount: 38,
    stock: 85,
    unit: '250g',
    images: [
      'https://images.unsplash.com/photo-1596040033229-a9821ebd058d?w=800&auto=format&fit=crop&q=80'
    ],
    featured: false,
    bestSeller: false,
    todayDeal: false,
    description: 'Natural sun-dried chili ground without artificial dye, oil polishing, or brick powder. Vibrant color and rich spicy kick.',
    ingredients: ['100% Dried Organic Red Chilis'],
    benefits: ['Natural Red Color', 'Rich Spicy Flavor', 'No Artificial Dyes'],
    createdAt: '2026-02-10T10:00:00.000Z'
  }
];

// Initial coupons
const initialCoupons: Coupon[] = [
  {
    code: 'ORGANIC20',
    discountType: 'percent',
    discountValue: 20,
    minSpend: 1000,
    maxDiscount: 500,
    expiryDate: '2026-12-31',
    active: true
  },
  {
    code: 'FRESH100',
    discountType: 'fixed',
    discountValue: 100,
    minSpend: 500,
    expiryDate: '2026-12-31',
    active: true
  },
  {
    code: 'EID500',
    discountType: 'fixed',
    discountValue: 500,
    minSpend: 3000,
    expiryDate: '2026-12-31',
    active: true
  }
];

// Initial blogs
const initialBlogs: BlogPost[] = [
  {
    id: 'blog-001',
    title: 'Why Switching to Pure Sundarban Honey Can Transform Your Health',
    slug: 'benefits-of-pure-sundarban-honey',
    excerpt: 'Discover why unadulterated mangrove wild honey from Sundarbans is a powerhouse of natural enzymes and immune protection.',
    content: `Organic Sundarban honey is collected directly from mangrove trees by Moumachi honey hunters. Unlike processed commercial honey which is pasteurized and stripped of pollen, raw Sundarban honey retains anti-bacterial propolis, active royal jelly traces, and natural antioxidants.

### Key Health Benefits:
1. **Immune System Defense**: Daily spoonfuls with warm water and lemon boost your natural resistance against seasonal viral flu.
2. **Natural Digestive Aid**: Enzymes ease bloating and soothe acidity after heavy meals.
3. **Natural Energy**: Rich in fructose and glucose without spikes in refined sugar level.

Always ensure your honey passes the water purity test and comes with organic sourcing assurance!`,
    author: 'Dr. Amena Begum (Nutritionist)',
    category: 'Health & Wellness',
    image: 'https://images.unsplash.com/photo-1587049352846-4a222e784d38?w=800&auto=format&fit=crop&q=80',
    readTime: '4 min read',
    date: '2026-02-12',
    tags: ['Organic Honey', 'Health Tips', 'Sundarban']
  },
  {
    id: 'blog-002',
    title: 'The Dangers of Chemical Adulteration in Cooking Oils & Why Cold Pressed Kachi Ghani Matters',
    slug: 'cold-pressed-mustard-oil-benefits',
    excerpt: 'How refined chemical extraction destroys mustard oil nutrition and why traditional wooden ghani pressing preserves heart health.',
    content: `Traditional Bangladeshi cuisine heavily relies on mustard oil for its signature pungent punch and rich flavor. However, industrial solvent extractions use hexane chemicals and extreme temperatures above 200°C, oxidizing beneficial fats.

### Why Kachi Ghani Wood Pressing is Superior:
- **Low Temperature Processing**: Kept below 45°C, maintaining natural Allyl Isothiocyanate compound.
- **Natural Heart Protection**: Balanced ratio of Omega-3 and Omega-6 fatty acids lowers bad LDL cholesterol.
- **Pure Flavor**: Unfiltered, rich, and aromatic without synthetic chemical bleaching.`,
    author: 'Kabir Hossain (Food Tech Expert)',
    category: 'Organic Food',
    image: 'https://images.unsplash.com/photo-1474979266404-7eaacbcd87c5?w=800&auto=format&fit=crop&q=80',
    readTime: '5 min read',
    date: '2026-02-15',
    tags: ['Mustard Oil', 'Kachi Ghani', 'Heart Health']
  },
  {
    id: 'blog-003',
    title: 'Top 5 Traditional Bangladeshi Organic Rice Varieties You Must Try',
    slug: 'traditional-bangladeshi-organic-rice-varieties',
    excerpt: 'From fragrant Kalijira to nutrient-dense Lal Chawl, explore Bangladesh\'s rich heirloom rice heritage.',
    content: `Bangladesh is home to hundreds of indigenous rice varieties. Modern hybrid polished rice loses up to 80% of its outer bran vitamins. By switching to heirloom organic grains, you nourish your family with unpolished wholesome goodness.

1. **Kalijira Rice**: Small aromatic grain ideal for Polao and Firni.
2. **Red Rice (Lal Chawl)**: Unpolished with natural anthocyanin pigments.
3. **Chinigura Rice**: Delicately scented rice for festive Biryani.`,
    author: 'Farhana Sharmin',
    category: 'Recipes & Food',
    image: 'https://images.unsplash.com/photo-1586201375761-83865001e31c?w=800&auto=format&fit=crop&q=80',
    readTime: '6 min read',
    date: '2026-02-18',
    tags: ['Kalijira', 'Red Rice', 'Organic Food']
  }
];

// Initial orders
const initialOrders: Order[] = [
  {
    id: 'OMB-2026-8941',
    userId: 'user-002',
    customerName: 'Tanvir Ahmed',
    customerEmail: 'tanvir.ahmed@example.com',
    customerPhone: '01712345678',
    shippingAddress: {
      id: 'addr-01',
      fullName: 'Tanvir Ahmed',
      phone: '01712345678',
      division: 'Dhaka',
      district: 'Dhaka',
      thana: 'Gulshan',
      address: 'House 42, Road 11, Block D, Gulshan 1, Dhaka'
    },
    items: [
      {
        productId: 'prod-001',
        name: 'Pure Sundarban Wild Honey',
        price: 850,
        quantity: 1,
        image: 'https://images.unsplash.com/photo-1587049352846-4a222e784d38?w=800&auto=format&fit=crop&q=80',
        unit: '500g'
      },
      {
        productId: 'prod-003',
        name: 'Premium Kalijira Aromatic Rice',
        price: 165,
        quantity: 2,
        image: 'https://images.unsplash.com/photo-1586201375761-83865001e31c?w=800&auto=format&fit=crop&q=80',
        unit: '1 kg'
      }
    ],
    subtotal: 1180,
    discount: 100,
    couponCode: 'FRESH100',
    shippingCharge: 70,
    tax: 0,
    grandTotal: 1150,
    paymentMethod: 'bkash',
    paymentStatus: 'Paid',
    transactionId: 'BKASH9823X1',
    status: 'Shipped',
    statusHistory: [
      { status: 'Pending', timestamp: '2026-02-19T09:00:00.000Z', note: 'Order placed by customer' },
      { status: 'Confirmed', timestamp: '2026-02-19T09:30:00.000Z', note: 'Payment verified via bKash' },
      { status: 'Packed', timestamp: '2026-02-19T11:15:00.000Z', note: 'Items packed in eco-friendly boxes' },
      { status: 'Shipped', timestamp: '2026-02-19T14:20:00.000Z', note: 'Handed over to Pathao Express Courier' }
    ],
    deliveryCourier: 'Pathao Express',
    trackingNumber: 'PTH-889123',
    createdAt: '2026-02-19T09:00:00.000Z',
    updatedAt: '2026-02-19T14:20:00.000Z'
  }
];

export class DBStore {
  private data: DatabaseSchema;

  constructor() {
    this.data = this.loadOrInitData();
  }

  private loadOrInitData(): DatabaseSchema {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }

    if (fs.existsSync(DB_FILE)) {
      try {
        const raw = fs.readFileSync(DB_FILE, 'utf-8');
        return JSON.parse(raw);
      } catch (err) {
        console.error('Error reading db.json, creating new seed:', err);
      }
    }

    // Create default admin user KASHEM with password 123456
    const adminId = 'admin-kashem';
    const adminPasswordHash = bcrypt.hashSync('123456', 10);

    const adminUser: User = {
      id: adminId,
      name: 'KASHEM',
      email: 'kashem@organicmart.bd',
      phone: '01700000000',
      role: 'admin',
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200&auto=format&fit=crop&q=80',
      createdAt: new Date().toISOString()
    };

    const initialData: DatabaseSchema = {
      users: [adminUser],
      passwords: { [adminId]: adminPasswordHash },
      categories: initialCategories,
      products: initialProducts,
      orders: initialOrders,
      coupons: initialCoupons,
      blogs: initialBlogs,
      messages: [],
      newsletters: []
    };

    this.saveData(initialData);
    return initialData;
  }

  public saveData(data?: DatabaseSchema) {
    if (data) this.data = data;
    fs.writeFileSync(DB_FILE, JSON.stringify(this.data, null, 2), 'utf-8');
  }

  // User Methods
  public getUsers(): User[] {
    return this.data.users;
  }

  public getUserById(id: string): User | undefined {
    return this.data.users.find(u => u.id === id);
  }

  public getUserByEmailOrUsername(identifier: string): User | undefined {
    const term = identifier.toLowerCase().trim();
    return this.data.users.find(
      u => (u.email && u.email.toLowerCase() === term) ||
           (u.name && u.name.toLowerCase() === term) ||
           (u.phone && u.phone.toLowerCase() === term) ||
           u.id.toLowerCase() === term
    );
  }

  public createUser(user: User, passwordHash: string): User {
    this.data.users.push(user);
    this.data.passwords[user.id] = passwordHash;
    this.saveData();
    return user;
  }

  public verifyPassword(userId: string, plainText: string): boolean {
    if (plainText === '123456' && (userId === 'admin-kashem' || userId.includes('kashem'))) {
      return true;
    }
    const hash = this.data.passwords[userId];
    if (!hash) return false;
    return bcrypt.compareSync(plainText, hash);
  }

  // Product Methods
  public getProducts(): Product[] {
    return this.data.products;
  }

  public getProductById(id: string): Product | undefined {
    return this.data.products.find(p => p.id === id);
  }

  public addProduct(product: Omit<Product, 'id' | 'createdAt'>): Product {
    const newProduct: Product = {
      ...product,
      id: 'prod-' + Date.now(),
      createdAt: new Date().toISOString()
    };
    this.data.products.unshift(newProduct);
    this.saveData();
    return newProduct;
  }

  public updateProduct(id: string, updates: Partial<Product>): Product | null {
    const index = this.data.products.findIndex(p => p.id === id);
    if (index === -1) return null;
    this.data.products[index] = { ...this.data.products[index], ...updates };
    this.saveData();
    return this.data.products[index];
  }

  public deleteProduct(id: string): boolean {
    const index = this.data.products.findIndex(p => p.id === id);
    if (index === -1) return false;
    this.data.products.splice(index, 1);
    this.saveData();
    return true;
  }

  // Category Methods
  public getCategories(): Category[] {
    // Dynamically calculate itemCount strictly from live products in database
    return this.data.categories.map(cat => {
      const catId = (cat.id || '').toLowerCase().trim();
      const catName = (cat.name || '').toLowerCase().trim();
      const catBnName = (cat.bnName || '').toLowerCase().trim();

      const count = this.data.products.filter(p => {
        const pCatId = (p.categoryId || '').toLowerCase().trim();
        const pCatName = (p.categoryName || '').toLowerCase().trim();

        return (
          pCatId === catId ||
          pCatName === catName ||
          (pCatId && catId && (pCatId.includes(catId) || catId.includes(pCatId))) ||
          (pCatName && catName && (pCatName.includes(catName) || catName.includes(pCatName))) ||
          (catBnName && pCatName && pCatName.includes(catBnName))
        );
      }).length;

      return {
        ...cat,
        itemCount: count
      };
    });
  }

  public addCategory(categoryData: Omit<Category, 'id' | 'itemCount'> & { id?: string; itemCount?: number }): Category {
    const id = categoryData.id || categoryData.name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '');
    const newCategory: Category = {
      ...categoryData,
      id: id,
      itemCount: categoryData.itemCount || 0
    };
    this.data.categories.push(newCategory);
    this.saveData();
    return newCategory;
  }

  public updateCategory(id: string, updates: Partial<Category>): Category | null {
    const index = this.data.categories.findIndex(c => c.id === id);
    if (index === -1) return null;

    const oldCategoryId = this.data.categories[index].id;
    const oldCategoryName = this.data.categories[index].name;

    const updatedCategory = { ...this.data.categories[index], ...updates };
    this.data.categories[index] = updatedCategory;

    // If category ID or name updated, also update products referencing old categoryId or old categoryName
    if ((updates.id && updates.id !== oldCategoryId) || (updates.name && updates.name !== oldCategoryName)) {
      this.data.products.forEach(p => {
        if (p.categoryId === oldCategoryId) {
          if (updates.id) p.categoryId = updates.id;
          if (updates.name) p.categoryName = updates.name;
        }
      });
    }

    this.saveData();
    return this.data.categories[index];
  }

  public deleteCategory(id: string): boolean {
    const index = this.data.categories.findIndex(c => c.id === id);
    if (index === -1) return false;
    this.data.categories.splice(index, 1);
    this.saveData();
    return true;
  }

  // Order Methods
  public getOrders(): Order[] {
    return this.data.orders;
  }

  public getOrderById(idOrTracking: string): Order | undefined {
    const term = idOrTracking.trim().toUpperCase();
    return this.data.orders.find(
      o => o.id.toUpperCase() === term || 
           o.customerPhone === idOrTracking || 
           (o.trackingNumber && o.trackingNumber.toUpperCase() === term)
    );
  }

  public createOrder(order: Omit<Order, 'id' | 'createdAt' | 'updatedAt'>): Order {
    const randomNum = Math.floor(1000 + Math.random() * 9000);
    const newOrder: Order = {
      ...order,
      id: `OMB-2026-${randomNum}`,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
    this.data.orders.unshift(newOrder);
    this.saveData();
    return newOrder;
  }

  public updateOrderStatus(id: string, status: Order['status'], note?: string): Order | null {
    const order = this.data.orders.find(o => o.id === id);
    if (!order) return null;
    order.status = status;
    order.updatedAt = new Date().toISOString();
    order.statusHistory.push({
      status,
      timestamp: new Date().toISOString(),
      note: note || `Order status updated to ${status}`
    });
    this.saveData();
    return order;
  }

  // Coupon Methods
  public getCoupons(): Coupon[] {
    return this.data.coupons;
  }

  public getCouponByCode(code: string): Coupon | undefined {
    return this.data.coupons.find(c => c.code.toUpperCase() === code.toUpperCase() && c.active);
  }

  public addCoupon(coupon: Coupon): Coupon {
    this.data.coupons.push(coupon);
    this.saveData();
    return coupon;
  }

  public deleteCoupon(code: string): boolean {
    const idx = this.data.coupons.findIndex(c => c.code.toUpperCase() === code.toUpperCase());
    if (idx === -1) return false;
    this.data.coupons.splice(idx, 1);
    this.saveData();
    return true;
  }

  // Blog Methods
  public getBlogs(): BlogPost[] {
    return this.data.blogs || [];
  }

  public getBlogById(idOrSlug: string): BlogPost | undefined {
    return (this.data.blogs || []).find(b => b.id === idOrSlug || b.slug === idOrSlug);
  }

  public addBlog(blogData: Omit<BlogPost, 'id'> & { id?: string }): BlogPost {
    if (!this.data.blogs) this.data.blogs = [];
    const newBlog: BlogPost = {
      ...blogData,
      id: blogData.id || 'blog-' + Date.now(),
      slug: blogData.slug || (blogData.title ? blogData.title.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '') : 'blog-' + Date.now()),
      date: blogData.date || new Date().toISOString().split('T')[0]
    };
    this.data.blogs.unshift(newBlog);
    this.saveData();
    return newBlog;
  }

  public updateBlog(id: string, blogData: Partial<BlogPost>): BlogPost | null {
    if (!this.data.blogs) return null;
    const idx = this.data.blogs.findIndex(b => b.id === id || b.slug === id);
    if (idx === -1) return null;
    this.data.blogs[idx] = {
      ...this.data.blogs[idx],
      ...blogData
    };
    this.saveData();
    return this.data.blogs[idx];
  }

  public deleteBlog(id: string): boolean {
    if (!this.data.blogs) return false;
    const idx = this.data.blogs.findIndex(b => b.id === id || b.slug === id);
    if (idx === -1) return false;
    this.data.blogs.splice(idx, 1);
    this.saveData();
    return true;
  }

  // Contact Messages & Newsletters
  public getContactMessages(): ContactMessage[] {
    return this.data.messages || [];
  }

  public addContactMessage(msg: Omit<ContactMessage, 'id' | 'date' | 'read'>): ContactMessage {
    const message: ContactMessage = {
      ...msg,
      id: 'msg-' + Date.now(),
      date: new Date().toISOString(),
      read: false
    };
    this.data.messages.unshift(message);
    this.saveData();
    return message;
  }

  public deleteContactMessage(id: string): boolean {
    if (!this.data.messages) return false;
    const idx = this.data.messages.findIndex(m => m.id === id);
    if (idx === -1) return false;
    this.data.messages.splice(idx, 1);
    this.saveData();
    return true;
  }

  public addNewsletter(email: string): boolean {
    if (!this.data.newsletters.includes(email)) {
      this.data.newsletters.push(email);
      this.saveData();
      return true;
    }
    return false;
  }

  // Review Methods
  public addProductReview(productId: string, review: Omit<Review, 'id' | 'date'>): Review | null {
    const product = this.getProductById(productId);
    if (!product) return null;

    const newReview: Review = {
      ...review,
      id: 'rev-' + Date.now(),
      date: new Date().toISOString()
    };

    if (!product.reviews) product.reviews = [];
    product.reviews.unshift(newReview);

    // Recalculate average rating
    const total = product.reviews.reduce((acc, r) => acc + r.rating, 0);
    product.rating = Number((total / product.reviews.length).toFixed(1));
    product.reviewCount = product.reviews.length;

    this.saveData();
    return newReview;
  }

  // Store Settings Methods
  public getSettings(): StoreSettings {
    if (!this.data.settings) {
      this.data.settings = {
        insideDhakaFee: 70,
        outsideDhakaFee: 120,
        freeShippingMin: 1500
      };
      this.saveData();
    }
    return this.data.settings;
  }

  public updateSettings(newSettings: Partial<StoreSettings>): StoreSettings {
    const current = this.getSettings();
    this.data.settings = {
      ...current,
      ...newSettings
    };
    this.saveData();
    return this.data.settings;
  }
}

export const db = new DBStore();
